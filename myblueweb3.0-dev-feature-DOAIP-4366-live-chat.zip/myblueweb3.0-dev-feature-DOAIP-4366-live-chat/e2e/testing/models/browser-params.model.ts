import { SiteAccountType } from './site-account-type.enum';
import { SiteAccount } from './site-account.model';

export interface BrowserParams {
  accounts: { [key in SiteAccountType]: SiteAccount };
}
