import { browser, ElementFinder, protractor } from 'protractor';
import { isVisible } from '../util';

const EC = protractor.ExpectedConditions;

/**
 * Promotes separation of concerns by abstracting DOM concerns away from
 * testing logic.
 *
 * While "page object" is the common term used, a page object does not
 * necessarily represent a literal "page" in an application. It can represent
 * any part of a user interface.
 */
export abstract class BasePageObject<ChildEnum> {
  /**
   * An ElementFinder that can locate the page object in the DOM.
   */
  protected readonly container: ElementFinder;

  /**
   * @param container
   *   An ElementFinder that can locate the page object in the DOM.
   *   For best results, provide a DOM element that can be tested for visibility,
   *   and not necessarily the topmost "app-" element of an Angular component.
   */
  constructor(container: ElementFinder) {
    this.container = container;
  }

  /**
   * Returns child ElementFinder instances for internal use based on exposed
   * enum values.
   */
  protected abstract resolveChild(child: ChildEnum): ElementFinder;

  /**
   * Performs a mouse click on an element contained by the page object.
   */
  public async clickChild(child: ChildEnum): Promise<void> {
    const childElement = this.resolveChild(child);
    await childElement.click();
  }

  /**
   * Clause usable in an expect() test to determine whether a child element
   * contains specific text.
   */
  public async containsText(text: string): Promise<boolean> {
    try {
      await browser.wait(EC.textToBePresentInElement(this.container, text));
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * Clause usable in an expect() test to determine whether a child element
   * contains specific text.
   */
  public async childContainsText(child: ChildEnum, text: string): Promise<boolean> {
    const childElement = this.resolveChild(child);
    try {
      await browser.wait(EC.textToBePresentInElement(childElement, text));
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * Clause usable in an expect() test to determine visibility of a child element.
   *
   * This check returns the element's state immediately; it does not wait for HTTP requests
   * and timeouts to complete. Add additional checks as needed to determine whether the
   * UI is stable enough for interaction and testing.
   */
  public async isChildVisible(child: ChildEnum): Promise<boolean> {
    const childElement = this.resolveChild(child);
    // const waitForAngular = await browser.waitForAngularEnabled();
    // await browser.waitForAngularEnabled(false);
    // const isVisible = await isVisible(childElement);
    // await browser.waitForAngularEnabled(waitForAngular);
    return await isVisible(childElement);
  }

  /**
   * Clause usable in an expect() test to determine the presence
   * (but not necessarily the visibility) of the main container.
   *
   * This check returns the element's state immediately; it does not wait for HTTP requests
   * and timeouts to complete. Add additional checks as needed to determine whether the
   * UI is stable enough for interaction and testing.
   */
  public async isPresent(waitForAngular: boolean = true): Promise<boolean> {
    // const previousWaitForAngular = await browser.waitForAngularEnabled();
    // await browser.waitForAngularEnabled(waitForAngular);
    const isPresent = await this.container.isPresent();
    // await browser.waitForAngularEnabled(previousWaitForAngular);
    return isPresent;
  }

  /**
   * Clause usable in an expect() test to determine visibility of the main container.
   *
   * This check returns the element's state immediately; it does not wait for HTTP requests
   * and timeouts to complete. Add additional checks as needed to determine whether the
   * UI is stable enough for interaction and testing.
   */
  public async isVisible(): Promise<boolean> {
    // const waitForAngular = await browser.waitForAngularEnabled();
    // await browser.waitForAngularEnabled(false);
    // const isVisible = await isVisible(this.container);
    // await browser.waitForAngularEnabled(waitForAngular);
    return await isVisible(this.container);
  }

  /**
   * Vertically scrolls the main container into view.
   */
  public async scrollTo(): Promise<void> {
    const loc = await this.container.getLocation();
    await browser.driver.executeScript(`window.scrollTo(0, ${loc.y});`);
  }

  /**
   * Vertically scrolls a child element into view.
   */
  public async scrollToChild(child: ChildEnum): Promise<void> {
    const childElement = this.resolveChild(child);
    const loc = await childElement.getLocation();
    await browser.driver.executeScript(`window.scrollTo(0, ${loc.y});`);
  }

  /**
   * Waits until the page object is either invisible or not present in the DOM.
   *
   * @param timeout How long to wait, in milliseconds.
   */
  public async waitUntilInvisible(timeout: number = 10000): Promise<void> {
    await browser.wait(EC.invisibilityOf(this.container), timeout, 'Timed out waiting for invisibility of page object container element.');
  }

  /**
   * Waits until the page object is present in the DOM (but not necessarily visible).
   *
   * @param timeout How long to wait, in milliseconds.
   */
  public async waitUntilPresent(timeout: number = 20000): Promise<void> {
    await browser.wait(EC.presenceOf(this.container), timeout, 'Timed out waiting for presence of page object container element.');
  }

  /**
   * Waits until the page object is both present and visible in the DOM.
   *
   * @param timeout How long to wait, in milliseconds.
   */
  public async waitUntilVisible(timeout: number = 20000): Promise<void> {
    await browser.wait(EC.visibilityOf(this.container), timeout, 'Timed out waiting for visibility of page object container element.');
  }

  /**
   * Waits until a child element is either invisible or not present in the DOM.
   *
   * @param child
   * @param timeout How long to wait, in milliseconds.
   */
  public async waitUntilChildInvisible(child: any, timeout: number = 10000): Promise<void> {
    const childElement = this.resolveChild(child);
    await browser.wait(EC.invisibilityOf(childElement), timeout, 'Timed out waiting for invisibility of page object child element.');
  }

  /**
   * Waits until a child element is both present and visible in the DOM.
   *
   * @param child
   * @param timeout How long to wait, in milliseconds.
   */
  public async waitUntilChildVisible(child: ChildEnum, timeout: number = 10000): Promise<void> {
    const childElement = this.resolveChild(child);
    await browser.wait(EC.visibilityOf(childElement), timeout, 'Timed out waiting for visibility of page object child element.');
  }
}
