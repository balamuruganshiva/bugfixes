import { browser, ElementFinder } from 'protractor';
import { BasePageObject } from './base.po';

/**
 * Represents an actual "page" in an Angular application that can be navigated
 * to by URL.
 */
export abstract class NavigablePageObject<ChildEnum> extends BasePageObject<ChildEnum> {
  protected path: string;

  /**
   * Constructor.
   *
   * @param path
   *   The absolute path to the page (e.g., "/login");
   * @param container
   *   An ElementFinder that can locate the page object in the DOM.
   *   For best results, provide a DOM element that can be tested for visibility,
   *   and not necessarily the topmost "app-" element of an Angular component.
   */
  constructor(path: string, container: ElementFinder) {
    super(container);
    this.path = path;
  }

  public async navigateTo(timeout = 10000): Promise<void> {
    // const currentUrl = await browser.getCurrentUrl();
    // console.log(currentUrl);
    // if (!currentUrl.endsWith(this.path)) {
    await browser.get(this.path, timeout);
    // }
    await this.waitUntilVisible(timeout);
  }
}
