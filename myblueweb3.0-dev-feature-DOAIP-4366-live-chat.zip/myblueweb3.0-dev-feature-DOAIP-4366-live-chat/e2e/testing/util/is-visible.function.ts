import { ElementFinder } from 'protractor';

export async function isVisible(element: ElementFinder): Promise<boolean> {
  const isPresent = await element.isPresent();
  if (!isPresent) {
    return false;
  } else {
    return await element.isDisplayed();
  }
}
