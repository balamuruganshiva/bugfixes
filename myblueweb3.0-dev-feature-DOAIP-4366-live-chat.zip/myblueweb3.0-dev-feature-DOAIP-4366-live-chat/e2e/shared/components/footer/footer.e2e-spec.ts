import { appInfoSectionSuite } from './app-info-section.suite';
import { Footer } from './footer.po';
import { languageAssistanceSectionSuite } from './language-assistance-section.suite';
import { socialMediaSectionSuite } from './social-media-section.suite';

describe('Footer', () => {
  const page = new Footer();

  languageAssistanceSectionSuite();
  appInfoSectionSuite();
  socialMediaSectionSuite();
});
