import { by, element, ElementFinder } from 'protractor';
import { BasePageObject } from '../../../testing/page-object';

enum Child {
  FACEBOOK_LINK = 'facebook-link',
  TWITTER_LINK = 'twitter-link',
  LINKEDIN_LINK = 'linkedin-link',
  YOUTUBE_LINK = 'youtube-link'
}

export class SocialMediaSection extends BasePageObject<Child> {
  public Child = Child;

  constructor() {
    super(element(by.css(`[data-qa="social-media"]`)));
  }

  protected resolveChild(child: Child): ElementFinder {
    switch (child) {
      case Child.FACEBOOK_LINK:
        return this.container.element(by.css(`[data-qa="social-media__link--facebook"]`));
      case Child.TWITTER_LINK:
        return this.container.element(by.css(`[data-qa="social-media__link--twitter"]`));
      case Child.LINKEDIN_LINK:
        return this.container.element(by.css(`[data-qa="social-media__link--linkedin"]`));
      case Child.YOUTUBE_LINK:
        return this.container.element(by.css(`[data-qa="social-media__link--youtube"]`));
      default:
        throw new Error('Child not defined.');
    }
  }
}
