import { by, element, ElementFinder } from 'protractor';
import { BasePageObject } from '../../../testing/page-object';

enum Child {
  APP_STORE_LINK = 'app-store-link',
  GOOGLE_PLAY_LINK = 'google-play-link'
}

export class AppInfoSection extends BasePageObject<Child> {
  public Child = Child;

  constructor() {
    super(element(by.css(`[data-qa="app-info"]`)));
  }

  protected resolveChild(child: Child): ElementFinder {
    switch (child) {
      case Child.APP_STORE_LINK:
        return this.container.element(by.css(`[data-qa="app-info__link--app-store"]`));
      case Child.GOOGLE_PLAY_LINK:
        return this.container.element(by.css(`[data-qa="app-info__link--google-play"]`));
      default:
        throw new Error('Child not defined.');
    }
  }
}
