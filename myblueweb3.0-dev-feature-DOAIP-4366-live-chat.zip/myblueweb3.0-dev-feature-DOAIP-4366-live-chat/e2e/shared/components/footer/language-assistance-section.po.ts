import { browser, by, element, ElementFinder, protractor } from 'protractor';
import { BasePageObject } from '../../../testing/page-object';

enum Child {
  ENGLISH_LINK = 'english-link',
  SPANISH_LINK = 'spanish-link',
  PORTUGESE_LINK = 'portugese-link',
  FRENCH_LINK = 'french-link',
  CHINESE_LINK = 'chinese-link',
  HAITIAN_CREOLE_LINK = 'haitian-creole-link',
  VIETNAMESE_LINK = 'vietnamese-link',
  RUSSIAN_LINK = 'russian-link',
  CAMBODIAN_LINK = 'cambodian-link',
  ITALIAN_LINK = 'italian-link',
  KOREAN_LINK = 'korean-link',
  GREEK_LINK = 'greek-link',
  POLISH_LINK = 'polish-link',
  HINDI_LINK = 'hindi-link',
  GUJARATI_LINK = 'gujarati-link',
  TAGALOG_LINK = 'tagalog-link',
  JAPANESE_LINK = 'japanese-link',
  GERMAN_LINK = 'german-link',
  LAO_LINK = 'lao-link',
  NAVAJO_LINK = 'navajo-link',
  MESSAGE = 'message'
}

enum SupportedLanguage {
  ENGLISH = 'en',
  SPANISH = 'es',
  PORTUGESE = 'pt',
  FRENCH = 'fr',
  CHINESE = 'zh',
  HAITIAN_CREOLE = 'ht',
  VIETNAMESE = 'vi',
  RUSSIAN = 'ru',
  CAMBODIAN = 'km',
  ITALIAN = 'it',
  KOREAN = 'ko',
  GREEK = 'el',
  POLISH = 'pl',
  HINDI = 'hi',
  GUJARATI = 'gu',
  TAGALOG = 'tl',
  JAPANESE = 'ja',
  GERMAN = 'de',
  LAO = 'lo',
  NAVAJO = 'nv'
}

export class LanguageAssistanceSection extends BasePageObject<Child> {
  public Child = Child;
  public SupportedLanguage = SupportedLanguage;

  public messages: { [key in SupportedLanguage]?: string } = {
    // tslint:disable:max-line-length
    [SupportedLanguage.ENGLISH]:
      'ATTENTION: If you speak a language other than English, language assistance services are available to you free of charge. Call 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.SPANISH]:
      'ATENCIÓN: Si habla español, tiene a su disposición servicios gratuitos de asistencia con el idioma. Llame al número de Servicio al Cliente que figura en su tarjeta de identificación 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.PORTUGESE]:
      'ATENÇÃO: Se fala português, são-lhe disponibilizados gratuitamente serviços de assistência de idiomas. Telefone para os Serviços aos Membros, através do número no seu cartão ID 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.FRENCH]:
      'ATTENTION : si vous parlez français, des services d’assistance linguistique sont disponibles gratuitement. Appelez le Service adhérents au numéro indiqué sur votre carte d’assuré 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.CHINESE]:
      '注意：如果您讲中文，我们可向您免费提供语言协助服务。请拨打您 ID 卡上的号码联系会员服务部 1-800-200-4255（TTY 号码：711）。',
    [SupportedLanguage.HAITIAN_CREOLE]:
      'ATANSYON: Si ou pale kreyòl ayisyen, sèvis asistans nan lang disponib pou ou gratis. Rele nimewo Sèvis Manm nan ki sou kat Idantitifkasyon w lan (Sèvis pou Malantandan 1-800-200-4255 TTY: 711).',
    [SupportedLanguage.VIETNAMESE]:
      'LƯU Ý: Nếu quý vị nói Tiếng Việt, các dịch vụ hỗ trợ ngôn ngữ được cung cấp cho quý vị miễn phí. Gọi cho Dịch vụ Hội viên theo số trên thẻ ID của quý vị 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.RUSSIAN]:
      'ВНИМАНИЕ: если Вы говорите по-русски, Вы можете воспользоваться бесплатными услугами переводчика. Позвоните в отдел обслуживания клиентов по номеру, указанному в Вашей идентификационной карте 1-800-200-4255 (телетайп: 711).',
    [SupportedLanguage.CAMBODIAN]:
      'ការជូនដំណឹង៖ ប្រសិនប�ើអ្នកនិយាយភាសា ខ្មែរ សេ វាជំនួយភាសាឥតគិតថ្លៃ គឺអាចរកបានសម្ រាប់អ្នក។ សូមទូរស័ព្ទទៅផ្នែកសេ វាសមា ជិកតាមលេខន ៅល� ើប័ណ្ណ សម្ គាល់ខ្លួ ខ្លួនរបស់អ្នក 1-800-200-4255 (TTY: 711)។',
    [SupportedLanguage.ITALIAN]:
      'ATTENZIONE: se parlate italiano, sono disponibili per voi servizi gratuiti di assistenza linguistica. Chiamate il Servizio per i membri al numero riportato sulla vostra scheda identificativa 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.KOREAN]:
      '주의:한국어를 사용하시는 경우, 언어 지원 서비스를 무료로 이용하실 수 있습니다. 귀하의 ID 카드에 있는 전화번호 1-800-200-4255 (TTY: 711)를 사용하여 회원 서비스에 전화하십시오.',
    [SupportedLanguage.GREEK]:
      'ΠΡΟΣΟΧΗ: Εάν μιλάτε Ελληνικά, διατίθενται για σας υπηρεσίες γλωσσικής βοήθειας, δωρεάν. Καλέστε την Υπηρεσία Εξυπηρέτησης Μελών στον αριθμό της κάρτας μέλους σας (ID Card) 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.POLISH]:
      'UWAGA: Osoby posługujące się językiem polskim mogą bezpłatnie skorzystać z pomocy językowej. Należy zadzwonić do Działu obsługi ubezpieczonych pod numer podany na identyfikatorze 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.HINDI]:
      'ध्यान दें: यदि आप हिन्दी बोलते हैं, तो भाषा सहाय ता सेवाएँ, आप के लिए नि:शुल्क उपलब्ध हैं। सदस्य सेवाओं को आपके आई.डी. कार ्ड पर दिए गए नंबर पर कॉल करें 1-800-200-4255 (टी.टी.वाई.: 711).',
    [SupportedLanguage.GUJARATI]:
      'ધ્યાન આપો: જો તમે ગુજરાતી બોલતા હો, તો તમને ભાષાકીય સહાય તા સેવાઓ વિના મૂલ્યે ઉપલબ્ધ છે. તમારા આઈડી કાર ્ડ પર આપેલા નંબર પર Member Service ને કૉલ કરો 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.TAGALOG]:
      'PAUNAWA: Kung nagsasalita ka ng wikang Tagalog, mayroon kang magagamit na mga libreng serbisyo para sa tulong sa wika. Tawagan ang Mga Serbisyo sa Miyembro sa numerong nasa iyong ID Card 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.JAPANESE]:
      'お知らせ：日本語をお話しになる方は無料の言語アシスタンスサービスをご利用いただけます。IDカードに記載の電話番号を使用してメンバーサービスまでお電話ください 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.GERMAN]:
      'ACHTUNG: Wenn Sie Deutsche sprechen, steht Ihnen kostenlos fremdsprachliche Unterstützung zur Verfügung. Rufen Sie den Mitgliederdienst unter der Nummer auf Ihrer ID-Karte an 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.LAO]:
      'ໍ ຂ້ຄວນໃສ່ໃຈ: ຖ້າເຈົ ້າເວົ ້າພາສາລາວໄດ້, ມີການບໍ ິລການຊ່ວຍເຫືຼອດ້ານພາສາໃຫ້ທ່ານໂດຍບໍ ່ເສຍຄ່າ.ໂທຫາຝ່າຍບໍ ິລການສະມາິຊກທີ ່ໝາຍເລກໂທລະສັບຢູ່ໃນບັດຂອງທ່ານ 1-800-200-4255 (TTY: 711).',
    [SupportedLanguage.NAVAJO]:
      'BAA !KOHWIINDZIN DOO&G&: Din4 k’ehj7 y1n7[t’i’go saad bee y1t’i’ 47 t’11j77k’e bee n7k1’a’doowo[go 47 n1’ahoot’i’. D77 bee an7tah7g7 ninaaltsoos bine’d44’ n0omba bik1’7g7ij8’ b44sh bee hod77lnih 1-800-200-4255 (TTY: 711).'
    // tslint:enable:max-line-length
  };

  constructor() {
    super(element(by.css(`[data-qa="language-assistance"]`)));
  }

  public async messageIs(language: SupportedLanguage): Promise<boolean> {
    const EC = protractor.ExpectedConditions;
    const expectedMessage = this.messages[language];
    const messageElement = this.resolveChild(Child.MESSAGE);

    try {
      await browser.wait(EC.textToBePresentInElement(messageElement, expectedMessage));
      return true;
    } catch (e) {
      return false;
    }
  }

  protected resolveChild(child: Child): ElementFinder {
    switch (child) {
      case Child.ENGLISH_LINK:
        return this.container.element(by.cssContainingText('a', 'English (English)'));
      case Child.SPANISH_LINK:
        return this.container.element(by.cssContainingText('a', 'Español (Spanish)'));
      case Child.PORTUGESE_LINK:
        return this.container.element(by.cssContainingText('a', 'Português (Portuguese)'));
      case Child.FRENCH_LINK:
        return this.container.element(by.cssContainingText('a', 'Français (French)'));
      case Child.CHINESE_LINK:
        return this.container.element(by.cssContainingText('a', '简体中文 (Chinese)'));
      case Child.HAITIAN_CREOLE_LINK:
        return this.container.element(by.cssContainingText('a', 'Kreyòl Ayisyen (Haitian Creole)'));
      case Child.VIETNAMESE_LINK:
        return this.container.element(by.cssContainingText('a', 'Tiếng Việt: (Vietnamese)'));
      case Child.RUSSIAN_LINK:
        return this.container.element(by.cssContainingText('a', 'Русский: (Russian)'));
      case Child.CAMBODIAN_LINK:
        return this.container.element(by.cssContainingText('a', 'ខ្មែរ (Mon-Khmer, Cambodian)'));
      case Child.ITALIAN_LINK:
        return this.container.element(by.cssContainingText('a', 'Italiano (Italian)'));
      case Child.KOREAN_LINK:
        return this.container.element(by.cssContainingText('a', '한국어: (Korean)'));
      case Child.GREEK_LINK:
        return this.container.element(by.cssContainingText('a', 'λληνικά: (Greek)'));
      case Child.POLISH_LINK:
        return this.container.element(by.cssContainingText('a', 'Polski: (Polish)'));
      case Child.HINDI_LINK:
        return this.container.element(by.cssContainingText('a', 'हिंदी (Hindi)'));
      case Child.GUJARATI_LINK:
        return this.container.element(by.cssContainingText('a', 'ગુજરાતી: (Gujarati)'));
      case Child.TAGALOG_LINK:
        return this.container.element(by.cssContainingText('a', 'Tagalog (Tagalog)'));
      case Child.JAPANESE_LINK:
        return this.container.element(by.cssContainingText('a', '日本語 (Japanese)'));
      case Child.GERMAN_LINK:
        return this.container.element(by.cssContainingText('a', 'Deutsch (German)'));
      case Child.LAO_LINK:
        return this.container.element(by.cssContainingText('a', 'ພາສາລາວ (Lao)'));
      case Child.NAVAJO_LINK:
        return this.container.element(by.cssContainingText('a', 'Diné Bizaad (Navajo)'));
      case Child.MESSAGE:
        return this.container.element(by.css(`[data-qa="language-assistance__message"]`));
      default:
        throw new Error('Child not defined.');
    }
  }
}
