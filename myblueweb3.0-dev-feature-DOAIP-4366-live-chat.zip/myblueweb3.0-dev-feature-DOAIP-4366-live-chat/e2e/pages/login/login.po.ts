import { browser, by, element, ElementFinder, protractor } from 'protractor';
import { NavigablePageObject } from '../../testing/page-object';
import { AuthenticatedUserPage } from '../landing/authenticated-user/authenticated-user.po';

const EC = protractor.ExpectedConditions;

enum Child {
  ALERT = 'alert',
  USERNAME_INPUT = 'username-input',
  USERNAME_INPUT_MESSAGES = 'username-input-messages',
  FORGOT_USERNAME_LINK = 'forgot-username-link',
  PASSWORD_INPUT = 'password-input',
  PASSWORD_TOGGLE_BUTTON = 'password-toggle-button',
  PASSWORD_INPUT_MESSAGES = 'password-input-messages',
  FORGOT_PASSWORD_LINK = 'forgot-password-link',
  REMEMBER_ME_CHECKBOX = 'remember-me-checkbox',
  SUBMIT_BUTTON = 'submit-button',
  HELP_LINK = 'help-link',
  REGISTER_LINK = 'register-link'
}

export class LoginPage extends NavigablePageObject<Child> {
  public Child = Child;

  public authenticatedUserPage = new AuthenticatedUserPage();

  constructor() {
    super('/login', element.all(by.css('app-core-login > div')).first());
  }

  public async passwordIsHidden(): Promise<boolean> {
    const input = this.resolveChild(Child.PASSWORD_INPUT);
    return (await input.getAttribute('type')) === 'password';
  }

  public async rememberMeIsChecked(): Promise<boolean> {
    /* The actual input is a hidden element, so not pulling from resolveChild() here */
    const checkbox = this.container.element(by.id('remember-me'));
    return !!(await checkbox.getAttribute('checked'));
  }

  public async checkRememberMe(): Promise<void> {
    const rememberMeCheckbox = this.resolveChild(Child.REMEMBER_ME_CHECKBOX);

    const isRememberMeChecked = await this.rememberMeIsChecked();
    if (!isRememberMeChecked) {
      await rememberMeCheckbox.click();
    }
  }

  public async uncheckRememberMe(): Promise<void> {
    const rememberMeCheckbox = this.resolveChild(Child.REMEMBER_ME_CHECKBOX);

    const isRememberMeChecked = await this.rememberMeIsChecked();
    if (isRememberMeChecked) {
      await rememberMeCheckbox.click();
    }
  }

  public async signIn(username: string, password: string, rememberMe: boolean = false): Promise<void> {
    const usernameInput = this.resolveChild(Child.USERNAME_INPUT);
    const passwordInput = this.resolveChild(Child.PASSWORD_INPUT);
    const submitButton = this.resolveChild(Child.SUBMIT_BUTTON);

    await usernameInput.sendKeys(username);
    await passwordInput.sendKeys(password);
    const isCheckboxVisible = await this.isChildVisible(Child.REMEMBER_ME_CHECKBOX);
    if (isCheckboxVisible) {
      if (rememberMe) {
        await this.checkRememberMe();
      } else {
        await this.uncheckRememberMe();
      }
    }
    await submitButton.click();

    const previousWaitForAngular = await browser.waitForAngularEnabled();
    await browser.waitForAngularEnabled(false);
    await browser.wait(
      async () => {
        const homeIsPresent = await this.authenticatedUserPage.isPresent();
        const alertIsVisible = await this.isChildVisible(Child.ALERT);
        return homeIsPresent || alertIsVisible;
      },
      30000 /* big performance problem */,
      'Timed out waiting for either an error message or the landing page.'
    );
    await browser.waitForAngularEnabled(previousWaitForAngular);
  }

  protected resolveChild(id: Child): ElementFinder {
    switch (id) {
      case Child.ALERT:
        return element
          .all(by.css('app-alerts .alert'))
          .filter(e => e.isDisplayed())
          .first();
      case Child.FORGOT_PASSWORD_LINK:
        return this.container.element(by.cssContainingText('.forgot-text a', 'Forgot password?'));
      case Child.FORGOT_USERNAME_LINK:
        return this.container.element(by.cssContainingText('.forgot-text a', 'Forgot username?'));
      case Child.HELP_LINK:
        return this.container.element(by.css('.help-text a'));
      case Child.PASSWORD_INPUT:
        return this.container.element(by.css('#passwordin'));
      case Child.PASSWORD_TOGGLE_BUTTON:
        return this.container.all(by.css('.show-class, .hide-class')).first();
      case Child.PASSWORD_INPUT_MESSAGES:
        return this.container.element(by.css('app-input-messages:nth-of-type(2)'));
      case Child.REGISTER_LINK:
        return this.container.element(by.css('a[href="/register"]'));
      case Child.REMEMBER_ME_CHECKBOX:
        return this.container.element(by.css('label[for="remember-me"]'));
      case Child.SUBMIT_BUTTON:
        return this.container.element(by.css('.submit-action button'));
      case Child.USERNAME_INPUT:
        return this.container.element(by.css('#useridin'));
      case Child.USERNAME_INPUT_MESSAGES:
        return this.container.element(by.css('app-input-messages:nth-of-type(1)'));
      default:
        throw new Error('Child not defined.');
    }
  }
}
