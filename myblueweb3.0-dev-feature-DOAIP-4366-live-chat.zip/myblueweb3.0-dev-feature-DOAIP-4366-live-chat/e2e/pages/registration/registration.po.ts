import { by, element, ElementFinder } from 'protractor';
import { NavigablePageObject } from '../../testing/page-object';

enum Child {}

export class RegistrationPage extends NavigablePageObject<Child> {
  public Child = Child;

  constructor() {
    super('/register', element.all(by.css('app-core-register > div')).first());
  }

  protected resolveChild(child: Child): ElementFinder {
    throw new Error('Method not implemented.');
  }
}
