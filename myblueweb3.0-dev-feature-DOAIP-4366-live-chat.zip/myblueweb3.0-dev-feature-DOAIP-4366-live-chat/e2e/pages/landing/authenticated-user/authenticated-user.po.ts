import { by, element, ElementFinder } from 'protractor';
import { NavigablePageObject } from '../../../testing/page-object';

enum Child {}

export class AuthenticatedUserPage extends NavigablePageObject<Child> {
  public Child = Child;

  constructor() {
    super('/home', element(by.css('app-authenticated-home')));
  }

  protected resolveChild(child: Child): ElementFinder {
    throw new Error('Method not implemented.');
  }
}
