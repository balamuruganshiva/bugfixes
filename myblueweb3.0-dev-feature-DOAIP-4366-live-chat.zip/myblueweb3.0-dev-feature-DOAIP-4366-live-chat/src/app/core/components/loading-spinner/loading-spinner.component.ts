import { Component, Input, NgZone, OnDestroy, ViewEncapsulation } from '@angular/core';
import { Subscription } from 'rxjs';
import { LoadingSpinnerService } from './loading-spinner.service';

@Component({
  selector: 'app-loading-spinner',
  templateUrl: './loading-spinner.component.html',
  styleUrls: ['./loading-spinner.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LoadingSpinnerComponent implements OnDestroy {
  // tslint:disable-next-line: variable-name max-line-length
  private _template = `<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>`;

  // tslint:disable-next-line:variable-name
  private _loadingText = '';

  // tslint:disable-next-line:variable-name
  private _showSpinner = false;

  // tslint:disable-next-line:variable-name
  private _threshold = 500;

  // tslint:disable-next-line:variable-name
  private _timeout = 0;

  // tslint:disable-next-line:variable-name
  private _zIndex = 9999;

  @Input()
  public set zIndex(value: number) {
    this._zIndex = value;
  }

  public get zIndex(): number {
    return this._zIndex;
  }

  @Input()
  public set template(value: string) {
    this._template = value;
  }

  public get template(): string {
    return this._template;
  }

  @Input()
  public set loadingText(value: string) {
    this._loadingText = value;
  }

  public get loadingText(): string {
    return this._loadingText;
  }

  @Input()
  public set threshold(value: number) {
    this._threshold = value;
  }

  public get threshold(): number {
    return this._threshold;
  }

  @Input()
  public set timeout(value: number) {
    this._timeout = value;
  }

  public get timeout(): number {
    return this._timeout;
  }

  public isOpacityUnsetSupported = true;
  public subscription: Subscription;

  public get showSpinner(): boolean {
    return this._showSpinner;
  }

  public set showSpinner(showSpinner: boolean) {
    this.ngZone.run(() => {
      this._showSpinner = showSpinner;
    });
  }

  constructor(private ngZone: NgZone, private spinnerService: LoadingSpinnerService) {
    this.createServiceSubscription();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  createServiceSubscription() {
    let thresholdTimer: number;
    let timeoutTimer: number;

    this.subscription = this.spinnerService.getMessage().subscribe(show => {
      if (show) {
        if (thresholdTimer) {
          return;
        }

        this.ngZone.runOutsideAngular(() => {
          thresholdTimer = window.setTimeout(() => {
            thresholdTimer = null;
            this.showSpinner = show;

            if (this.timeout !== 0) {
              timeoutTimer = window.setTimeout(() => {
                timeoutTimer = null;
              }, this.timeout);
            }
          }, this.threshold);
        });
      } else {
        if (thresholdTimer) {
          clearTimeout(thresholdTimer);
          thresholdTimer = null;
        }
        if (timeoutTimer) {
          clearTimeout(timeoutTimer);
        }
        timeoutTimer = null;
        this.showSpinner = false;
      }
    });
  }
}
