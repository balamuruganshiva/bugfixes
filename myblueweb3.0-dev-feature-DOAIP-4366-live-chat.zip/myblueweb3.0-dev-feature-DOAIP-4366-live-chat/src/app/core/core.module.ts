import { NgModule, Optional, SkipSelf } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { NgxMaskModule } from 'ngx-mask';
import { reducers } from '../app.reducer';
import { LoadingSpinnerModule } from './components/loading-spinner';

/**
 * Hosts singletons that are used througout the application, such as:
 *   - Services without a more appropriate parent feature module
 *   - Components only used in the template of AppComponent
 *   - Providers from third-party libraries (imported via ```forRoot()```)
 *   - HTTP interceptors
 */
@NgModule({
  imports: [
    BrowserAnimationsModule /* Keep this as first import */,
    EffectsModule.forRoot([]),
    NgIdleKeepaliveModule.forRoot(),
    NgxMaskModule.forRoot({ showMaskTyped: true }),
    StoreModule.forRoot(reducers),
    LoadingSpinnerModule.forRoot()
  ],
  exports: [LoadingSpinnerModule],
  declarations: [],
  providers: []
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error('CoreModule has already been loaded. Import it from AppModule only.');
    }
  }
}
