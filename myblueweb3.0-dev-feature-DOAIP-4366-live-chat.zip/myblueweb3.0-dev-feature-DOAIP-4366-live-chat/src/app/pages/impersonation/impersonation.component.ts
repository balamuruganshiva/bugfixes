import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalService } from '../../shared/services/global.service';
import { AlertService, AuthService } from '../../shared/shared.module';
import { ImpersonationService } from './impersonation.service';

@Component({
  selector: 'app-impersonation',
  templateUrl: './impersonation.component.html',
  styleUrls: ['./impersonation.component.scss']
})
export class ImpersonationComponent implements OnInit, OnDestroy {
  isApiCalled = false;
  impersonationAccessError: string;
  useridin: string;
  errorFlag = false;

  constructor(
    private impersonationService: ImpersonationService,
    public authService: AuthService,
    private alertService: AlertService,
    private router: Router,
    private route: ActivatedRoute,
    private globalService: GlobalService
  ) { }

  ngOnInit() {
    try {
      let user = this.route.snapshot.params.useridin;
      sessionStorage.setItem('key', null);
      this.alertService.clearError();
      const imperPayload = decodeURIComponent(user) + '';
      const req = {imperPayload};
      this.impersonationService.impersonation(req).subscribe(
        response => {
          if (response.scopename === 'AUTHENTICATED-AND-VERIFIED' && response.migrationtype === 'NONE') {
            this.impersonationService.impersonationPostLogin().then(respPostLogin => {
              if (respPostLogin && respPostLogin.error !== true) {
                sessionStorage.setItem('postLoginInfo', JSON.stringify(respPostLogin));
                this.impersonationService.hideSpinnerLoading();
                if (response) {
                  this.globalService.setAdobe();
                  console.log('Redirecting from Impersonation to Home : Impersonation Component ');
                  this.globalService.initIsSearchEnabled();
                  this.globalService.initTelehealthEligibility();
                  this.router.navigate(['/home']);
                }
              }
            }, err => {
              console.log('Error in postLogin API, displaying impersonation error', err);
              this.router.navigate(['/impersonation/error']);
            });
          } else {
            console.log('ID doesnt belong to a AV user');
            this.router.navigate(['/impersonation/error']);
          }
        },
        err => {
          this.isApiCalled = false;
          if (err.status >= 403) {
            console.log(err.status);
            console.log(err.error);
            // let message = err.error.displaymessage;
            const message = err.error;
            console.log(message);
            this.impersonationAccessError = message;
            this.router.navigate(['/impersonation/error']);
            console.log('Redirecting from Impersonation to Error page');
          } else {
            console.log('Impersonation error response');
          }
        }
      );


    } catch (exception) {
      this.router.navigate(['/impersonation/error']);
      console.error('Error in decryption, So redirecting to Error Page');
    }
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }
}
