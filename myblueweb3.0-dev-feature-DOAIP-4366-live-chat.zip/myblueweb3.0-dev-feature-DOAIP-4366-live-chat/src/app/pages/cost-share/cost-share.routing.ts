import { RouterModule, Routes } from '@angular/router';
import { CostShareComponent } from './cost-share.component';

const COSTSHARE_ROUTER: Routes = [
  {
    path: '',
    component: CostShareComponent,
    data: {
      breadcrumb: 'Cost-Share Assistance'
    }
  }
];

export const CostShareRouter = RouterModule.forChild(COSTSHARE_ROUTER);
