import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CostShareComponent } from './cost-share.component';
import { CostShareRouter } from './cost-share.routing';
import { CostShareService } from './cost-share.service';

@NgModule({
  imports: [CommonModule, CostShareRouter],
  declarations: [CostShareComponent],
  providers: [CostShareService]
})
export class CostShareModule {}
