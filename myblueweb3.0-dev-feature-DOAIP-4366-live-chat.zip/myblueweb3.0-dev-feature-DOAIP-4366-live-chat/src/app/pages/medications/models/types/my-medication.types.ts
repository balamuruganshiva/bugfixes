export type DependantRelationShipType = 'Subscriber' | 'Spouse' | 'Dependent';
