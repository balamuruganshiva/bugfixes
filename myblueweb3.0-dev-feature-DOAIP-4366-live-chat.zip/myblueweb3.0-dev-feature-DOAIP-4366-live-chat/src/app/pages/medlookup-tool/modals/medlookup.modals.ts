export interface MedictionsSearchResultsModel {
  pageLimit: number;
  currentPage: number;
  totalPages: number;
  medicationCount: string;
  medication: MedictionsListModel[];
  isNumberedMedsAvailable: boolean;
}

interface MedictionsListModel {
  medicationID: string;
  medicationName: string;
}

export interface MedicationsDetailsModel {
  medicationName: string;
  dosage: MedicationsDosageModel[];
  coveredAlternateMedications: CoveredAlterMedicationModel[];
}

interface MedicationsDosageModel {
  id: string;
  name: string;
  coverageType: string;
  coverageDetails: string;
  notes: MedicationsDosageNotesModel[];
}

interface MedicationsDosageNotesModel {
  title: string;
  description: string;
}

interface CoveredAlterMedicationModel {
  medicationID: string;
  medication: string;
}
