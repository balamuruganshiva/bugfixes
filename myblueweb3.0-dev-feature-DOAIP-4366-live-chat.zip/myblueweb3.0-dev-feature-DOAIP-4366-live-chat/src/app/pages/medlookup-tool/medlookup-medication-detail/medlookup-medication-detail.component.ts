import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { _throw } from 'rxjs/observable/throw';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { MEDLOOKUP_TIER_PLAN_INFORMATION } from '../medlookup.constants';
import { MedicationsDetailsModel, MedictionsSearchResultsModel } from '../modals/medlookup.modals';
import { MedLookUpMedDetailsService } from './medlookup-medication-detail.service';
declare let $: any;

@Component({
  selector: 'medlookup-medication-detail',
  templateUrl: './medlookup-medication-detail.component.html',
  styleUrls: ['./medlookup-medication-detail.component.scss']
})
export class MedLookupMedDetailsComponent implements OnInit, OnDestroy {
  showPrefPromo = false;
  public selectedMedicationID: string;
  public hasShowMore = true;
  public isMobileView = false;
  public medSearch: any[];
  public tierInformation: any[] = MEDLOOKUP_TIER_PLAN_INFORMATION;
  public meddetailsDosage: any[];
  public meddetailsAlternativeMed: any[];
  public hasAlternativeMed: boolean;
  public medicationName: any;
  public medicationTypeName: any;
  public medicationType: any;
  public totalPages = 1;
  public medicationsData: MedictionsSearchResultsModel;
  public q = '';
  clickedItem: any;
  toggleFlag = false;
  public tierInofList: string;
  public tierDescription: string;
  public tierName = sessionStorage.getItem('tierName');
  public tierId: any;
  foundError = false;
  public isTierErrorFound: boolean;
  medTierId: any;

  constructor(
    private router: Router,
    private medLookUpMedDetailsService: MedLookUpMedDetailsService,
    private route: ActivatedRoute,
    private authHttp: AuthHttp
  ) {}

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.isMobileView = event.target.innerWidth <= 992;
  }

  ngOnInit() {
    this.setTierId();
    // this.tierId = sessionStorage.getItem('tierNumber');

    this.isTierErrorFound = JSON.parse(sessionStorage.getItem('isTierErrorFound'));
    this.route.queryParams.subscribe(params => {
      this.selectedMedicationID = params.selectedMedicationID;
      this.q = params.searchKeyword;
      this.medicationTypeName = params.medicationTypeName;
    });
    this.getIndividualMedDetails(this.selectedMedicationID);

    this.tierInformation.forEach(item => {
      if (item.tier === this.tierName) {
        this.tierInofList = item.subitems;
        this.tierDescription = item.description;
      }
    });
  }

  setTierId() {
    if (!sessionStorage.getItem('tierNumber')) {
      const tierMappingData = JSON.parse(sessionStorage.getItem('tierMappingData'));
      if (tierMappingData) {
        tierMappingData.forEach(item => {
          if (item.planTier === sessionStorage.getItem('tierName')) {
            this.tierId = item.planTierId;
            sessionStorage.setItem('tierNumber', item.planTierId);
          }
        });
      }
    }
  }

  getIndividualMedDetails(selectedId) {
    this.medTierId = this.tierId ? this.tierId : sessionStorage.getItem('tierNumber');
    this.medLookUpMedDetailsService.getIndividualMedicationDetails(selectedId, this.medTierId).subscribe(
      (data: MedicationsDetailsModel) => {
        this.medicationName = data.medicationName;
        this.meddetailsDosage = data.dosage;
        this.foundError = !data.medicationName ? true : false;
        data.coveredAlternateMedications
          ? ((this.hasAlternativeMed = true), (this.meddetailsAlternativeMed = data.coveredAlternateMedications))
          : (this.hasAlternativeMed = false);
      },
      error => {
        this.foundError = true;
        return _throw(error);
      }
    );
  }

  openTierModal() {
    $('#openOtherPartySiteWithExternalLink').modal('open');
  }
  closeModals() {
    $('#openOtherPartySiteWithExternalLink').modal('close');
  }

  navigateToAlternativeMedDetails(medicationId, medicationName) {
    this.router.navigate(['/med-lookup/med-search'], {
      queryParams: {
        searchKeyword: medicationName,
        medicationType: this.medicationType,
        medicationTypeName: 'Medications',
        selectedMedicationID: medicationId
      }
    });
  }

  toggleMedDetails(dosageItem) {
    this.toggleFlag = this.clickedItem && this.clickedItem === dosageItem.id ? !this.toggleFlag : true;

    this.clickedItem = dosageItem.id;
  }

  navigateToPublicMedlookup() {
    const medicationUrl = 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav';
    window.open(medicationUrl, '_blank');
  }

  navigateUrl(url) {
    this.router.navigate([url]);
  }

  ngOnDestroy() {}
}
