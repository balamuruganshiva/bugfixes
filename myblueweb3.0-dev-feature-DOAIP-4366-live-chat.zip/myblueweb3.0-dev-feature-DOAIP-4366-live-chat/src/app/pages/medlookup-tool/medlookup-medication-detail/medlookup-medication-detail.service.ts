import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService, ConstantsService } from '../../../shared/shared.module';
import { MedicationsDetailsModel } from '../modals/medlookup.modals';


@Injectable()

export class MedLookUpMedDetailsService {
  constructor(
    public http: HttpClient,
    public constantService: ConstantsService,
    public authService: AuthService,
    private authHttp: AuthHttp,
    ) {}

  getIndividualMedicationDetails(medId, tierId): Observable<MedicationsDetailsModel> {
    const url = `${this.constantService.medlookupDetailUrl}/medicationdetails?medicationID=${medId}&planTier=${tierId}`;

    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: `Bearer ${this.authService.getAuthToken()}`,
        uitxnid: 'WEB_v3.0_' + this.authHttp.uuid()
      })
    };
    return this.authHttp.get(url, httpOptions, true).pipe(map(data => data as MedicationsDetailsModel));
  }
}
