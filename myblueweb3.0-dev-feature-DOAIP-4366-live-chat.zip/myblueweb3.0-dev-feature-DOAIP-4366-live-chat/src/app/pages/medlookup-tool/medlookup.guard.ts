import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class MedLookupGuard implements CanActivate {
  //formulary variables
  memberuseridin: string;
  subscriberId: string;
  memberSuffix: string;
  groupUaCvg: string;
  isNPFformularyFlag = false;
  tierNumber: string;

  constructor(
    private router: Router
  ) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (sessionStorage.getItem('isTierErrorFound')) {
      return true;
    } else {
      this.router.navigate(['/home']);
      return false;
    }
  }
}
