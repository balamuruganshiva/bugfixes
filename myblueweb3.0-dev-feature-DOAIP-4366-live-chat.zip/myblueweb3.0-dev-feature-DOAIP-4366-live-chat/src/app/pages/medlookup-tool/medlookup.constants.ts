export const MEDLOOKUP_HOMEPAGE_MEDICATION_LISTS = [
  {
    id: 'all_medications',
    label: 'All Medications',
    url: '/med-lookup/med-search'
  },
  {
    id: 'non_covered_medications',
    label: 'Non-Covered Medications'
  },
  {
    id: 'prior_authorization_medications',
    label: 'Medications That Require Prior Authorization'
  }
];

export const MEDLOOKUP_TIER_PLAN_INFORMATION = [
  {
    tier: '2-Tier',
    description : 'Some exceptions may apply. For example, Tier 2 could include some generic medications in addition to brand-name medications.',
    subitems : [
      'Tier 1: Generics',
      'Tier 2: Brands'
    ],
  },
  {
    tier: '3-Tier',
    description : 'Some exceptions may apply. For example, Tier 2 could include some generic medications in addition to preferred brand-name medications.',
    subitems : [
      'Tier 1: Generics',
      'Tier 2: Preferred Brands',
      'Tier 3: Non-Preferred Brands'
    ],
  },
  {
    tier: '4-Tier',
    description : 'Some exceptions may apply. For example, Tier 3 could include some non-preferred generic medications in addition to preferred brand-name medications.',
    subitems : [
      'Tier 1: Preferred Generics',
      'Tier 2: Non-Preferred Generics',
      'Tier 3: Preferred Brands',
      'Tier 4: Non-Preferred Brands',
    ],
  },
  {
    tier: '5-Tier',
    description : 'Some exceptions may apply. For example, Tier 2 could include some generic medications in addition to preferred brand-name medications.',
    subitems : [
      'Tier 1: Generics',
      'Tier 2: Preferred Brands',
      'Tier 3: Non-Preferred Brands',
      'Tier 4: Preferred Brand Specialty',
      'Tier 5: Non-Preferred Brand Specialty',
    ],
  },
  {
    tier: '6-Tier',
    description : 'Some exceptions may apply. For example, Tier 3 could include some non-preferred generic medications in addition to preferred brand-name medications.',
    subitems : [
      'Tier 1: Preferred Generics',
      'Tier 2: Non-Preferred Generics',
      'Tier 3: Preferred Brands',
      'Tier 4: Non-Preferred Brands',
      'Tier 5: Preferred Brand Specialty',
      'Tier 6: Non-Preferred Brand Specialty',
    ],
  },
]

export const MEDLOOKUP_KEYWORD_BUTTONS = [
  {
    id: 'all_numbers',
    label: '#'
  },
  {
    id: 'a',
    label: 'A'
  },
  {
    id: 'b',
    label: 'B'
  },
  {
    id: 'c',
    label: 'C'
  },
  {
    id: 'd',
    label: 'D'
  },
  {
    id: 'e',
    label: 'E'
  },
  {
    id: 'f',
    label: 'F'
  },
  {
    id: 'g',
    label: 'G'
  },
  {
    id: 'h',
    label: 'H'
  },
  {
    id: 'i',
    label: 'I'
  },
  {
    id: 'j',
    label: 'J'
  },
  {
    id: 'k',
    label: 'K'
  },
  {
    id: 'l',
    label: 'L'
  },
  {
    id: 'm',
    label: 'M'
  },
  {
    id: 'n',
    label: 'N'
  },
  {
    id: 'o',
    label: 'O'
  },
  {
    id: 'p',
    label: 'P'
  },
  {
    id: 'q',
    label: 'Q'
  },
  {
    id: 'r',
    label: 'R'
  },
  {
    id: 's',
    label: 'S'
  },
  {
    id: 't',
    label: 'T'
  },
  {
    id: 'u',
    label: 'U'
  },
  {
    id: 'v',
    label: 'V'
  },
  {
    id: 'w',
    label: 'W'
  },
  {
    id: 'x',
    label: 'X'
  },
  {
    id: 'y',
    label: 'Y'
  },
  {
    id: 'z',
    label: 'Z'
  }
];
