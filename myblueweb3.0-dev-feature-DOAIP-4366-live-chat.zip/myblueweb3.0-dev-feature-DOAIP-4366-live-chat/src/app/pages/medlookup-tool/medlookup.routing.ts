import { RouterModule, Routes } from '@angular/router';
import { AuthenticatedLayoutComponent } from '../../shared/layouts/AuthenticatedLayoutComponent/AuthenticatedLayout.component';
import { MedLookupComponent } from './medlookup-home/medlookup.component';
import { MedLookupMedDetailsComponent } from './medlookup-medication-detail/medlookup-medication-detail.component';
import { MedLookupSearchComponent } from './medlookup-search-results/medlookup-search-results.component';
import { MedLookupGuard } from './medlookup.guard';

const REGISTER_ROUTER: Routes = [
  {
    path: '',
    component: AuthenticatedLayoutComponent,
    canActivate: [MedLookupGuard],
    children: [
      {
        path: '',
        component: MedLookupComponent
      },
      {
        path: 'med-search',
        data: {
          breadcrumb: 'Search Results'
        },
        children: [
          {
            path: '',
            component: MedLookupSearchComponent,
            data: {
              breadcrumb: 'Search Results'
            }
          },
          {
            path: 'med-search-details',
            component: MedLookupMedDetailsComponent,
            data: {
              breadcrumb: 'Medication Details'
            }
          }
        ]
      }
    ]
  }
];

export const medlookupHomeRouter = RouterModule.forChild(REGISTER_ROUTER);
