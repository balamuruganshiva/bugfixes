import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MEDLOOKUP_HOMEPAGE_MEDICATION_LISTS, MEDLOOKUP_KEYWORD_BUTTONS } from '../medlookup.constants';

@Component({
  selector: 'med-lookup',
  templateUrl: './medlookup.component.html',
  styleUrls: ['./medlookup.component.scss']
})
export class MedLookupComponent implements OnInit, OnDestroy {
  showPrefPromo = false;
  public hasShowMore = true;
  public isMobileView = false;
  public homepageMedListLabels: any[] = MEDLOOKUP_HOMEPAGE_MEDICATION_LISTS;
  public quickKeyWordSearch: any[] = MEDLOOKUP_KEYWORD_BUTTONS;
  public tierId: any;
  public isTierErrorFound: boolean;

  constructor(private router: Router) {}

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.isMobileView = event.target.innerWidth <= 992;
  }

  ngOnInit() {
    this.tierId = sessionStorage.getItem('tierNumber');
    this.isTierErrorFound = JSON.parse(sessionStorage.getItem('isTierErrorFound'));
  }

  ngDoCheck(){
    if(sessionStorage.getItem('isTierErrorFound')) {
    this.isTierErrorFound = JSON.parse(sessionStorage.getItem('isTierErrorFound'));
    }
  }

  navigateUrl(url) {
    this.router.navigate([url]);
  }

  navigateToPublicMedlookup() {
    const medicationUrl = 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav';
    window.open(medicationUrl, '_blank');
  }

  navigateToSearchResults(medListId, medListName) {
    this.router.navigate(['/med-lookup/med-search'], {
      queryParams: {
        searchKeyword: '',
        medicationType: medListId,
        medicationTypeName: medListName
      }
    });
  }

  ngOnDestroy() {}
}
