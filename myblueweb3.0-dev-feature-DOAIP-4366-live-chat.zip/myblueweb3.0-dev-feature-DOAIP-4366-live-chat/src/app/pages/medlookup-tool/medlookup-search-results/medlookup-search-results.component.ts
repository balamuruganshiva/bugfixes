import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { _throw } from 'rxjs/observable/throw';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { MEDLOOKUP_KEYWORD_BUTTONS, MEDLOOKUP_TIER_PLAN_INFORMATION } from '../medlookup.constants';
import { MedictionsSearchResultsModel } from '../modals/medlookup.modals';
import { MedLookupSearchService } from './medlookup-search-results.service';
declare let $: any;

@Component({
  selector: 'medlookup-search-results',
  templateUrl: './medlookup-search-results.component.html',
  styleUrls: ['./medlookup-search-results.component.scss']
})
export class MedLookupSearchComponent implements OnInit, OnDestroy {
  showPrefPromo = false;
  public hasShowMore = true;
  public isMobileView = false;
  public medSearchResults: any[];
  public medlookupGlossaryItems: any[] = MEDLOOKUP_KEYWORD_BUTTONS;
  public tierInformation: any[] = MEDLOOKUP_TIER_PLAN_INFORMATION;
  public medicationType: any;
  public medicationTypeName: string;
  public totalPages = 1;
  public medicationsData: MedictionsSearchResultsModel;
  public q = '';
  public totalMedicationCount: string;
  public hasLoadMore = true;
  public selectedMedListName: string;
  public isGlossarySearch = false;
  public tierInofList: string;
  public tierDescription: string;
  public tierName = sessionStorage.getItem('tierName');
  foundError = false;
  public tierId: any;
  public isTierErrorFound: boolean;

  constructor(
    private router: Router,
    private medLookupSearchService: MedLookupSearchService,
    private authHttp: AuthHttp,
    private route: ActivatedRoute
  ) {}

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.isMobileView = event.target.innerWidth <= 992;
  }

  ngOnInit() {
    this.tierId = sessionStorage.getItem('tierNumber');
    this.isTierErrorFound = JSON.parse(sessionStorage.getItem('isTierErrorFound'));

    sessionStorage.setItem('queryParamItem', JSON.stringify(this.route.snapshot.queryParams));
    this.route.queryParams.subscribe(params => {
      this.q = params.searchKeyword;
      this.medicationType = params.medicationType;
      this.medicationTypeName = params.medicationTypeName;
      this.selectedMedListName = params.medicationTypeName ? params.medicationTypeName : 'All Medications';
    });

    this.getDefualtMedication();
    this.tierInformation.forEach(item => {
      if (item.tier === this.tierName) {
        this.tierInofList = item.subitems;
        this.tierDescription = item.description;
      }
    });
  }

  openTierModal() {
    $('#openOtherPartySiteWithExternalLink').modal('open');
  }
  closeModals() {
    $('#openOtherPartySiteWithExternalLink').modal('close');
  }

  getDefualtMedication() {
    const q = this.q ? this.q : '';
    this.totalPages = 1;
    this.medLookupSearchService.getMedicationSearchList(this.medicationType, this.totalPages, q).subscribe(
      (data: MedictionsSearchResultsModel) => {
        if (!data.isNumberedMedsAvailable && !this.isGlossarySearch) {
          this.medlookupGlossaryItems = this.medlookupGlossaryItems.slice(1);
        }
        this.foundError = false;
        this.totalMedicationCount = data.medicationCount;
        this.medicationsData = data;
        this.medSearchResults = data.medication;
        Number(data.medicationCount) < 20 ? (this.hasLoadMore = false) : (this.hasLoadMore = true);
      },
      error => {
        this.foundError = true;
        return _throw(error);
      }
    );
  }

  loadMoreMedications() {
    const q = this.q ? this.q : '';
    this.totalPages += 1;
    this.medLookupSearchService.getMedicationSearchList(this.medicationType, this.totalPages, q).subscribe(
      (data: MedictionsSearchResultsModel) => {
        this.medicationsData = data;
        this.foundError = false;
        data.medication.forEach(element => {
          this.medSearchResults.push(element);
          data.currentPage === data.totalPages ? (this.hasLoadMore = false) : (this.hasLoadMore = true);
        });
      },
      error => {
        this.foundError = true;
        return _throw(error);
      }
    );
  }

  glossaryItemSearch(searchItem, visibleFlag) {
    if(visibleFlag){
      this.q = searchItem;
      this.router.navigate(['/med-lookup/med-search'], {
        queryParams: {
          searchKeyword: searchItem,
          medicationType: this.medicationType,
          medicationTypeName: this.medicationTypeName
        },
        queryParamsHandling: 'merge'
      });
    }
  }

  navigateToPublicMedlookup() {
    const medicationUrl = 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav';
    window.open(medicationUrl, '_blank');
  }

  navigateUrl(medicationId, medicationName) {
    this.router.navigate(['/med-lookup/med-search/med-search-details'], {
      queryParams: {
        searchKeyword: medicationName,
        medicationType: this.medicationType,
        medicationTypeName: this.medicationTypeName,
        selectedMedicationID: medicationId
      }
    });
  }

  ngOnDestroy() {}
}
