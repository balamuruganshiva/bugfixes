import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService, ConstantsService } from '../../../shared/shared.module';
import { MedictionsSearchResultsModel } from '../modals/medlookup.modals';


@Injectable()

export class MedLookupSearchService {
  constructor(
    public http: HttpClient,
    public constantService: ConstantsService,
    public authService: AuthService,
    private authHttp: AuthHttp,
    ) {}

  getMedicationSearchList(medication_type, pages, q): Observable<MedictionsSearchResultsModel> {
    if(medication_type===undefined) {
      medication_type = 'all_medications'
    }
    const url = `${this.constantService.medlookupUrl}?medicationType=${medication_type}&medicationKeyword=${encodeURIComponent(q)}&page=${pages}`;

    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: `Bearer ${this.authService.getAuthToken()}`,
        uitxnid: 'WEB_v3.0_' + this.authHttp.uuid()
      })
    };
    return this.authHttp.get(url, httpOptions, true).pipe(map(data => data as MedictionsSearchResultsModel));
  }
}
