import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../../shared/shared.module';
import { MedLookupComponent } from './medlookup-home/medlookup.component';
import { MedLookupMedDetailsComponent } from './medlookup-medication-detail/medlookup-medication-detail.component';
import { MedLookUpMedDetailsService } from './medlookup-medication-detail/medlookup-medication-detail.service';
import { MedLookupSearchBarComponent } from './medlookup-search-bar/medlookup-search-bar.component';
import { MedLookupSearchComponent } from './medlookup-search-results/medlookup-search-results.component';
import { MedLookupSearchService } from './medlookup-search-results/medlookup-search-results.service';
import { MedLookupStaticLinksComponent } from './medlookup-static-links/medlookup-static-links.component';
import { MedLookupGuard } from './medlookup.guard';
import { medlookupHomeRouter } from './medlookup.routing';

@NgModule({
  imports: [
    CommonModule,
    medlookupHomeRouter,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule,
    StorageServiceModule,
    SharedModule
  ],
  declarations: [
    MedLookupComponent,
    MedLookupSearchComponent,
    MedLookupMedDetailsComponent,
    MedLookupSearchBarComponent,
    MedLookupStaticLinksComponent
  ],
  providers: [MedLookupSearchService, MedLookUpMedDetailsService, MedLookupGuard],
  exports: [MedLookupSearchBarComponent, MedLookupStaticLinksComponent]
})
export class MedlookupHomeModule {}
