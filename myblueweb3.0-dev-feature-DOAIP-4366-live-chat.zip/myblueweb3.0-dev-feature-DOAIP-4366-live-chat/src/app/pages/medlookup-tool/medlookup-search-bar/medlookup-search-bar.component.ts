import { Component, HostListener, Input, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { HeaderService } from '../../../shared/layouts/header/header.service';
import { MedLookupSearchSuggestionService } from './medlookup-search-bar.service';
declare var $: any;

@Component({
  selector: 'medlookup-search-bar',
  templateUrl: './medlookup-search-bar.component.html',
  styleUrls: ['./medlookup-search-bar.component.scss'],
  providers: [MedLookupSearchSuggestionService]
})
export class MedLookupSearchBarComponent implements OnInit, OnDestroy {
  @Input() mainMedlookupPage = false;
  @Input() medResultsPage = false;
  @Input() medDetailsPage = false;
  @Input() placeHolderText: string;

  results: object;
  searchTerm$ = new Subject<string>();
  searchKeyword: string;
  isSearchSuggestionActive = false;
  medicationType = 'all_medications';
  medicationTypeName = 'All Medications';
  public isTierErrorFound: boolean;
  tierNumber: any;
  tierName: any;

  constructor(
    private medLookUpSearchBarService: MedLookupSearchSuggestionService,
    private router: Router,
    public headerService: HeaderService,
    private route: ActivatedRoute
    ) {
    this.isTierErrorFound = JSON.parse(sessionStorage.getItem('isTierErrorFound'));
    if(!this.isTierErrorFound) {
    this.medLookUpSearchBarService.search(this.searchTerm$).subscribe(data => {
      data.medication.length !== 0 ? (this.results = data.medication) : (this.isSearchSuggestionActive = false);
    });
    }
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick($event) {
    $event.stopPropagation();
    this.isSearchSuggestionActive = false;
  }

  ngOnInit() {
    this.isTierErrorFound = JSON.parse(sessionStorage.getItem('isTierErrorFound'));
    this.tierName = sessionStorage.getItem("tierName");

    this.route.queryParams.subscribe(params => {
      this.medicationType = params.medicationType ? params.medicationType : this.medicationType;
      this.medicationTypeName = params.medicationTypeName ? params.medicationTypeName : this.medicationTypeName;
      if(params.searchKeyword === 'all_numbers') {
        this.searchKeyword = '';
        this.placeHolderText = '';
      } else {
      this.searchKeyword = params.searchKeyword || this.searchKeyword;
      }
    });
  }

  ngDoCheck(){
    if(sessionStorage.getItem('isTierErrorFound')) {
    this.isTierErrorFound = JSON.parse(sessionStorage.getItem('isTierErrorFound'));
    }
  }

  openTierModal() {
    $('#openOtherPartySiteWithExternalLink').modal('open');
  }
  closeModals() {
    $('#openOtherPartySiteWithExternalLink').modal('close');
  }


  searchInputText(event) {
    const searchText = event.target.value;
    searchText === '' || this.isTierErrorFound
      ? ((this.isSearchSuggestionActive = false), (this.results = null))
      : ((this.isSearchSuggestionActive = true), this.searchTerm$.next(searchText));
    this.searchKeyword = searchText;

    const current = $('.search-suggestion-list-selected');

    //Key Up
    if (event.which === 38) {
      event.preventDefault();
      const prev = current.prev('li');
      if (prev.length) {
        current.removeClass('search-suggestion-list-selected');
        prev.addClass('search-suggestion-list-selected');
      }
    }

    //Key Down
    if (event.which === 40) {
      event.preventDefault();
      const next = current.next('li');
      if (next.length) {
        current.removeClass('search-suggestion-list-selected');
        next.addClass('search-suggestion-list-selected');
      }
    }

    //backspace reset
    if (event.which === 8) {
      event.preventDefault();
      $('ul.search-suggestion-ul li:first-child').addClass('search-suggestion-list-selected');
    }

    //on clicking enter
    if (event.which === 13) {
      event.preventDefault();
      const medId = String($('.search-suggestion-list-selected span').attr('id')).replace(/\s/g, '');
      const medName = String($('.search-suggestion-list-selected span').text()).replace(/\s/g, '');
      if(!this.isTierErrorFound) {
      this.navigateToMedDetail(medId, medName);
      }
    }
  }

  searchKeyWord() {
    if(!this.isTierErrorFound) {
    this.router.navigate(['/med-lookup/med-search'], {
      queryParams: {
        searchKeyword: this.searchKeyword,
        medicationType: this.medicationType,
        medicationTypeName: this.medicationTypeName
      }
    });
    }
  }

  navigateToPublicMedlookup() {
    const medicationUrl = 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav';
    window.open(medicationUrl, '_blank');
  }

  navigateToMedDetail(medicationId, medicationName) {
    this.router.navigate(['/med-lookup/med-search/med-search-details'], {
      queryParams: {
        searchKeyword: medicationName,
        medicationType: this.medicationType,
        medicationTypeName: this.medicationTypeName,
        selectedMedicationID: medicationId
      }
    });
  }

  ngOnDestroy() {}
}
