import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService } from '../../../shared/services/auth.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { MedictionsSearchResultsModel } from '../modals/medlookup.modals';

@Injectable()
export class MedLookupSearchSuggestionService {
  constructor(
    public http: HttpClient,
    public constantService: ConstantsService,
    public authService: AuthService,
    private authHttp: AuthHttp,
    private route: ActivatedRoute
  ) {}

  search(searchTerms: Observable<string>) {
    let medicationType = 'all_medications';
    this.route.queryParams.subscribe(params => {
      medicationType = params.medicationType ? params.medicationType : medicationType;
    });
    return searchTerms
      .debounceTime(200)
      .distinctUntilChanged()
      .switchMap(searchItem => this.getMedicationSuggestionList(medicationType, 1, searchItem));
  }

  getMedicationSuggestionList(medicationType: string, pages: number, q: string): Observable<MedictionsSearchResultsModel> {
    const searchUrl = `${this.constantService.medlookupUrl}?medicationType=${medicationType}&medicationKeyword=${encodeURIComponent(q)}&page=${pages}`;

    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: `Bearer ${this.authService.getAuthToken()}`,
        uitxnid: 'WEB_v3.0_' + this.authHttp.uuid()
      })
    };
    return this.http.get(searchUrl, httpOptions).pipe(map(data => data as MedictionsSearchResultsModel));
  }
}
