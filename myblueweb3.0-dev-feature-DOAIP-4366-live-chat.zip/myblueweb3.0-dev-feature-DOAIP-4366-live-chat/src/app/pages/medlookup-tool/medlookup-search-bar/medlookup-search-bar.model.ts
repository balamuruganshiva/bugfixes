export interface MedictionsSuggestedListModel {
  pageLimit: number;
  currentPage: number;
  totalPages: number;
  medicationCount: string;
  medication: MedictionsListModel[];
  isNumberedMedsAvailable: boolean;
}

interface MedictionsListModel {
  medicationID: string;
  medicationName: string;
}
