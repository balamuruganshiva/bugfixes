import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService, ConstantsService } from '../../../shared/shared.module';

@Injectable()
export class MedLookUpStaticLinksService {
  public httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.authService.getAuthToken()}`,
      uitxnid: 'WEB_v3.0_' + this.authHttp.uuid()
    })
  };
  cachedData: any;

  constructor(
    public http: HttpClient,
    public constantService: ConstantsService,
    public authService: AuthService,
    private authHttp: AuthHttp
  ) {}

  getStaticLinksData() {
    const url = `${environment.serviceUrl}/medlookup/medicationpdflinks?
                    medicationPdfType=allPdfLinks&showMore=true`;

    return this.authHttp.get(url, this.httpOptions, true).pipe(map(data => data));
  }
}
