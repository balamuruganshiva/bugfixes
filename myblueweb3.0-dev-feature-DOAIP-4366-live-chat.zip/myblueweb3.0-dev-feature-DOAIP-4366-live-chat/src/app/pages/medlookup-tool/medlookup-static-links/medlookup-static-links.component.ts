import { Component, OnDestroy, OnInit } from '@angular/core';
import { _throw } from 'rxjs/observable/throw';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { MedLookUpStaticLinksService } from './medlookup-static-links.service';

@Component({
  selector: 'medlookup-static-links',
  templateUrl: './medlookup-static-links.component.html',
  styleUrls: ['./medlookup-static-links.component.scss'],
  providers: [MedLookUpStaticLinksService]
})
export class MedLookupStaticLinksComponent implements OnInit, OnDestroy {
  public externalLinks: any;
  public externalLinksCopy: any;
  public hasShowMore = true;
  public cachedData: any[];
  public tierName: any;
  tierNumber = sessionStorage.getItem('tierNumber');
  foundTierError: boolean;

  constructor(private medLookupStaticLinksService: MedLookUpStaticLinksService, private authHttp: AuthHttp) {}

  ngOnInit() {
    this.tierName = sessionStorage.getItem('tierName');

    this.cachedData = JSON.parse(sessionStorage.getItem('MedLookupStaticLinks'));
    if (this.cachedData) {
      this.externalLinks = this.cachedData;
      this.externalLinksCopy = this.cachedData;

      if (this.externalLinks[0].pdfCount > 4) {
        this.externalLinks = JSON.parse(JSON.stringify(this.externalLinksCopy));
        this.externalLinks[0].pdfData = this.externalLinks[0].pdfData.slice(0, 4);
      }
    } else {
      this.medLookupStaticLinksService.getStaticLinksData().subscribe(
        data => {
          sessionStorage.setItem('MedLookupStaticLinks', JSON.stringify(data));
          this.externalLinks = data;
          this.externalLinksCopy = data;

          if (this.externalLinks[0].pdfCount > 4) {
            this.externalLinks = JSON.parse(JSON.stringify(this.externalLinksCopy));
            this.externalLinks[0].pdfData = this.externalLinks[0].pdfData.slice(0, 4);
          }
        },
        error => {
          return _throw(error);
        }
      );
    }
  }

  showLess() {
    this.externalLinks[0].pdfData = this.externalLinks[0].pdfData.slice(0, 4);
    this.hasShowMore = true;
  }

  showMoreExternalLinks() {
    this.externalLinks = JSON.parse(JSON.stringify(this.externalLinksCopy));
    this.externalLinks[0].pdfData = this.externalLinks[0].pdfData.slice(0, this.externalLinks[0].length);
    this.hasShowMore = false;
  }

  ngOnDestroy() {}
}
