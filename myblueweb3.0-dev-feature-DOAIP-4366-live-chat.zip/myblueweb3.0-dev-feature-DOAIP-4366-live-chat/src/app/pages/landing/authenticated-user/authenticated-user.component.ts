import { DatePipe, TitleCasePipe } from '@angular/common';
import { AfterViewInit, ChangeDetectorRef, Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { delay, startWith } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { LineChartOptionsInterface } from '../../../shared/components/line-chart/line-chart.interface';
import { Finanical } from '../../../shared/models/finanical.model';
import { Image } from '../../../shared/models/image.model';
import { PharmacyLink, PostLoginInfo } from '../../../shared/models/postlogininfo.model';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService } from '../../../shared/services/auth.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { FadService } from '../../fad/fad.service';
import { RxDetailsRequestModelInterface } from '../../medications/models/interfaces/rx-details-model.interface';
import { RxDetailsRequestModel } from '../../medications/models/rx-details.model';
import { MyMedicationDetailsService } from '../../medications/myMedicationDetails/my-medication-details.service';
import { DeductiblesAccumsInterface } from '../../myded-co/models/interfaces/myded-co-info-model.interface';
import { MyDedCoService } from '../../myded-co/myded-co.service';
import { MEMBER_LINKS, QUICK_ACCESS_LINKS, TRACK_WIDGETS } from '../constants/homepage.constants';
import { HomePageInfoModel } from '../landing.model';
import { LandingService } from '../landing.service';

declare let $: any;

/* tslint:disable */
@Component({
  selector: 'app-authuser-landing',
  templateUrl: './authenticated-user.component.html',
  styleUrls: ['./authenticated-user.component.scss']
})
export class AuthUserLandingComponent implements OnInit, OnDestroy, AfterViewInit {
  PHARMACYURL: PharmacyLink[] = [];
  isRegisteredUser: boolean;
  isAuthentiactedUser: boolean;
  hide4Feb19Release = false;
  memberInfo: HomePageInfoModel;
  carouselItemDetails: Image[] = [];
  bannerImage: {} = '';
  doctorData: {};
  medicationData: {};
  ClaimsData: {};
  isdependant = false;
  ismedicareonly = false;
  ismedicaremember = false;
  isFinancialView = false;
  isSmartShopperUser = false;
  ismobile = false;
  mobileViewPort = 992;
  showDedcoSpinner = false;
  showDrupal = false;
  showDoctorDrupal = false;
  showMedicationDrupal = false;
  showClaimsDrupal = false;
  dedCoInfo: DeductiblesAccumsInterface = null;
  dedCoInfoDental: DeductiblesAccumsInterface = null;
  dedCoInfoVision: DeductiblesAccumsInterface = null;
  deductibleChartDetails: LineChartOptionsInterface[];
  dentalChartDetails: LineChartOptionsInterface[];
  visionChartDetails: LineChartOptionsInterface[];
  financialChartCounter: number = 0;
  deductibleChartCounter: number = 0;
  financialChartDetails: Finanical[] = [];
  isDisplayFinanceLoader: boolean;
  showNurseLine = false;
  hasBqi = false;
  title = 'Explanation of Benefits';
  hasBlueGreen = false;
  ahealthyme = false;
  dedCoName: string;
  transferLink: string;
  blueGreenUrl: string = this.constantsService.blueGreenUrl;
  nurseLineUrl: string = this.constantsService.nurseLineUrl;
  cernerEEUrl: string = this.constantsService.cernerEEUrl;
  preferences: {};
  CernerMedicareUrl: string = this.constantsService.cernerMedicareUrl;
  drupalContentInactiveWithFinancials: string = this.constantsService.drupalContentInactiveWithFinancialsUrl;
  drupalContentInactiveNoFinancials: string = this.constantsService.drupalContentInactiveNoFinancialsUrl;
  postLoginInfo: PostLoginInfo;
  repPayeeFalg;
  isIndividual: boolean = false;
  isFDCmem: boolean = false;
  isFamilyDed: boolean = false;
  iswellnessRewardsProgramUser: boolean = false;
  showFAD = false;
  memberFullName: string;
  currentScope: string;
  ismedicarePPO = false;
  hasPlanFinancialDetails$: Observable<boolean>;
  count = 0;
  teleHealthFlag = false;

  urlConfig = {
    mymedications: '../mymedications',
    medicationdetails: '../mymedications/medicationdetails',
    myclaims: '../myclaims',
    claimdetails: '/myclaims/claimdetails',
    mycards: '../mycards',
    myplans: '../myplans',
    myaccount: '../myaccount',
    messagecenter: '../message-center/messages',
    documents: '../myeobs',
    uploads: '../message-center/uploads',
    deductibles: '../mydedco',
    maintenance: '../pages/maintenance',
    mydoctors: '../mydoctors',
    doctordetails: '../mydoctors/details',
    myInbox: '../message-center',
    myprofile: '../myprofile',
    addpcp: '../mydoctors/add-pcp-homepage',
    updatepcp: '../mydoctors/update-pcp-homepage',
    requestwrittenestimate: '/request-estimate',
    yes: '/yes',
    taxforms: '../message-center/documents/tax-forms'
  };

  quickAccessLinks = QUICK_ACCESS_LINKS;
  memberLinks = MEMBER_LINKS;
  trackWidgets = TRACK_WIDGETS;

  public learnToLive = [];
  heroButtonText: any;
  buttonUrl: any;
  heroBodyText: any;
  isExternalUrl: any;
  memberFirstName: string;
  memberlinkText: string;
  memberlinkHeader: string;
  memberlinkButtonText: string;
  memberlinkWarningText: string;
  isSelectedTab: boolean = true;
  memberRouterLink: string;
  memberlinkOpen: boolean;
  memberlinkId: string;
  arrLength: any = 0;
  promoFlag: boolean = false;
  promoFlagTwo: boolean = false;
  promoArray: any = [];
  hasDentalPlan: boolean = false;
  hasMedicalPlan: boolean = false;
  hasVisionPlan: boolean = false;
  sliderCounter: number = 0;
  memberLinkMobileHeader: string;
  hasFinancialView$: Observable<any>;
  isFinancialWidgetEnabled: boolean;
  Homepagepromobaseurl: string;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }

  constructor(
    private authService: AuthService,
    private globalService: GlobalService,
    private router: Router,
    private http: AuthHttp,
    private titleCase: TitleCasePipe,
    private r: ActivatedRoute,
    private constantsService: ConstantsService,
    public landingService: LandingService,
    private alertService: AlertService,
    private datePipe: DatePipe,
    private myDedCoService: MyDedCoService,
    private myMedicationDetailsService: MyMedicationDetailsService,
    private fadService: FadService,
    private profileService: ProfileService,
    private cdRef: ChangeDetectorRef
  ) {
    this.heroBannerDatas();
    this.getPromoContents();
    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    const parsedPostInfo = JSON.parse(postLoginInfo);
    const impersonation = this.authService.impersonation();
    const shouldLoadFAD = !impersonation && (parsedPostInfo.hasSS || parsedPostInfo.hasSSO || parsedPostInfo.hasCI);
    const l2FeaturelFalg = environment.enableL2L;
    this.isFinancialWidgetEnabled = environment.enableFinancialWidget;

    sessionStorage.setItem('isTierErrorFound', JSON.stringify(false));

    if (!shouldLoadFAD && !sessionStorage.getItem('fadData')) {
      forkJoin([this.fadService.resolve(false), this.fadService.getVitalsTeleHealthDetails()])
        .toPromise()
        .then(result => {
          this.showFAD = true;
          this.globalService.updateFADStatus(true);
          sessionStorage.setItem('fadData', JSON.stringify(result, null, 2));
        });
    } else {
      this.showFAD = true;
      this.globalService.updateFADStatus(true);
    }

    if (window.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    }

    if (postLoginInfo != null) {
      postLoginInfo ? JSON.parse(postLoginInfo).pharmacyLinks : [];
    }

    /* -- Don't Make changes Here -- */
    if (
      this.r.snapshot.data.home &&
      this.r.snapshot.data.home.ROWSET &&
      !Array.isArray(this.r.snapshot.data.home.ROWSET.ROW) &&
      typeof this.r.snapshot.data.home.ROWSET.ROW === 'object'
    ) {
      this.memberInfo = new HomePageInfoModel(titleCase).deserialize(
        this.r.snapshot.data.home.ROWSET && this.r.snapshot.data.home.ROWSET.ROW
      );
      const postLoginInfoObj = JSON.parse(postLoginInfo);
      this.isSmartShopperUser = postLoginInfo ? postLoginInfoObj.hasSS : false;
      if (l2FeaturelFalg) {
        this.learnToLive = postLoginInfoObj.wellnessPrograms;
      } else {
        this.learnToLive = null;
      }
      this.showNurseLine =
        this.memberInfo.cerner &&
        this.memberInfo.cerner.hasCerner !== 'true' &&
        this.memberInfo.cerner.hasCernerEE !== 'true' &&
        this.memberInfo.cerner.hasCernerMedicare !== 'true' &&
        this.memberInfo.hasBlueGreen !== 'true' &&
        this.memberInfo.hasBQi !== 'true';
      this.hasBqi = this.memberInfo.hasBQi === 'true';
      this.hasBlueGreen = this.memberInfo.hasBlueGreen === 'true';

      this.ahealthyme =
        this.memberInfo.cerner &&
        (this.memberInfo.cerner.hasCerner === 'true' ||
          this.memberInfo.cerner.hasCernerEE === 'true' ||
          this.memberInfo.cerner.hasCernerMedicare === 'true');

      //KLO 1659
      sessionStorage.setItem('isEE', this.memberInfo.isEE);
      this.iswellnessRewardsProgramUser = this.memberInfo.cerner.hasCernerEE === 'true';

      this.globalService.landingPageMemberInfo = this.memberInfo;
      this.authService.storeUserState(this.memberInfo.userState);

      if (this.memberInfo.myclaims && this.memberInfo.myclaims.clmICN) {
        sessionStorage.setItem('claimId', this.memberInfo.myclaims.clmICN);
      }
    }

    /* -- Don't Make changes Here -- */
    if (this.memberInfo) {
      this.showUserBanner();
      // this.getFinancialData();
      this.showUserDataBlocks();
    }

    this.landingService.getCarouselItemDetails().subscribe(response => {
      this.carouselItemDetails = this.transformCarouselResponse(response);
    });

    this.repPayeeFalg = JSON.parse(sessionStorage.getItem('postLoginInfo')).repPayeeFalg;
    this.repPayeeFalg = this.repPayeeFalg === 'true' || this.repPayeeFalg === 'unknown';

    this.landingService.loadArticle(1);
    this.landingService.loadArticle(2);
    if (
      authService.authToken.userType &&
      authService.authToken.userType.toLowerCase() !== 'medicare' &&
      authService.authToken.userType.toLowerCase() !== 'medex' &&
      !this.repPayeeFalg
    ) {
      this.landingService.loadArticle(3);
    }
    if (
      this.authService.authToken &&
      this.authService.authToken.userType &&
      this.authService.authToken.userType.toLowerCase() === 'medicare'
    ) {
      this.ismedicareonly = this.authService.authToken.userType.toLowerCase() === 'medicare';

      this.ismedicarePPO = this.ismedicareonly && JSON.parse(this.memberInfo.isPPO);
    }
    this.hasPlanFinancialDetails$ = this.globalService.hasPlanFinancialDetails$.pipe(
      delay(0)
    );
  }

  ngAfterViewInit() {
    this.hasFinancialView$ = this.landingService.hasFinancialView$.pipe(
      startWith(false),
      delay(0)
    );
  }

  getPromoContents() {
    this.Homepagepromobaseurl = this.constantsService.drupalTestUrl;
    const promoFirst = this.landingService.promoDetails(0);
    const promoThird = this.landingService.promoDetails(2);
    const promoFourth = this.landingService.promoDetails(3);
    const getauthToken = sessionStorage.getItem('authToken');
    const parsedauthToken = JSON.parse(getauthToken);
    const getmemProfile = sessionStorage.getItem('memProfile');
    const parsedmemProfile = JSON.parse(getmemProfile);
    const userAge = Date.parse(parsedmemProfile.dob)
    forkJoin([promoFirst, promoThird]).subscribe(response => {
      promoFourth.subscribe(result => {
        if (result[0].Title !== '') {
          const userTypes = result[0].field_plan_type_export[0].plan_name.map(val => val.toLowerCase().trim());
          if(parsedauthToken.scopename === "AUTHENTICATED-AND-VERIFIED" && userAge > Date.parse(result[0].StartDateOfBirth) && userAge < Date.parse(result[0].EndDateOfBirth) &&
          parsedauthToken.userType &&
          ( userTypes.includes('all') || userTypes.includes(parsedauthToken.userType.toLowerCase()))){
            result[0].hasPsw = true;
            this.promoArray.push(response[0], result, response[1]);
            this.setBlockHeight(this.promoArray);
          } else{
           this.callSecondBlock(response);
          }
        } else{
          this.callSecondBlock(response);
        }
      });
    });
  }
  setBlockHeight(blockArray){
    blockArray.forEach(element => {
      if (element[0].Title !== '') {
        this.arrLength = this.arrLength + 1;
      }
    });
    if (this.arrLength === 3 || this.arrLength === 2) {
      this.promoFlag = true;
    } else if (this.arrLength === 1) {
      this.promoFlag = false;
    }
  }
  callSecondBlock(response){
    const promoSecond = this.landingService.promoDetails(1);
    promoSecond.subscribe( res => {
      this.promoArray.push(response[0], res, response[1]);
      this.setBlockHeight(this.promoArray);
    });
  }
  heroBannerDatas() {
    this.memberFullName = this.profileService.getProfile() ? this.profileService.getProfile().fullName : '';
    this.memberFirstName =
      this.authService && this.authService.authToken && this.authService.authToken.firstName ? this.authService.authToken.firstName : '';
    this.landingService.heroBannerItemsDetails().subscribe(response => {
      this.heroButtonText = response[0].ButtonText;
      this.isExternalUrl = response[0].isExternal;
      this.buttonUrl = this.isExternalUrl === 'FALSE' ? response[0].ButtonUrl.replace('internal:', '') : response[0].ButtonUrl;
      this.heroBodyText = response[0].Body;
    });
  }

  getMyPharmacyMenu() {
    const pharmacymenu: any[] = [];

    const pharmacyImage = {
      '90-Day Supply': 'far fa-shipping-timed  icons-class',
      '90-Day Mail Order Pharmacy': 'far fa-shipping-timed   icons-class',
      'Medication Lookup Tool': 'far fa-prescription-bottle-alt  icons-class',
      'Sign Up for PillPack': 'far fa-hand-holding-box  icons-class',
      'Manage Your PillPack Account': 'far fa-hand-holding-box  icons-class',
      'Express Scripts®': 'far fa-files-medical  icons-class',
      'Cost-Share Assistance Program': 'far fa-hand-holding-usd  icons-class'
    };

    const postLoginInfo = sessionStorage.getItem('postLoginInfo');

    if (postLoginInfo != null && postLoginInfo !== '') {
      const links = JSON.parse(postLoginInfo).pharmacyLinks;
      if (links && links.length > 0) {
        links.forEach(data => {
          pharmacymenu.push({ text: data.text, url: data.url, img: pharmacyImage[data.text] });
        });
        this.PHARMACYURL = pharmacymenu;
      }
    }
    return this.PHARMACYURL;
  }

  showUserBanner(): void {
    try {
      if (
        this.authService.authToken &&
        this.authService.authToken.userType &&
        (this.authService.authToken.userType.toLowerCase() === 'medicare' || this.authService.authToken.userType.toLowerCase() === 'medex')
      ) {
        this.bannerImage = 'hero-medicare-d.png';
        this.ismedicaremember = true;
      } else if (
        this.memberInfo &&
        this.memberInfo.hasDependents.toString() === 'false' &&
        this.authService.authToken.userType &&
        (this.authService.authToken.userType.toLowerCase() !== 'medicare' || this.authService.authToken.userType.toLowerCase() !== 'medex')
      ) {
        this.bannerImage = 'hero-individual-d.png';
        this.isdependant = true;
      } else {
        this.bannerImage = 'hero-family-d.png';
      }
    } catch (exception) {
      console.log(exception);
    }
  }

  openSsoEsiSite(url) {
    if (!this.authService.impersonation()) {
      sessionStorage.setItem('consentLink', url);
      $('#openSsoEsiSite').modal('open');
    }
  }

  openLearnToLive(url: string) {
    $('#openLearnToLive').modal('open');
  }

  bannerButtonNavigate() {
    if (this.isExternalUrl === 'FALSE') {
      this.router.navigate([this.buttonUrl]);
    } else {
      window.open(this.buttonUrl, '_blank');
    }
  }

  navigatePharmacyUrl(url: string) {
    if (url === '/my-pillpack/landing') {
      this.router.navigate([url], { queryParams: { icid: 'PillPack Global' } });
    } else if (url === '/sso/expressscript') {
      this.openSsoEsiSite(url);
    } else if (url.startsWith('/')) {
      this.router.navigate([url]);
    } else if (url !== 'https://www.pillpack.com') {
      window.open(url);
    } else {
      this.openPillPackSite();
    }
  }

  transformCarouselResponse(response: any): Image[] {
    if (response && response.length) {
      return response.map(item => {
        const carouselItem = new Image();
        carouselItem.src = this.constantsService.drupalTestUrl + item.RegularImages;
        carouselItem.mobilesrc = this.constantsService.drupalTestUrl + item.MobileImages;
        // item.isVideo ? '/assets/images/promo/bluebikes-myblue-promo-1002x435.png' : item.VIdeoUrl;
        carouselItem.text = item.ArticleText;
        carouselItem.isVideo = item.VideoUrl.length;
        carouselItem.VIdeoUrl = item.VideoUrl;
        carouselItem.urlLink = item.ArticleUrl;
        carouselItem.Title = item.Title;
        carouselItem.Body = item.Body;
        return carouselItem;
      });
    }
    return [];
  }

  ngOnDestroy() {}

  stopEventPropagation(event) {
    event.stopPropagation();
  }
  openOtherPartnerSite(link) {
    this.transferLink = link;
    $('#openOtherPartnerSite').modal('open');
  }
  closeOtherPartnerSite() {
    $('#openOtherPartnerSite').modal('close');
  }
  ngOnInit() {
    $('#openOtherPartnerSite').modal({ dismissible: true });
    if (environment.displayVirtualVisit) {
      this.fetchVitalsResponse();
    }

    this.getMyPharmacyMenu();
    this.isRegisteredUser = this.authService.getScopeName().includes('REGISTERED');
    this.isAuthentiactedUser = this.authService.getScopeName().includes('AUTHENTICATED');
    this.currentScope =
      this.authService && this.authService.authToken && this.authService.authToken.scopename ? this.authService.authToken.scopename : '';
    this.alertService.clearError();
    this.setNewMemberAlert();
    this.memberlinkText = this.memberLinks[0].text;
    this.memberlinkHeader = this.memberLinks[0].label;
    this.memberLinkMobileHeader = this.memberLinks[0].mobilelabel;
    this.memberlinkButtonText = this.memberLinks[0].buttonText;
    this.memberlinkWarningText = this.memberLinks[0].warningText;
    this.memberRouterLink = this.memberLinks[0].link;
    this.memberlinkOpen = this.memberLinks[0].isExternal;
    this.memberlinkId = this.memberLinks[0].id;
    this.memberLinks.forEach(item => {
      if (item.id === 'mentalHealth') {
        item.isSelected = true;
      } else {
        item.isSelected = false;
      }
    });

    if (!this.authService.tokenError) {
      // this.http.showSpinnerLoading();
    } else {
      this.http.hideSpinnerLoading();
    }

    const t = sessionStorage.getItem('authToken');
    if (t) {
      const authToken = JSON.parse(t);

      if (
        authToken.userType === 'MEMBER' &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (
        authToken.userType === 'MEMBER' &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (
        authToken.userType === 'MEMBER' &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (
        authToken.userType === 'MEMBER' &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Explanation of Your Dental Benefits';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Explanation of Your Dental Benefits';
      }
    }
    this.clearSessionItems();
  }

  fetchVitalsResponse() {
    const vitalsResponse = JSON.parse(sessionStorage.getItem('vitalsResponse'));
    if (!vitalsResponse && this.count < 20) {
      this.count++;
      setTimeout(() => this.fetchVitalsResponse(), 1000);
    } else {
      if (vitalsResponse) {
        this.teleHealthFlag = vitalsResponse.amwellTeleHealthFlag;
        this.memberLinks = this.memberLinks.filter(link => link.id !== (this.teleHealthFlag ? 'getYourFluShot' : 'telehealth'));
    }
  }
}
  setCarouselSlider() {
    // financials carousel code
    if (this.sliderCounter === 0) {
      const track = document.querySelector('.carousel_track') as HTMLElement;
      const slides = Array.from(track.children);
      const nextButton = document.querySelector('.carousel_button--right') as HTMLElement;
      const prevButton = document.querySelector('.carousel_button--left') as HTMLElement;
      const dotsNav = document.querySelector('.carousel_nav') as HTMLElement;
      const dots = Array.from(dotsNav.children);

      const slideSize = slides[0].getBoundingClientRect();
      const slideWidth = slideSize.width;

      //arrange the slides next to one another
      slides.forEach((slide, index) => {
        (slide as HTMLElement).style.left = slideWidth * index + 'px';
      });

      const moveToSlide = (track, currentSlide, targetSlide) => {
        track.style.transform = 'translateX(-' + targetSlide.style.left + ')';
        currentSlide.classList.remove('current-slide');
        targetSlide.classList.add('current-slide');
      };

      const updateDots = (currentDot, targetDot) => {
        currentDot.classList.remove('current-slide');
        targetDot.classList.add('current-slide');
      };

      //When I click right, move them to right
      nextButton.addEventListener('click', e => {
        const currentSlide = track.querySelector('.current-slide') as HTMLElement;
        const nextSlide = currentSlide.nextElementSibling;
        const currentDot = dotsNav.querySelector('.current-slide');
        const nextDot = currentDot.nextElementSibling;
        const nextIndex = slides.findIndex(slide => slide === nextSlide);

        if (nextIndex >= 0) {
          moveToSlide(track, currentSlide, nextSlide);
          updateDots(currentDot, nextDot);
        }
      });

      //When I click left, move slides to left
      prevButton.addEventListener('click', e => {
        const currentSlide = track.querySelector('.current-slide') as HTMLElement;
        const prevSlide = currentSlide.previousElementSibling;
        const currentDot = dotsNav.querySelector('.current-slide');
        const prevDot = currentDot.previousElementSibling;
        const prevIndex = slides.findIndex(slide => slide === prevSlide);
        if (prevIndex >= 0) {
          moveToSlide(track, currentSlide, prevSlide);
          updateDots(currentDot, prevDot);
        }
      });

      //When I click the nav indicators, move to that slide
      dotsNav.addEventListener('click', e => {
        const targetDot = (e.target as HTMLElement).closest('button');
        if (!targetDot) return;
        const currentSlide = track.querySelector('.current-slide');
        const currentDot = dotsNav.querySelector('.current-slide');
        const targetIndex = dots.findIndex(dot => dot === targetDot);
        const targetSlide = slides[targetIndex];
        moveToSlide(track, currentSlide, targetSlide);
        updateDots(currentDot, targetDot);
      });
      this.sliderCounter = this.sliderCounter + 1;
    }
  }

  showUserDataBlocks(): void {
    if (
      this.memberInfo &&
      this.memberInfo.mydoctors &&
      !this.memberInfo.mydoctors.visitPrvName &&
      this.memberInfo.mymedications &&
      !this.memberInfo.mymedications.rxDrugName &&
      this.memberInfo.myclaims &&
      !this.memberInfo.myclaims.clmICN
    ) {
      this.showDrupal = false;
      this.showMedicationDrupal = false;
      this.showDoctorDrupal = false;
      this.showClaimsDrupal = false;
    } else if (
      this.memberInfo &&
      ((this.memberInfo.mydoctors && !this.memberInfo.mydoctors.visitPrvName) ||
        (this.memberInfo.mymedications && !this.memberInfo.mymedications.rxDrugName) ||
        (this.memberInfo.myclaims && !this.memberInfo.myclaims.clmICN))
    ) {
      if (this.memberInfo && this.memberInfo.mydoctors && !this.memberInfo.mydoctors.visitPrvName) {
        this.showDoctorDrupal = true;
        this.getDrupalContent(this.constantsService.drupalDoctorsUrl).subscribe(response => {
          this.doctorData = response[0];
        });
      }

      if (this.memberInfo && this.memberInfo.mymedications && !this.memberInfo.mymedications.rxDrugName) {
        this.showMedicationDrupal = true;
        this.getDrupalContent(this.constantsService.drupalMedicationsUrl).subscribe(response => {
          this.medicationData = response[0];
        });
      }
      if (this.memberInfo && this.memberInfo.myclaims && !this.memberInfo.myclaims.clmICN) {
        this.showClaimsDrupal = true;
        this.getDrupalContent(this.constantsService.drupalClaimsUrl).subscribe(response => {
          this.ClaimsData = response[0];
        });
      }
    } else {
      this.showDrupal = false;
    }
  }

  formattedData(value: string) {
    if (!value) {
      return '';
    } else {
      value = value.substring(0, 11);
      return this.datePipe.transform(value, 'MM/dd/yyyy');
    }
  }

  navigate(id, routeParams?) {
    const url = this.urlConfig[id];
    if (url) {
      if (!routeParams) {
        this.router.navigate([url], { relativeTo: this.r });
      } else {
        this.router.navigate([url], { relativeTo: this.r });
      }
    } else {
      return;
    }
  }

  openUrl(url) {
    if (url) {
      window.open(url, '_self');
    }
  }

  openUrlinNewWindow(url,ispsw = false) {
     if (!ispsw && url) {
      window.open(url, '_blank');
    } else if(ispsw){
      $('#openPsw').modal('open');
    }
  }

  openFadSSO() {
    // Impersonation has SSO blocked
    const impersonate = this.authService.impersonation();
    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    if (!postLoginInfo) {
      this.http.postlogin().then(response => {
        if (response && response.error !== true) {
          sessionStorage.setItem('postLoginInfo', JSON.stringify(response));
        }
        if (response && response.error) {
          this.http.showServiceErrorModalPopup('globalError');
        } else if ((response.hasSS || response.hasSSO || response.hasCI) && !impersonate) {
          this.openFadSsoSite();;
        } else {
          this.router.navigate(['/fad']);
        }
      });
    } else {
      const postLoginInfoObj = JSON.parse(postLoginInfo);
      if ((postLoginInfoObj.hasSS || postLoginInfoObj.hasSSO || postLoginInfoObj.hasCI) && !impersonate) {
        this.openFadSsoSite();;
      } else {
        this.router.navigate(['/fad']);
      }
    }
  }

  openFadSsoSite() {
    if(!this.authService.impersonation()){
      sessionStorage.setItem('consentLink', '/sso/vitals');
      $('#openSsoFadSite').modal('open');
    }
  }


  openPillPackSite() {
    sessionStorage.setItem('consentLink', 'https://www.pillpack.com');
    $('#openPillPackSite').modal('open');
  }

  getDrupalContent(url): Observable<{}> {
    return this.http.get(url).map(response => {
      return this.transformCarouselResponse(response);
    });
  }

  authRestartScreen() {
    this.globalService
      .redirectionRoute()
      .then(response => {
        console.log(response);
      })
      .catch(route => {
        this.router.navigate([route]);
      });
  }

  showMedicationDetails() {
    const medicationDetailReq: RxDetailsRequestModelInterface = new RxDetailsRequestModel();
    medicationDetailReq.useridin = this.authService.useridin;
    medicationDetailReq.rxIncurredDate = this.globalService.getUTCDate(this.memberInfo.mymedications.rxIncurredDate);
    medicationDetailReq.ndcCd = this.memberInfo.mymedications.rxNDCCode; // ndcCd;
    if (this.memberInfo && this.memberInfo.mymedications && this.memberInfo.mymedications.rxDependentId) {
      medicationDetailReq.dependentId = this.memberInfo.mymedications.rxDependentId;
    }
    this.myMedicationDetailsService.setMyMedicationDetailsRequest(medicationDetailReq);
    this.router.navigate(['../mymedications/medicationdetails']);
  }

  showDoctorDetails() {
    sessionStorage.setItem('providerName', this.memberInfo.mydoctors.visitPrvName);
    sessionStorage.setItem('providerNumber', this.memberInfo.mydoctors.visitPrvNum);
    if (this.memberInfo && this.memberInfo.mydoctors && this.memberInfo.mydoctors.visitDependentId) {
      sessionStorage.setItem('docDependentId', this.memberInfo.mydoctors.visitDependentId);
    }
    this.router.navigate([`/mydoctors/details`]);
  }

  clearSessionItems() {
    sessionStorage.removeItem('medicationDetailRequest');
    sessionStorage.removeItem('medicationDependentMemberInfo');
  }

  navigateToAlegeus(lineChart: Finanical): void {
    const impersonate = this.authService.impersonation();
    if (lineChart && !impersonate) {
      if (lineChart.isALGAccount) {
        sessionStorage.setItem('consentLink', '/sso/alegeus');
        $('#openSsoAlgSite').modal('open');
      } else {
        sessionStorage.setItem('consentLink', '/sso/heathequity');
        $('#openSsoHeqSite').modal('open');
      }
    }
  }

  openAhealthyme() {
    // Impersonation has SSO blocked
    const impersonate = this.authService.impersonation();
    console.log('SSO blocked in Impersonation');
    if (this.memberInfo.cerner.hasCernerMedicare === 'true' && !impersonate) {
      window.open(this.constantsService.cernerMedicareUrl, '_blank');
    } else if (this.memberInfo.cerner.hasCernerEE === 'true' && !impersonate) {
      window.open(this.constantsService.cernerEEUrl, '_blank');
    } else if (this.memberInfo.cerner.hasCerner === 'true' && !impersonate) {
      window.open('/sso/cerner', '_blank');
    }
  }

  openBqi() {
    // Impersonation has SSO blocked
    const impersonate = this.authService.impersonation();
    console.log('SSO blocked in Impersonation');
    if (!impersonate) {
      window.open('sso/connecture', '_blank');
    }
  }

  openWellnessRewardsProgram() {
    if (this.memberInfo && this.memberInfo.cerner && this.memberInfo.cerner.hasCernerEE) {
      sessionStorage.setItem('hasCernerEE', this.memberInfo.cerner.hasCernerEE);
    } else {
      sessionStorage.setItem('hasCernerEE', null);
    }

    $('#wellnessRewardsProgram').modal('open');
  }

  setNewMemberAlert() {
    this.alertService.setAlert(
      this.constantsService.registerNewMembers,
      'Welcome New Members!',
      AlertType.Warning,
      'component',
      'registeredhomepage'
    );
  }

  memberLinkClick(index: any) {
    this.memberlinkText = this.memberLinks[index].text;
    this.memberlinkHeader = this.memberLinks[index].label;
    this.memberLinkMobileHeader = this.memberLinks[index].mobilelabel;
    this.memberRouterLink = this.memberLinks[index].link;
    this.memberlinkButtonText = this.memberLinks[index].buttonText;
    this.memberlinkWarningText = this.memberLinks[index].warningText;
    this.memberlinkOpen = this.memberLinks[index].isExternal;
    this.memberlinkId = this.memberLinks[index].id;
    this.memberLinks.forEach((item, count) => {
      item.isSelected = count === index ? true : false;
    });
  }

  memberLinkOpenUrl(url, isExternal, id) {
    if (id === 'remoteDoctorVisits') {
      this.openFadSSO();
    } else if (isExternal && url) {
      window.open(url, '_blank');
    } else {
      this.router.navigateByUrl(url);
    }
  }

  openMentalHealth(url: string) {
    $('#openMentalHealthLink').modal('open');
    sessionStorage.setItem('memberLinkLearnToLive', url);
  }
}
