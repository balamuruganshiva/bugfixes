import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { of } from 'rxjs/observable/of';
import { AuthService } from '../../shared/services/auth.service';
import { FadService } from '../fad/fad.service';

@Injectable()
export class FadResolver implements Resolve<Observable<any>> {
  constructor(private fadService: FadService, private authService: AuthService) {}

  async resolve() {
    const fadData = JSON.parse(sessionStorage.getItem('fadData'));
    return (await this.authService.isAuthenticated()) && fadData
      ? of([])
      : forkJoin([this.fadService.resolve(true), this.fadService.getVitalsTeleHealthDetails()])
          .toPromise()
          .then(result => {
            sessionStorage.setItem('fadData', JSON.stringify(result, null, 2));
            console.log('fad resolver page Getvitals response', result);
            sessionStorage.setItem('fadResolverGetVitalsTeleHealthResponse',JSON.stringify(result));  
            return of(result);
          });
  }
}
