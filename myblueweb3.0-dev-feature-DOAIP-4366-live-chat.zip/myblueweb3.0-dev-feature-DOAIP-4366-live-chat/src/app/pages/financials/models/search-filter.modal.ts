import { RadioListInterface } from './interfaces/search-filter.interface';

export class RadioList implements RadioListInterface {
    value: string;
    checked: boolean;
}
