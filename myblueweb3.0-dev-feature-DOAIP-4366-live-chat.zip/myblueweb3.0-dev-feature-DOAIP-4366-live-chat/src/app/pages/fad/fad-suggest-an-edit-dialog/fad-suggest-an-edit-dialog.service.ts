import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { FadConstants } from '../constants/fad.constants';
import { FadSuggestAnEditSubmitFeedbackRequestInterface } from '../modals/interfaces/fad-suggest-an-edit-dialog.interface';

@Injectable()
export class FadSuggestAnEditDialogService {

  constructor(private http: AuthHttp) { }

  getFadSuggestAnEditSubmitFeedback(fadSuggestAnEditSubmitFeedbackRequest: FadSuggestAnEditSubmitFeedbackRequestInterface): Observable<any> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in fadSuggestAnEditSubmitFeedbackRequest) {
      params = params.append(key.toString(), fadSuggestAnEditSubmitFeedbackRequest[key]);
    }

    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.http.encryptFadPost(FadConstants.urls.fadSuggestAnEdit_submitFeedbackUrl, fadSuggestAnEditSubmitFeedbackRequest, '', '', false).map(response => {
      return response;
    });
  }
}
