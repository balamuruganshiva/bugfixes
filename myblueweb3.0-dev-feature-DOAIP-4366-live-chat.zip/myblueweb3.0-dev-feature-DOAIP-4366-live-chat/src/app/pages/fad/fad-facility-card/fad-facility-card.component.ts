import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadFacilityCardComponentOutputModel } from '../modals/fad-profile-card.modal';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadFacilityCardComponentInputModelInterface, FadFacilityCardComponentOutputModelInterface } from '../modals/interfaces/fad-profile-card.interface';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';


@Component({
  selector: 'app-fad-facility-card',
  templateUrl: './fad-facility-card.component.html',
  styleUrls: ['./fad-facility-card.component.scss']
})
export class FadFacilityCardComponent implements OnInit, StarRatingComponentConsumer {
  @Output('componentOutput') componentOutput: EventEmitter<FadFacilityCardComponentOutputModelInterface> = new EventEmitter<
    FadFacilityCardComponentOutputModelInterface
  >();

  @Input('componentInput') componentInput: FadFacilityCardComponentInputModelInterface;

  @Input('disbaleSelection') disbaleSelection: boolean;

  // temporary stuff
  public doctorStarRating: StarRatingComponentInputModelInterface;
  public checked = false;
  // end of temporary stuff
  public tier: string;
  public tierTooltip = new Array();
  public facilityName: string;
  public doctorDegree: string;
  public speciality: string;
  public medicalGroup: string;
  public address: string;
  public phoneNumber: string;
  public awards = [];
  public numberOfLocations: number;
  public cost_dollars = '00';
  public cost_pennies = '00';
  public costAvailable = false;
  public isProcedure = false;
  public accordianToggleStatus: any = {};
  public disclaimers: any;
  public disclaimersText: string;
  public disclaimersFlag: boolean;
  public toggleShowMoreLocationStatus = false;
  public costNotAvailableToolTipVisible = false;
  public blueDistinct: string;
  public blueDistinctPlus: string;
  public tierTooltipDescription: string;
  public fasFlag = false;
  public blueAwardFlag = false;
  public endDateDisclaimers: string;
  public endDateDisclaimersFlag: boolean;
  public endDateDisclaimersDate: string;
  constructor(
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private router: Router,
    private fadSearchResultsService: FadSearchResultsService,
    private facilityProfileService: FadFacilityProfileService,
    public authService: AuthService
  ) {}

  ngOnInit() {
    try {
      if (JSON.parse(sessionStorage.getItem('tiersLabel'))) {
        this.tierTooltip = JSON.parse(sessionStorage.getItem('tiersLabel'));
      }
      this.facilityName = this.componentInput.facility.facilityName;
      if (this.componentInput.facility.disclaimers) {
        this.disclaimers = this.componentInput.facility.disclaimers;
        if (this.disclaimers && this.disclaimers.category && this.disclaimers.category == 'on_record' && this.disclaimers.text) {
          this.disclaimersFlag = true;
          this.disclaimersText = this.disclaimers.text;
        }
      }
      // this.doctorDegree = this.componentInput.professional.degrees.join(',');
      this.speciality = this.componentInput.facility.specialty;

      // const specialityBuffer = [];
      // this.componentInput.professional.specializations.map((specialization) => {
      //   specialityBuffer.push(specialization.field_specialty.name);
      //   return specialization;
      // });
      // this.speciality = specialityBuffer.join(',');
      this.blueDistinct = FadConstants.text.blueDistinct;
      this.blueDistinctPlus = FadConstants.text.blueDistinctPlus;
      if (this.componentInput.facility.locations) {
        this.numberOfLocations = this.componentInput.facility.locations.length;
        const firstLocation = this.componentInput.facility.locations[0];
        this.medicalGroup = firstLocation.name;
        this.address = firstLocation.address;
        this.phoneNumber = firstLocation.phone;
        this.endDateDisclaimers = firstLocation.endDateDisclaimers.text;
        this.endDateDisclaimersFlag = firstLocation.endDateDisclaimers.showEndDateDisclmrs;
        this.endDateDisclaimersDate = firstLocation.endDateDisclaimers.futureTerminationDate;
        this.awards = [];

        this.accordianToggleStatus = {};
        if (firstLocation.awards && firstLocation.awards.length) {
          const blueAwards = firstLocation.awards.filter(award => {
            return award.name.indexOf('BLUE DISTINCTION') >= 0;
          });
          if (blueAwards.length > 0) {
            this.awards = [{ name: 'Blue Distinctions', awardDetails: [] }];
            blueAwards.forEach(award => {
              if (award.awardDetails.length) {
                this.blueAwardFlag = true;
                award.awardDetails.forEach(awardDetail => {
                  this.awards[0].awardDetails.push(awardDetail);
                });
              }
            });
          }
        }

        /*this.address = [firstLocation.address.addr_line1, firstLocation.address.addr_line2, // have to check
        firstLocation.address.city, firstLocation.address.state_code, firstLocation.address.county].filter((adrItem) => {
          if (adrItem) {
            return adrItem;
          }
        }).join(', ') + ' ' + firstLocation.address.postal_code;

        if (firstLocation.phones.voice && firstLocation.phones.voice.length > 0) {
          this.phoneNumber = firstLocation.phones.voice[0].number;  // have to check
        }*/

        /* COST IS MISSING */
        /* kalagi01: DO NOT DELETE******************/
        if (firstLocation.facilityCost && firstLocation.facilityCost.memberCost >= 0) {
          const costString: string = firstLocation.facilityCost.memberCost + '';
          this.cost_dollars = costString.split('.')[0];
          this.cost_pennies = costString.split('.')[1];
          this.costAvailable = true;
        } else {
          this.costAvailable = false;
        }
        if (firstLocation && firstLocation.tiers && firstLocation.tiers.description) {
          this.tier = firstLocation.tiers.description;
          this.getToolTipDescription(this.tierTooltip, this.tier);
        }
      } else {
        this.numberOfLocations = 0;
      }

      // temporary stuff
      this.doctorStarRating = new StarRatingComponentInputModel();
      if (this.componentInput.facility.reviews) {
        if (this.componentInput.facility.reviews.overallRating) {
          this.doctorStarRating.ratingInPercentage = parseInt(
            '' + (parseFloat(this.componentInput.facility.reviews.overallRating.toString()) * 100) / 5
          );
        }
        // parseInt(this.componentInput.facility.reviews.overallRating.toString())*100/5;
        // this.doctorStarRating.numberOfStars = 5;
        this.doctorStarRating.totalRatings = this.componentInput.facility.reviews.totalRatings;
        if (this.componentInput.facility.reviews.overallRating) {
          this.doctorStarRating.overAllRating = parseFloat(this.componentInput.facility.reviews.overallRating.toString());
        }
        // end of temporary stuff
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilityCardComponent,
        FadConstants.methods.ngOnInit
      );
    }

    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    if (searchCriteria) {
      this.isProcedure = searchCriteria.getSearchText().isProcedure();
    }
  }

  getToolTipDescription(toolTip, tier) {
    this.tierTooltipDescription = '';
    if (toolTip) {
      toolTip.forEach(toolTips => {
        if (toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase() === tier.toLowerCase()) {
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    }
    return this.tierTooltipDescription;
  }
  fasIcon() {
    this.fasFlag = !this.fasFlag;
  }

  toggleAccordion(listItem, status) {
    this.accordianToggleStatus[listItem] = status;
  }

  public openProfile(event): void {
    try {
      const facilityDetails: any = this.componentInput.facility;
      this.facilityProfileService.facilityProfile = facilityDetails.facilityId;
      sessionStorage.setItem('facilityProfileId', facilityDetails.facilityId.toString());

      sessionStorage.setItem('locationId', this.componentInput.facility.locations[0].id.toString());
      setTimeout(() => {
        this.router.navigate(['/fad/facility-profile']);
      }, 1);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilityCardComponent,
        FadConstants.methods.openProfile
      );
    }
  }

  public toggleShowMoreLocation() {
    this.toggleShowMoreLocationStatus = !this.toggleShowMoreLocationStatus;
  }
  /**
   * @description: get triggered when check box selection changes in the profile card. Triggers an output with the necessary info to
   * the parent component
   */
  public onSelectionChange(event): void {
    try {
      const output: FadFacilityCardComponentOutputModelInterface = new FadFacilityCardComponentOutputModel();
      output.facility = this.componentInput.facility;
      output.facility.isChecked = event.checked;
      output.isSelected = event.checked;
      this.checked = event.checked;
      this.componentOutput.emit(output);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilityCardComponent,
        FadConstants.methods.onSelectionChange
      );
    }
  }

  public doAuthentication() {
    this.router.navigateByUrl('/login');
  }

  public reviewBenifits(): void {
    throw new Error('yet to be coded');
  }

  showCostCostAvailableToolTip() {
    this.costNotAvailableToolTipVisible = !this.costNotAvailableToolTipVisible;
  }
}
