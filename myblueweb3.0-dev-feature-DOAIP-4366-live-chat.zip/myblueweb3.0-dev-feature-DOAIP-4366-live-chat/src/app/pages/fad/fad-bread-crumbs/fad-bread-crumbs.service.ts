import { Injectable } from '@angular/core';
import { BreadCrumbInterface } from '../modals/interfaces/fad.interface';
import { BreadCrumb } from '../utils/fad.utils';

@Injectable()
export class FadBreadCrumbsService {
  private stackedBreadCrumbList: BreadCrumbInterface[] = [new BreadCrumb().setLabel('Find a Doctor').setUrl('/fad')];

  constructor() {}

  getStacketBreadCrumbList(): BreadCrumbInterface[] {
    return this.stackedBreadCrumbList;
  }

  addBreadCrumb(breadCrumb: BreadCrumbInterface): FadBreadCrumbsService {
    // slice the breadcrumb list untill the current selected value if the item is already present in the list
    if (!this.cropTillBreadCrumb(breadCrumb)) {
      // if the item is not already on the list, remove it
      this.stackedBreadCrumbList.push(breadCrumb);
    }

    return this;
  }

  cropTillBreadCrumb(breadCrumb: BreadCrumbInterface): boolean {
    let matchIndex = 1;
    const matchFound: boolean = this.stackedBreadCrumbList.some(breadCrumbItem => {
      if (breadCrumbItem.getLabel() === breadCrumb.getLabel() && breadCrumbItem.getUrl() === breadCrumb.getUrl()) {
        return true;
      }
      matchIndex++;
    });

    if (matchFound) {
      this.stackedBreadCrumbList = this.stackedBreadCrumbList.slice(0, matchIndex);
    }

    return matchFound;
  }
}
