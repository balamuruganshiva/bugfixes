import { Component, HostListener, Inject, OnDestroy, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { SendProviderInquiryDialogConfirmation_InputDataInterface } from "../modals/interfaces/send-provider-inquiry-dialogs.interface";

@Component({
  selector: 'app-send-provider-email-inquiry-confirmation-popup',
  templateUrl: './send-provider-email-inquiry-confirmation-popup.component.html',
  styleUrls: ['./send-provider-email-inquiry-confirmation-popup.component.scss']
})
export class SendProviderEmailInquiryConfirmationPopupComponent implements OnInit, OnDestroy {

  public emailSentTo: string = null;
  public errorFlag: boolean = false;

  private isMobileView: boolean = false;
  private mobileViewWidth = '40vw';
  private desktopViewWidth = '94vw';
  private mobileViewWidthLimit = 992;

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.isMobileView = event.target.innerWidth <= this.mobileViewWidthLimit;

    if (this.isMobileView) {
      const overLay = <HTMLElement>document.getElementsByClassName('cdk-overlay-pane')[0];
      overLay.style.maxWidth = this.desktopViewWidth;
      overLay.style.width = this.desktopViewWidth;
    } else {
      const overLay = <HTMLElement>document.getElementsByClassName('cdk-overlay-pane')[0];
      overLay.style.maxWidth = this.mobileViewWidth;
      overLay.style.width = this.mobileViewWidth;
    }
  }

  constructor(public dialogRef: MatDialogRef<SendProviderEmailInquiryConfirmationPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: SendProviderInquiryDialogConfirmation_InputDataInterface) {
    //clicking outside the popup should not close the dialog
    dialogRef.disableClose = true;
    this.emailSentTo = this.data.emailId;
    this.errorFlag = this.data.errorFlag;
  }

  ngOnInit() {
    this.isMobileView = window.innerWidth <= this.mobileViewWidthLimit;
    let clearCount = 0;
    const timer = window.setInterval(() => {
      clearCount++;
      let cdkOverlayContainer = <HTMLElement>document.getElementsByClassName('cdk-overlay-container')[0];
      cdkOverlayContainer.style.zIndex = '1002';

      if (this.isMobileView) {
        const overLay = <HTMLElement>document.getElementsByClassName('cdk-overlay-pane')[0];
        overLay.style.maxWidth = this.desktopViewWidth;
        overLay.style.width = this.desktopViewWidth;
      } else {
        const overLay = <HTMLElement>document.getElementsByClassName('cdk-overlay-pane')[0];
        overLay.style.maxWidth = this.mobileViewWidth;
        overLay.style.width = this.mobileViewWidth;
      }

      if (clearCount > 15) {
        window.clearInterval(timer);
      }
    }, 50);
  }

  ngOnDestroy() {

    let cdkOverlayContainer = <HTMLElement>document.getElementsByClassName('cdk-overlay-container')[0];
    cdkOverlayContainer.style.zIndex = '1000';

  }

  cancel(): void {
    this.dialogRef.close('dismiss');
  }


}
