import { Injectable } from '@angular/core';
import { Resolve, Router, RoutesRecognized } from '@angular/router';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { GetSearchByFacilityRequestModel } from '../modals/getSearchByFacility.model';
import { GetSearchByProfessionalRequestModel } from '../modals/getSearchByProfessional.model';
import { GetSearchBySpecialityRequestModel } from '../modals/getSearchBySpeciality.model';
import { FadAutoCompleteComplexOptionInterface, FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { GetSearchByFacilityRequestModelInterface, GetSearchByFacilityResponseModelInterface } from '../modals/interfaces/getSearchByFacility-models.interface';
import { GetSearchByProfessionalRequestModelInterface, GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import { GetSearchBySpecialityRequestModelInterface, GetSearchBySpecialtyResponseModelInterface } from '../modals/interfaces/getSearchBySpeciality-models.interface';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';
import { FadSearchResultsService } from './fad-search-results.service';


@Injectable()
export class FadSearchResultsResolver<T>
  implements
  Resolve<
  Promise<
    | GetSearchBySpecialtyResponseModelInterface
    | GetSearchByProfessionalResponseModelInterface
    | GetSearchByFacilityResponseModelInterface
  >
  > {
    public locationflagaffl = false;
    hpnTieredNetworId :number = 311006116;
    constructor(
    private fadSearchResultsService: FadSearchResultsService,
    private errorHandler: BcbsmaerrorHandlerService,
    private router: Router,
    private authService: AuthService
  ) { }

  async resolve(): Promise<
    GetSearchBySpecialtyResponseModelInterface | GetSearchByProfessionalResponseModelInterface | GetSearchByFacilityResponseModelInterface
  > {
    try {

      this.router.events
    .filter(e => e instanceof RoutesRecognized)
    .pairwise()
    .subscribe((event: any[]) => {

      if(event[0].urlAfterRedirects === '/fad/doctor-profile'){
        if(event[1].urlAfterRedirects === '/fad/affiliated-doctors-search-results'){
          this.fadSearchResultsService.setContextText('affiliated');
          this.locationflagaffl = true;
        }
      }
      else{
        this.locationflagaffl = false;
      }
    });


      const authUserId = this.authService.useridin;
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

      if (searchCriteria && searchCriteria.getSearchText()) {
        const searchTextOption: FadAutoCompleteComplexOptionInterface = searchCriteria.getSearchText();

        if (
          searchTextOption.getInfoText() === 'Specialty' ||
          searchTextOption.getInfoText() === 'procedures' ||
          searchTextOption.getInfoText() === 'specialities'
        ) {
          if (
            searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.speciality &&
            this.fadSearchResultsService.getContextText() != 'affiliated'
          ) {
            const vitalsSearchRequestbySpeciality: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();
      
            vitalsSearchRequestbySpeciality
              .setGeoLocation(searchCriteria.getZipCode().geo)
              .setLimit(FadConstants.defaults.limit)
              .setPage(FadConstants.defaults.page)
              .setRadius(25)
              .setNetworkId(searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId())
              .setSearchForTH(true)
              if((searchCriteria.getPlanName().getNetworkId()) === this.hpnTieredNetworId){
                vitalsSearchRequestbySpeciality.setSort('tiers:hpn asc, relevancy desc')
              };
    

            if (!searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getSpecialityId()) {
              vitalsSearchRequestbySpeciality.setSearchSpecialtyId(searchCriteria.getSearchText().getSpecialityId());
            } else if (searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getProcedureId()) {
              vitalsSearchRequestbySpeciality.setProcedureId(searchCriteria.getSearchText().getProcedureId());
              vitalsSearchRequestbySpeciality['sort'] = 'cost+asc';
            } else {
            }

            if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
              vitalsSearchRequestbySpeciality.setUserId(this.authService.useridin);
            }
            return await this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality).toPromise();
          } else if (
            searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.facility &&
            this.fadSearchResultsService.getContextText() != 'affiliated'
          ) {
            const vitalsSearchRequestbySpeciality: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();

              vitalsSearchRequestbySpeciality
              .setGeoLocation(searchCriteria.getZipCode().geo)
              .setLimit(FadConstants.defaults.limit)
              .setPage(FadConstants.defaults.page)
              .setRadius(25)
              .setNetworkId(searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId())
              .setSearchForTH(true)
              if((searchCriteria.getPlanName().getNetworkId()) === this.hpnTieredNetworId){
                vitalsSearchRequestbySpeciality.setSort('tiers:hpn asc, relevancy desc')
              };


            if (!searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getSpecialityId()) {
              vitalsSearchRequestbySpeciality.setSearchSpecialtyId(searchCriteria.getSearchText().getSpecialityId());
            } else if (searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getProcedureId()) {
              vitalsSearchRequestbySpeciality.setProcedureId(searchCriteria.getSearchText().getProcedureId());
              vitalsSearchRequestbySpeciality['sort'] = 'cost+asc';
            } else {
            }

            if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
              vitalsSearchRequestbySpeciality.setUserId(this.authService.useridin);
            }
            return await this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality).toPromise();
          } else if (
            searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.professional &&
            this.fadSearchResultsService.getContextText() != 'affiliated'
          ) {
            const vitalsSearchRequestbySpeciality: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();

            vitalsSearchRequestbySpeciality
              .setGeoLocation(searchCriteria.getZipCode().geo)
              .setLimit(FadConstants.defaults.limit)
              .setPage(FadConstants.defaults.page)
              .setRadius(25)
              .setNetworkId(searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId())
              .setSearchForTH(true)
              if((searchCriteria.getPlanName().getNetworkId()) === this.hpnTieredNetworId){
                vitalsSearchRequestbySpeciality.setSort('tiers:hpn asc, relevancy desc')
              };


            if (!searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getSpecialityId()) {
              vitalsSearchRequestbySpeciality.setSearchSpecialtyId(searchCriteria.getSearchText().getSpecialityId());
            } else if (searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getProcedureId()) {
              vitalsSearchRequestbySpeciality.setProcedureId(searchCriteria.getSearchText().getProcedureId());
              vitalsSearchRequestbySpeciality['sort'] = 'cost+asc';
            } else {
            }

            if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
              vitalsSearchRequestbySpeciality.setUserId(this.authService.useridin);
            }
            return await this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality).toPromise();
          } else if (this.fadSearchResultsService.getContextText() === 'affiliated') {
            let affiliatedDoctorSearchProviderId: string = sessionStorage.getItem('affiliatedDoctorSearchProviderId');
            if (affiliatedDoctorSearchProviderId === "undefined" || !affiliatedDoctorSearchProviderId) {
              affiliatedDoctorSearchProviderId = null;
            }

            const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();
            vitalsSearchRequestbyProfessional
              .setGeoLocation(searchCriteria.getZipCode().geo)
              .setLimit(FadConstants.defaults.limit)
              .setPage(FadConstants.defaults.page)
              .setNetworkId(
                searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
                  ? searchCriteria.getPlanName().getNetworkId()
                  : FadConstants.defaults.networkId
              ).setSearchForTH(true)
              .setProviderId(affiliatedDoctorSearchProviderId)
              if((searchCriteria.getPlanName().getNetworkId()) === this.hpnTieredNetworId){
                vitalsSearchRequestbyProfessional.setSort('tiers:hpn asc, relevancy desc')
              };


            if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
              vitalsSearchRequestbyProfessional.setUserIdIn(this.authService.useridin);
            }
            return await this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).toPromise();
          }
        } else if (this.fadSearchResultsService.getContextText() === 'affiliated') {
          let affiliatedDoctorSearchProviderId: string = sessionStorage.getItem('affiliatedDoctorSearchProviderId');
          if (affiliatedDoctorSearchProviderId === "undefined" || !affiliatedDoctorSearchProviderId) {
            affiliatedDoctorSearchProviderId = null;
          }
          const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();
          vitalsSearchRequestbyProfessional
            .setGeoLocation(searchCriteria.getZipCode().geo)
            .setLimit(FadConstants.defaults.limit)
            .setPage(FadConstants.defaults.page)
            .setNetworkId(
              searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
                ? searchCriteria.getPlanName().getNetworkId()
                : FadConstants.defaults.networkId
            ).setSearchForTH(true)
            .setProviderId(affiliatedDoctorSearchProviderId)
            if((searchCriteria.getPlanName().getNetworkId()) === this.hpnTieredNetworId){
              vitalsSearchRequestbyProfessional.setSort('tiers:hpn asc, relevancy desc')
            };

          if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
            vitalsSearchRequestbyProfessional.setUserIdIn(this.authService.useridin);
          }
          return await this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).toPromise();
        } else if (
          searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.professional &&
          !searchCriteria.getSearchText().isProcedure() &&
          this.fadSearchResultsService.getContextText() != 'affiliated'
        ) {
          const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();

        vitalsSearchRequestbyProfessional
            .setGeoLocation(searchCriteria.getZipCode().geo) // '42.402311000000026,-71.12037000000004')
            .setLimit(FadConstants.defaults.limit)
            .setPage(FadConstants.defaults.page)
            .setRadius(FadConstants.defaults.radius)
            .setNetworkId(
              searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
                ? searchCriteria.getPlanName().getNetworkId()
                : FadConstants.defaults.networkId
            ).setSearchForTH(true)
            if((searchCriteria.getPlanName().getNetworkId()) === this.hpnTieredNetworId){
              vitalsSearchRequestbyProfessional.setSort('tiers:hpn asc, relevancy desc')
            };

          //.setExpertiseTypeCode('');

          if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
            vitalsSearchRequestbyProfessional.setSearchSpecialtyId(searchTextOption.getSpecialityId());
          } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
            vitalsSearchRequestbyProfessional.setSearchProcedureId(searchTextOption.getProcedureId());
          } else {
            vitalsSearchRequestbyProfessional.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
          }

          if (authUserId) {
            vitalsSearchRequestbyProfessional.setUserIdIn(this.authService.useridin);
          }

          return await this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).toPromise();
        } else if (
          searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.facility &&
          !searchCriteria.getSearchText().isProcedure() &&
          this.fadSearchResultsService.getContextText() != 'affiliated'
        ) {
          const vitalsSearchRequestbyFacility: GetSearchByFacilityRequestModelInterface = new GetSearchByFacilityRequestModel();
          // alternate geolocation value format that is allowed '42.402311000000026,-71.12037000000004')

        vitalsSearchRequestbyFacility
            .setGeoLocation(searchCriteria.getZipCode().geo)
            .setLimit(FadConstants.defaults.limit)
            .setPage(FadConstants.defaults.page)
            .setRadius(FadConstants.defaults.radius)
            .setNetworkId(
              searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
                ? searchCriteria.getPlanName().getNetworkId()
                : FadConstants.defaults.networkId
            ).setSearchForTH(true)
            if((searchCriteria.getPlanName().getNetworkId()) === this.hpnTieredNetworId){
              vitalsSearchRequestbyFacility.setSort('tiers:hpn asc, relevancy desc')
            };


          if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
            vitalsSearchRequestbyFacility.setSearchSpecialtyId(searchTextOption.getSpecialityId());
          } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
            vitalsSearchRequestbyFacility.setProcedureId(searchTextOption.getProcedureId());
          } else {
            vitalsSearchRequestbyFacility.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
          }

          if (authUserId) {
            vitalsSearchRequestbyFacility.setUserIdIn(this.authService.useridin);
          }

          return await this.fadSearchResultsService.getFadFacilitySearchResults(vitalsSearchRequestbyFacility).toPromise();
        }
      } else {
        this.router.navigate([FadConstants.urls.fadLandingPage]);
      }
    } catch (exception) {
      this.errorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.services.fadSearchResultsResolver,
        FadConstants.methods.resolve
      );
    }
    return null;
  }
}
