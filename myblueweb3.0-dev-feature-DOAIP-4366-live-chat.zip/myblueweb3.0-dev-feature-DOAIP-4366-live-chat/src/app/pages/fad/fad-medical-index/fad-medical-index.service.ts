import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadMedicalIndexRequestModal } from '../modals/fad-medical-index.modal';
import { GetSearchByProcedureRequestModel } from '../modals/getSearchByProcedure.model';
import { GetSearchBySpecialityRequestModel } from '../modals/getSearchBySpeciality.model';
import { GetSearchByProcedureRequestModelInterface } from '../modals/interfaces/getSearchByProcedure-models.interface';
import { GetSearchBySpecialityRequestModelInterface, GetSearchBySpecialityResponseModelInterface } from '../modals/interfaces/getSearchBySpeciality-models.interface';
import { FadMedicalIndexParamType } from '../modals/types/fad.types';
@Injectable()
export class FadMedicalIndexService {
  constructor(private http: AuthHttp, 
    private authService: AuthService,
    private fadSearchResultsService:FadSearchResultsService) { }

  public fetchMedicalIndex(request: FadMedicalIndexRequestModal): Observable<GetSearchBySpecialityResponseModelInterface> {
    if (request.type === FadMedicalIndexParamType.procedures) {

      // Once We received URL have to update in (FadConstants.urls.fadVitalsProcedureUrl)
      const ProcedureSearchReq: GetSearchByProcedureRequestModelInterface = new GetSearchByProcedureRequestModel();
      ProcedureSearchReq.setUserId(this.authService.useridin).setLocale(FadConstants.defaults.locale + '');
      if (this.authService.getFadHccsFlag() !== null) {
        ProcedureSearchReq['hccsFlag'] = this.authService.getFadHccsFlag();
      }
      const mleIndicator = this.authService.getMleEligibility();
      if (this.authService.useridin) {
        ProcedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      }

      // adhoc fix for KLO-1722
      // fix is to call encryptFadPost instead of encryptPost
      return this.http.encryptFadPost(FadConstants.urls.fadVitalsProcedureUrl, ProcedureSearchReq).map(response => {
        return response;
      });
    } else if (request.type === FadMedicalIndexParamType.specialities) {
      const specialitySearchReq: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();
      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        specialitySearchReq.setUserId(this.authService.useridin);
      }
      if (this.authService.getFadHccsFlag() !== null) {
        specialitySearchReq['hccsFlag'] = this.authService.getFadHccsFlag();
      }
      
      let lastSelectedNetworkId = FadConstants.defaults.networkId;
      const lastSelectedPlanOption = this.fadSearchResultsService.getLastSelectedPlanOption();
      if(lastSelectedPlanOption && lastSelectedPlanOption.getNetworkId()){
        lastSelectedNetworkId = lastSelectedPlanOption.getNetworkId();
      }
      specialitySearchReq.setNetworkId( lastSelectedNetworkId);

      // adhoc fix for KLO-1722
      // fix is to call encryptFadPost instead of encryptPost
      return this.http.encryptFadPost(FadConstants.urls.fadVitalsSpecialitiesUrl, specialitySearchReq).map(response => {
        return response;
      });
    }
  }
}
