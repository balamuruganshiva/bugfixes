import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { AlertService, AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadCostBreakdownService } from '../fad-cost-breakdown/fad-cost-breakdown.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadSuggestAnEditDialogComponent } from '../fad-suggest-an-edit-dialog/fad-suggest-an-edit-dialog.component';
import { FadService } from '../fad.service';
import { FadDoctorProfileRequestModel, FadDoctorRatingsRequestModel, FadDoctorRatingsResponseModel, FadProfessionalResponseModel } from '../modals/fad-doctor-profile-details.model';
import { FadSuggestAnEditDialog_CorrectionType, FadSuggestAnEditDialog_InputData } from '../modals/fad-suggest-an-edit-dialog.model';
import { FadDoctorProfileRequestModelInterface, FadDoctorRatingsRequestModelInterface, FadDoctorRatingsResponseModelInterface, FadLocationDetailsInterface, FadProfessionalResponseModelInterface } from '../modals/interfaces/fad-doctor-profile-details.interface';
import { CustomizedAddressInfoForDisplayInterface } from '../modals/interfaces/fad-doctor-profile.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadSuggestAnEditDialog_CorrectionTypeInterface, FadSuggestAnEditDialog_InputDataInterface } from '../modals/interfaces/fad-suggest-an-edit-dialog.interface';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';
import { BreadCrumb } from '../utils/fad.utils';
import { FadDoctorProfileService } from './fad-doctor-profile.service';

@Component({
  selector: 'app-fad-doctor-profile',
  templateUrl: './fad-doctor-profile.component.html',
  styleUrls: ['./fad-doctor-profile.component.scss']
})
export class FadDoctorProfileComponent implements OnInit, OnDestroy, StarRatingComponentConsumer {
  public doctorProfile: any;
  public doctorName: string;
  public doctorDegree: string;
  public specialityNames = '';
  public identifiers = new Array();
  public languages = new Array();
  public certificates = new Array();
  public education = {};
  public awards = new Array();
  public doctorLocationsCustomizedAddressList: CustomizedAddressInfoForDisplayInterface[] = [];
  public hospitalAffiliationsList: any[] = []; // FVProSRAffilitatedHospital[] = [];  
  public doctorStarRating: StarRatingComponentInputModelInterface;
  public doctorsStarRating = new Array();
  public doctorReviews = new Array();
  public acceptedNetworks = new Array();
  public locationDetails = new Array();

  public pcpidVisibleFlag: boolean;
  public inNetworkFlag: boolean;
  public outOfNetworkFlag: boolean;
  public noNetworkSelectedFlag: boolean;
  public registeredUserFlag: boolean;
  public anonymousUserFlag: boolean;
  private specialityNamesList: string[] = [];
  public isDisplaySpinnerProfessional = false;
  public isShowProfessionalDetialsSection = false;
  private selectedLocationIndex = 0;
  public fadProfessionalResposeData: FadProfessionalResponseModelInterface;
  public selectedLocationDetails: FadLocationDetailsInterface;
  public startRating: StarRatingComponentInputModelInterface;
  public accordianToggleStatus: any = {};
  fadDoctorRatingsResponseData: FadDoctorRatingsResponseModelInterface;
  public fadLandingpagesearchcriteria: any = {};

  public disclaimers: any = [];
  public disclaimerToplist: any = [];
  public disclaimerBottomlist: any = [];
  networkId: number;

  reviewsListLimit = 3;
  reviewsLoadMoreLimit = 5;

  // Procedure details
  public isProcedure = false;
  public procedureTitle = '';
  public procedureId = 0;
  public acceptableReviews = false;
  public icon = false;
  public chapter224 = false;
  public mleEligibility: string;
  public medicareuser = true;
  public toolTipTxt: string;
  public tierTooltipDescription: string;
  public fasFlag = false;
  public tierTooltip = new Array();
  public fasFlagAward = false;
  public displayRatealinkdentalnetwork = true;
  public awardIndex = 0;
  public npFlag = false;
  public profileTooltip = new Array();
  public npToolTipDescription = '';
  public identifierToolTipDescription = '';
  public identifierFlag = false;
  public bcToolTipDescription = '';
  public bcFlag = false;
  public gawdToolTipDescription = '';
  public gawdFlag = false;
  public onRecordDiclaimers: any;
  public disclaimersFlag: boolean;
  public disclaimersText: string;
  public networkChanged: string;
  public fadDoctorProfileData: FadProfessionalResponseModelInterface = null;
  disclaimerBcbsBottomCostModule: any;
  disclaimerBcbsTopProfile: any;
  private isMobileView: boolean = false;

  constructor(private router: Router,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private fadDoctorProfileService: FadDoctorProfileService,
    private fadSearchResultsService: FadSearchResultsService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    public authService: AuthService,
    private fadService: FadService,
    private fadCostBreakdownService: FadCostBreakdownService,
    private facilityProfileService: FadFacilityProfileService,
    private authHttp: AuthHttp,
    private fadSearchListService: FadSearchListService,
    public dialogRef: MatDialog
  ) { }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.isMobileView = event.target.innerWidth <= 992;
  }

  public openSuggestAnEditDialog() {

      this.alertService.resetErrorObject();
      const feedBackValues: FadSuggestAnEditDialog_CorrectionTypeInterface = new FadSuggestAnEditDialog_CorrectionType();
      feedBackValues.correctionType = this.fadProfessionalResposeData.feedbackValues.correctionType;

      const suggestAnEditDialogInput: FadSuggestAnEditDialog_InputDataInterface = new FadSuggestAnEditDialog_InputData();
      suggestAnEditDialogInput.feedBackValues = feedBackValues;
      suggestAnEditDialogInput.suggestingEditFor = this.fadProfessionalResposeData.doctorName;
      suggestAnEditDialogInput.providerIdentifier = this.selectedLocationDetails.identifiers;
      suggestAnEditDialogInput.providerAddress = this.selectedLocationDetails.address;
      suggestAnEditDialogInput.providerPhone = this.selectedLocationDetails.phone;

      let dialogRef = this.dialogRef.open(FadSuggestAnEditDialogComponent, {
        // height: this.isMobileView ? '550px' : '530px',
        // width: '500px',
        data: suggestAnEditDialogInput
      });

      dialogRef.afterClosed().subscribe(result => {
        //console.log(result); 
        if (result) {
          window.scrollTo(0, 0);
          if (result.result === 0) {
            this.alertService.setAlert('Success', '', AlertType.Success);
          } else {
            this.alertService.setAlert('Error', '', AlertType.Failure);
          }
        }
      });

    
  }

  ngOnInit() {
    try {
      this.alertService.resetErrorObject();
      this.isMobileView = window.innerWidth <= 992;
      this.fadSearchListService.isFilterChanged(false);
      this.chapter224 = this.authService.getMLEIndicator() === 'lite';

      if (JSON.parse(sessionStorage.getItem('tiersLabel'))) {
        this.tierTooltip = JSON.parse(sessionStorage.getItem('tiersLabel'));
      }

      if (JSON.parse(sessionStorage.getItem('profileLabel'))) {
        this.profileTooltip = JSON.parse(sessionStorage.getItem('profileLabel'));
      }

      if (this.authService.authToken != null) {
        if (this.authService.authToken.userType != null || this.authService.authToken.userType != undefined)
          this.medicareuser = this.authService.authToken.userType.toLowerCase() == 'medicare' ? false : true;
      }

      this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Doctor Details').setUrl('/fad/doctor-profile'));
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      const affiliatedlinkedid = sessionStorage.getItem('linkedAffiliationId');
      this.mleEligibility = this.authService.getMleEligibility();
      if (searchCriteria) {
        this.isProcedure = searchCriteria.getSearchText().isProcedure();
        this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
        if (affiliatedlinkedid == '' || affiliatedlinkedid == null || affiliatedlinkedid == 'null') {
          this.isProcedure = searchCriteria.getSearchText().isProcedure();
          this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
        } else {
          this.isProcedure = false;
        }
        this.networkId =
          searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
            ? searchCriteria.getPlanName().getNetworkId()
            : FadConstants.defaults.networkId;
        if (this.networkId == 311005006 || this.networkId == 311005007) {
          this.displayRatealinkdentalnetwork = false;
        }
      }
      console.log(this.fadDoctorProfileData, this.route.snapshot.data.fadProfessionalResposeData);
      const resolvedData = this.fadDoctorProfileData == null ? this.route.snapshot.data.fadProfessionalResposeData : this.fadDoctorProfileData;
      if (resolvedData && resolvedData.displaymessage && resolvedData.errormessage && resolvedData.result) {
        this.isShowProfessionalDetialsSection = false;
        this.alertService.setAlert(resolvedData.displaymessage, null, AlertType.Failure);
      } else {
        this.fadProfessionalResposeData = new FadProfessionalResponseModel();
        this.fadProfessionalResposeData = resolvedData;
        console.log(resolvedData);
        if (this.fadProfessionalResposeData.disclaimers) {
          this.disclaimers = this.fadProfessionalResposeData.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(function (disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerProfileTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(function (disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerProfileBottomList;
          });
          this.disclaimerBcbsBottomCostModule = this.disclaimers.filter(function (disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerBcbsBottomCostModule;
          });
          this.disclaimerBcbsTopProfile = this.disclaimers.filter(function (disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerBcbsTopProfile;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
        if (this.fadProfessionalResposeData.onRecordDiclaimers) {
          this.onRecordDiclaimers = this.fadProfessionalResposeData.onRecordDiclaimers;
          if (
            this.onRecordDiclaimers &&
            this.onRecordDiclaimers.category &&
            this.onRecordDiclaimers.category == 'on_record' &&
            this.onRecordDiclaimers.text
          ) {
            this.disclaimersFlag = true;
            this.disclaimersText = this.onRecordDiclaimers.text;
          }
        }
        this.fadProfessionalResposeData.locations = resolvedData.locations;
        this.networkChanged = sessionStorage.getItem('networkChange');
        console.log(this.networkChanged);

        const locationId = sessionStorage.getItem('locationId');
        console.log(locationId);
        this.loadDetailsBasedOnLocation(locationId, false);

        this.isShowProfessionalDetialsSection = true;
      }
      this.getNPToolTipDescription();
      this.getProfessionalratings();
      if (!this.isMobileView) {
        this.accordianToggleStatus.locationDetails = true;
        this.accordianToggleStatus.providerDetails = true;
      }
    } catch (exception) {
      this.isShowProfessionalDetialsSection = false;
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadDoctorProfileComponent,
        FadConstants.methods.ngOnInit
      );
    }
  }
  getNPToolTipDescription() {
    if (this.profileTooltip) {
      this.profileTooltip.forEach(tooltip => {
        if (tooltip.toolTip && tooltip.toolTip.code === 'PANP') {
          this.npToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PPIN') {
          this.identifierToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PBCH') {
          this.bcToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PPAA') {
          this.gawdToolTipDescription = tooltip.toolTip.description;
        }
      });
    }
    console.log('profile ToolTip', this.profileTooltip);
  }

  getToolTipText(toolTip, awardname) {
    this.toolTipTxt = '';

    return this.toolTipTxt;
  }

  getToolTipDescription(toolTip, tier) {
    this.tierTooltipDescription = '';
    if (toolTip) {
      toolTip.forEach(toolTips => {
        if (toolTips.toolTip && toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase() === tier.toLowerCase()) {
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    }
    return this.tierTooltipDescription;
  }

  fasIcon() {
    this.fasFlag = !this.fasFlag;
  }

  newNPIcon() {
    this.npFlag = !this.npFlag;
  }

  bcIcon() {
    this.bcFlag = !this.bcFlag;
  }

  gawdIcon() {
    this.gawdFlag = !this.gawdFlag;
  }

  identifierIcon() {
    this.identifierFlag = !this.identifierFlag;
  }

  fasIconAward(index) {
    this.fasFlagAward = !this.fasFlagAward;
    this.awardIndex = index;
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  toggleAccordion(listItem, status) {
    this.accordianToggleStatus[listItem] = status;
  }

  getRating(ratings, totalReviews) {
    this.startRating = new StarRatingComponentInputModel();

    this.startRating.totalRatings = parseFloat(!totalReviews ? 0 : totalReviews);
    this.startRating.overAllRating = parseFloat(!ratings ? 0 : ratings);
    return this.startRating;
  }

  public getReviewRating(ratings) {
    this.startRating = new StarRatingComponentInputModel();
    this.startRating.overAllRating = parseFloat(!ratings ? 0 : ratings);

    this.startRating.showReviewCount = false;
    return this.startRating;
  }

  formatMobileNumer(primaryPhone) {
    if (primaryPhone && primaryPhone.length > 9) {
      return `(${primaryPhone.substring(0, 3)}) ${primaryPhone.substring(3, 6)}-${primaryPhone.substring(6, 10)}`;
    } else {
      return primaryPhone;
    }
  }

  redirectToFacility(facilityId) {
    if (facilityId) {
      this.facilityProfileService.facilityProfile = facilityId;
      sessionStorage.setItem('facilityProfileId', facilityId.toString());
      sessionStorage.setItem('facilityLocationFlag', 'true');
      this.router.navigate([FadConstants.urls.fadFacilityProfilePage]);
    }
  }

  loadDetailsBasedOnLocation(locationsId, change: boolean) {
      this.awards = [];
      sessionStorage.setItem('locationId', locationsId);
      this.selectedLocationIndex = locationsId;
      if (change) {
        const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
        const professionalId = parseInt(sessionStorage.getItem('professionalId'));

        const networkId = (searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()) ?
          searchCriteria.getPlanName().getNetworkId() : FadConstants.defaults.networkId;
        const geoLocation = (searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo) ?
          searchCriteria.getZipCode().geo : FadConstants.defaults.geo;

        const locationId = locationsId;

        const fadDoctorProfileRequestParams: FadDoctorProfileRequestModelInterface = new FadDoctorProfileRequestModel();
        fadDoctorProfileRequestParams.setGeoLocation(geoLocation)
          .setProfessional(professionalId)
          .setNetworkId(networkId)
          .setLocationId(Number(locationId));
        if (sessionStorage.getItem('linkedAffiliationId')) {
          fadDoctorProfileRequestParams['linkedAffiliationId'] = sessionStorage.getItem('linkedAffiliationId');
        }

        else if (searchCriteria && searchCriteria.getSearchText().isProcedure()) {
          const procedureID = searchCriteria.getSearchText().getProcedureId();
          fadDoctorProfileRequestParams.setProcedureId(procedureID);
          fadDoctorProfileRequestParams.setRadius(sessionStorage.getItem('radius') != 'null' ? Number(sessionStorage.getItem('radius')) : 25);
        }

        const authUserId = this.authService.useridin;

        if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {

          fadDoctorProfileRequestParams.useridin = this.authService.useridin;
        }
        const mleIndicator = this.authService.getMleEligibility();
        fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
        this.authHttp.showSpinnerLoading();
        this.fadDoctorProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(data => {

          this.fadDoctorProfileData = data;
          this.ngOnInit();
          this.authHttp.hideSpinnerLoading();
        },error => {
          this.authHttp.hideSpinnerLoading();
        })
      }

      this.selectedLocationDetails = this.fadProfessionalResposeData.locations.find(p => p.id.toString() === locationsId);

      if (this.selectedLocationDetails && this.selectedLocationDetails.awards) {
        this.selectedLocationDetails.awards.forEach(award => {
          this.awards.push(award);
        });
      }
      if (this.selectedLocationDetails && this.selectedLocationDetails.tiers && this.selectedLocationDetails.tiers.description) {
        this.getToolTipDescription(this.tierTooltip, this.selectedLocationDetails.tiers.description);
      }
      this.accordianToggleStatus = {};    

  }

  public copyIdentifierValue(event, inputId: string): void {
    const element: any = document.querySelector('#' + inputId);
    element.select();
    document.execCommand('copy');
    element.setSelectionRange(0, 0);
  }

  public doAuthentication() {
    throw new Error('yet to be coded');
  }

  public showCostBreakdown(providerName, facilityCost, costBenefit) {
    this.fadCostBreakdownService.costBenefitsData = costBenefit;
    this.fadCostBreakdownService.facilityCostData = facilityCost;
    this.fadCostBreakdownService.providerName = providerName;
    this.fadCostBreakdownService.parentPage = FadConstants.text.doctorPage;
    this.router.navigate([`/fad/cost-breakdown`]);
  }

  public getDirections(location, event): void {
    const locationURL = 'http://maps.google.com/?q=' + encodeURI(location);
    window.open(locationURL, '_self');
  }

  public isAnonymousUser() {
    
      let returnValue = false;
      const userid = this.authService.useridin;
      returnValue = userid && userid !== 'undefined' && userid !== 'null' ? false : true;
      return returnValue;
    
  }

  private getProfessionalratings(): void {
    this.isDisplaySpinnerProfessional = true;
    const FadDoctorProfileRequestParams: FadDoctorRatingsRequestModelInterface = new FadDoctorRatingsRequestModel();
    const ratingsIdentifier: string = this.fadProfessionalResposeData['ratingsIdentifier'];
    const reviewIdentifier: string = this.fadProfessionalResposeData['reviewIdentifier'];
    try {
      FadDoctorProfileRequestParams.setRatingIdentifier(ratingsIdentifier);
      FadDoctorProfileRequestParams.setReviewIdentifier(reviewIdentifier);
      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        FadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }
      this.fadDoctorProfileService.getProfessionalratings(FadDoctorProfileRequestParams).subscribe(
        responseData => {
          if (responseData) {
            this.fadDoctorRatingsResponseData = new FadDoctorRatingsResponseModel();
            this.fadDoctorRatingsResponseData = responseData;
          }
        },
        error => {
          this.isDisplaySpinnerProfessional = false;
        }
      );

    } catch (exception) {
      this.isDisplaySpinnerProfessional = false;
    }
  }

  public loadMoreReviews() {
    this.reviewsListLimit += this.reviewsLoadMoreLimit;
  }

  // Methods to convert Transaction amount into decimal values
  public convertAmountToBaseValue(value) {
    return Math.trunc(value);
  }

  public reviewPage() {
    if (
      this.authService.isAuthenticated() &&
      this.authService.isLogin() &&
      this.authService.getScopeName() === 'AUTHENTICATED-AND-VERIFIED' && this.fadProfessionalResposeData
    ) {
      sessionStorage.setItem('doctorreviewer', this.fadProfessionalResposeData['doctorName'].toString());
      sessionStorage.setItem('reviewIdentifier', this.fadProfessionalResposeData['reviewIdentifier'].toString());
      this.router.navigate(['/fad/review']);
    } else {
      this.router.navigate(['./login']);
    }
  }
  public convertAmountToDecimalValue(value) {
    const int_part = Math.trunc(value);
    const float_part = Number((value - int_part).toFixed(2));
    const decimal: string[] = float_part.toString().split('.');
    if (!decimal[1]) {
      const zero = '00';
      return zero;
    }

    return decimal[1];
  }

  convertDate(date) {
    if (date) {
      return moment(date, 'YYYYMMDD').format();
    } else {
      return '';
    }
  }

  additionalCostExpantion() {
    this.icon = !this.icon;
  }

  public requestWrittenEstimte() {
    this.fadService.requestWrittenEstimate();
  }
  public reviewBenefits(): void {
    this.fadService.reviewMyBenfits();
  }

  public impersonation() {
    return this.authService.impersonation();
  }

  public reviewMessage(reviewsItem) {
    return (reviewsItem && reviewsItem.recommended === 'Yes' ? 'would ' : 'would not ') + ' recommend this provider to a friend.';
  }

  public notAcceptingPatients(acceptingNewPatients) {
    return this.fadService.notAcceptingPatients(acceptingNewPatients);
  }

  public acceptingPatients(acceptingNewPatients) {
    return this.fadService.acceptingPatients(acceptingNewPatients);
  }

  public acceptingPatientsPCP(acceptingNewPatients) {
    return this.fadService.acceptingPatientsPCP(acceptingNewPatients);
  }

  public acceptingPatientsSpecialist(acceptingNewPatients) {
    return this.fadService.acceptingPatientsSpecialist(acceptingNewPatients);
  }

  public acceptingFamilyPatients(acceptingNewPatients) {
    return this.fadService.acceptingFamilyPatients(acceptingNewPatients);
  }
}
