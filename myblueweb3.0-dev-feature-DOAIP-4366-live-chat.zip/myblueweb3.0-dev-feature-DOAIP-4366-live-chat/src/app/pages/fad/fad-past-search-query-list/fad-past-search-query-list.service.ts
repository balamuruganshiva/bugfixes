import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { FadConstants } from '../constants/fad.constants';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadVitalsSearchHistoryResponseModelInterface } from '../modals/interfaces/fad-vitals-collection.interface';

@Injectable()
export class FadPastSearchQueryListService {
  public searchControlValues: FadLandingPageSearchControlValuesInterface = null;

  constructor(private bcbsmaHttpService: BcbsmaHttpService) {}

  getVitalsSearchHistory(): Observable<FadVitalsSearchHistoryResponseModelInterface> {
    const url = FadConstants.jsonurls.fadSearchHistoryUrl;
    return this.bcbsmaHttpService.get(url);
  }
}
