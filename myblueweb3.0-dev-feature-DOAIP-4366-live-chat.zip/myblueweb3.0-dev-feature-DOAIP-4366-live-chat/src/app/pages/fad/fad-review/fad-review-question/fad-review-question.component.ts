import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FadReviewQuestion } from '../../modals/fad-review-questions.modal';
import { StarRatingComponentConsumer } from '../../modals/interfaces/fad.interface';

@Component({
  selector: 'app-fad-review-question',
  templateUrl: './fad-review-question.component.html',
  styleUrls: ['./fad-review-question.component.scss']
})
export class FadReviewQuestionComponent implements OnInit, StarRatingComponentConsumer {
  @Input() form: FormGroup;
  @Input() question: FadReviewQuestion;

  constructor() { }

  ngOnInit() {
  }

  ratingChanged(event) {
    this.form.controls[event.id].setValue(event.currentRating);
  }
}
