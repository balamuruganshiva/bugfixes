import { Injectable } from '@angular/core';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';

@Injectable()
export class FadFacilityCompareService {
  public searchResults: GetSearchByProfessionalResponseModelInterface;
  public searchData;
  public compareString = '';
  public costInfo: any;

  constructor(private bcbsmaHttpService: BcbsmaHttpService,
    private authService: AuthService) { }

  getCompareTableDetail() {
    const facilityIdList = sessionStorage.getItem(FadConstants.storageVars.searchItemCompare);
    if (this.compareString || (facilityIdList && facilityIdList.length > 1)) {
      const compareUrl = FadConstants.urls.fadCompareFacilitys;
      const request = {
        useridin: this.authService.useridin,
        facilityIdList: this.compareString ? this.compareString : facilityIdList
      };
      if (this.authService.getFadHccsFlag() !== null) {
        request['hccsFlag'] = this.authService.getFadHccsFlag();
      }

      return null;
    }

    const url = FadConstants.jsonurls.fadFacilityCompareUrl;
    return this.bcbsmaHttpService.get(url);
  }

  setSearchResult(searchResults) {
    this.searchResults = searchResults;
  }

  getSearchResult() {
    return this.searchResults;
  }

  setCompareStirng(compareString: string) {
    sessionStorage.setItem(FadConstants.storageVars.searchItemCompare, compareString);
    this.compareString = compareString;
  }

  setCostInfo(costInfo) {
    sessionStorage.setItem('faciltyCostInfo', JSON.stringify(costInfo));
    this.costInfo = costInfo;
  }

  getCostInfo() {
    const costInfo = sessionStorage.getItem('faciltyCostInfo');
    if (costInfo) {
      const costInfoJson = JSON.parse(costInfo);
      return costInfoJson;
    }
    return null;
  }
}
