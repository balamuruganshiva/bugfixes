import { FadIdentifiersInterface } from "./interfaces/fad-facility-profile-details.interface";
import { FadSuggestAnEditDialog_CorrectionTypeInterface, FadSuggestAnEditDialog_FeedBackValuesInterface, FadSuggestAnEditDialog_InputDataInterface, FadSuggestAnEditSubmitFeedbackMessageInterface, FadSuggestAnEditSubmitFeedbackRequestInterface } from "./interfaces/fad-suggest-an-edit-dialog.interface";


export class FadSuggestAnEditDialog_FeedBackValues implements FadSuggestAnEditDialog_FeedBackValuesInterface {
    feedBackValues:FadSuggestAnEditDialog_CorrectionTypeInterface;
}

export class FadSuggestAnEditDialog_CorrectionType implements FadSuggestAnEditDialog_CorrectionTypeInterface {
    correctionType:string[];
}

export class FadSuggestAnEditDialog_InputData implements FadSuggestAnEditDialog_InputDataInterface{
    suggestingEditFor: string;
    feedBackValues: FadSuggestAnEditDialog_CorrectionType;
    providerIdentifier:FadIdentifiersInterface[];
    providerAddress: string;
    providerPhone: string;
}

export class FadSuggestAnEditSubmitFeedbackRequest implements FadSuggestAnEditSubmitFeedbackRequestInterface {
    fromAddress: string;
    toAddress: string;
    subject: string;
    emailMessage : FadSuggestAnEditSubmitFeedbackMessageInterface;
    paramGroupName: string;
}


export class FadSuggestAnEditSubmitFeedbackMessage implements FadSuggestAnEditSubmitFeedbackMessageInterface {
    providerName:string;
    providerIdentifier:string[];
    providerNetwork:string;
    issue:string[];
    providerAddress: string;
    providerPhone: string;
}
