import {
  ClearSearchResultFlagInterface,
  FadFacilityListComponentInputModelInterface,
  FadFacilityListComponentOutputModelInterface,
  FadSearchListComponentInputModelInterface,
  FadSearchListComponentOutputModelInterface,
  FadSpecialtyListComponentInputModelInterface,
  FadSpecialtyListComponentOutputModelInterface
} from './interfaces/fad-search-list.interface';
import { FadFacilityInterface, GetSearchByFacilityResponseModelInterface } from './interfaces/getSearchByFacility-models.interface';
import { GetSearchByProfessionalResponseModelInterface } from './interfaces/getSearchByProfessional-models.interface';
import { GetSearchBySpecialtyResponseModelInterface } from './interfaces/getSearchBySpeciality-models.interface';
// import { FadVitalsProfessionalsSearchResponseModelInterface } from './interfaces/fad-vitals-collection.interface';

export class FadSearchListComponentInputModel implements FadSearchListComponentInputModelInterface {
  public searchResults: GetSearchByProfessionalResponseModelInterface;
}

export class FadSearchListComponentOutputModel implements FadSearchListComponentOutputModelInterface {
  selectedProfessionals: FadFacilityInterface[];
}

export class FadFacilityListComponentInputModel implements FadFacilityListComponentInputModelInterface {
  public facilityResults: GetSearchByFacilityResponseModelInterface;
}

export class FadFacilityListComponentOutputModel implements FadFacilityListComponentOutputModelInterface {}

export class FadSpecialtyListComponentInputModel implements FadSpecialtyListComponentInputModelInterface {
  public specialtyResults: GetSearchBySpecialtyResponseModelInterface;
}

export class FadSpecialtyListComponentOutputModel implements FadSpecialtyListComponentOutputModelInterface {}

export class ClearSearchResultFlagModel implements ClearSearchResultFlagInterface {
  clearFlag = false;
  type: string;
}
