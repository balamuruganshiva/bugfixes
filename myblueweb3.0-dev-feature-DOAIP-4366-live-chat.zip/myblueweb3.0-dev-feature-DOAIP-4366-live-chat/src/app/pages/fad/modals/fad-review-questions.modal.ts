export class FadReviewQuestion {
  id: number;
  text: string;
  required: boolean;
  type: string;
  value: string;
}
