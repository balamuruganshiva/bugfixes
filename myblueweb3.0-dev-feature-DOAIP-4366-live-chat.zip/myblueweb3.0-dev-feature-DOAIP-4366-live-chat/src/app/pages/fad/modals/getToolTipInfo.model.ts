import { GeneralError } from '../../../shared/models/generic-app.model';
import { GetToolTipInfoRequestModelInterface } from './interfaces/getToolTipInfo-models.interface';

export class GetToolTipInfoRequestModel implements GetToolTipInfoRequestModelInterface {
  useridin: string;
  locale: string;

  getUserId(): string {
    return this.useridin;
  }
  setUserId(useridin: string): GetToolTipInfoRequestModel {
    this.useridin = useridin;
    return this;
  }
}
