import { GeneralError } from '../../../shared/models/generic-app.model';
import {
    GetSearchByProcedureRequestModelInterface,
} from './interfaces/getSearchByProcedure-models.interface';

export class GetSearchByProcedureRequestModel implements GetSearchByProcedureRequestModelInterface {
    useridin: string;
    locale: string;

    getUserId(): string {
        return this.useridin;
    }
    setUserId(useridin: string): GetSearchByProcedureRequestModel {
        this.useridin = useridin;
        return this;
    }

    getLocale(): string {
        return this.locale;
    }
    setLocale(locale: string): GetSearchByProcedureRequestModel {
        this.locale = locale;
        return this;
    }
}
