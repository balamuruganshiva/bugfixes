export interface FadMedicalIndexRequestModalInterface {
    type: string;

    setType(type: string): FadMedicalIndexRequestModalInterface;
}
