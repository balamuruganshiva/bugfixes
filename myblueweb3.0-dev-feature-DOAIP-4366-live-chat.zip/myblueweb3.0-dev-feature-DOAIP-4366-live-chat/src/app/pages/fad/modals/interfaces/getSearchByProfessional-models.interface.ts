import { GeneralErrorInterface } from '../../../../shared/models/interfaces/generic-app-models.interface';
import { FadAmenitiesInterface, FadAwardsInterface } from './fad-facility-profile-details.interface';
import { FilterCheckboxItemInterface, FilterListItemInterface, GrpHospitalAffiliationFilterListItemInterface } from './fad-search-filter.interface';

export interface GetSearchByProfessionalRequestModelInterface {
  geoLocation: string;
  limit: number;
  page: number;
  radius: number;
  networkId: number;
  searchSpecialtyId: string;
  procedureId: string;
  name: string;
  searchForTH: boolean;
  expertiseTypeCode: string;

  useridin: string;
  sort: string;
  contractAcceptingNewPatients: string;
  offersTeleHealth: string;
  techSavvy: string;
  inNetwork: string;
  professionalGender: string;
  isPcp: string;
  hospitalAffiliationCategory: string;
  hospitalAffiliationId: string;
  groupAffiliationCategory: string;
  groupAffiliationId: string;
  professionalLanguages: string;
  aggregateOverallRating: string;
  agestreatedTypeCode: string;
  treatmentMethodsTypeCode: string;
  disorderTreatedTypeCode: string;
  isChoicePcp: string;
  bdcId: string;
  cqmId: string;
  awardId: string;
  providerId: string;

  getProviderId(): string;
  setProviderId(providerId: string): GetSearchByProfessionalRequestModelInterface;

  getGeoLocation(): string;
  setGeoLocation(geoLocation: string): GetSearchByProfessionalRequestModelInterface;

  getLimit(): number;
  setLimit(limit: number): GetSearchByProfessionalRequestModelInterface;

  getPage(): number;
  setPage(page: number): GetSearchByProfessionalRequestModelInterface;

  getRadius(): number;
  setRadius(radius: number): GetSearchByProfessionalRequestModelInterface;

  getNetworkId(): number;
  setNetworkId(networkId: number): GetSearchByProfessionalRequestModelInterface;

  getSearchSpecialtyId(): string;
  setSearchSpecialtyId(searchSpecialtyId: string): GetSearchByProfessionalRequestModelInterface;

  getSearchProcedureId(): string;
  setSearchProcedureId(procedureId: string): GetSearchByProfessionalRequestModelInterface;

  getName(): string;
  setName(name: string): GetSearchByProfessionalRequestModelInterface;

  getUserIdIn(): string;
  setUserIdIn(useridin: string): GetSearchByProfessionalRequestModelInterface;

  getSort(): string;
  setSort(sort: string): GetSearchByProfessionalRequestModelInterface;

  getAcceptingNewPatients(): string;
  setAcceptingNewPatients(contractAcceptingNewPatients: string): GetSearchByProfessionalRequestModelInterface;

  getOffersTeleHealth(): string;
  setOffersTeleHealth(offersTeleHealth: string): GetSearchByProfessionalRequestModelInterface;

  getTechSavvy(): string;
  setTechSavvy(techSavvy: string): GetSearchByProfessionalRequestModelInterface;

  getInNetwork(): string;
  setInNetwork(inNetwork: string): GetSearchByProfessionalRequestModelInterface;

  getProfessionalGender(): string;
  setProfessionalGender(professionalGender: string): GetSearchByProfessionalRequestModelInterface;

  getisPcp(): string;
  setisPcp(isPcp: string): GetSearchByProfessionalRequestModelInterface;

  getHospitalAffiliationId(): string;
  setHospitalAffiliationId(hospitalAffiliationId: string): GetSearchByProfessionalRequestModelInterface;

  getGroupAffiliationId(): string;
  setGroupAffiliationId(groupAffiliationId: string): GetSearchByProfessionalRequestModelInterface;

  getGroupAffiliationCategory(): string;
  setGroupAffiliationCategory(groupAffiliationCategory: string): GetSearchByProfessionalRequestModelInterface;

  getHospitalAffiliationCategory(): string;
  setHospitalAffiliationCategory(hospitalAffiliationCategory: string): GetSearchByProfessionalRequestModelInterface;

  getProfessionalLanguages(): string;
  setProfessionalLanguages(professionalLanguages: string): GetSearchByProfessionalRequestModelInterface;

  getAggregateOverallRating(): string;
  setAggregateOverallRating(aggregateOverallRating: string): GetSearchByProfessionalRequestModelInterface;

  getAgestreatedTypeCode(): string;
  setAgestreatedTypeCode(agestreatedTypeCode: string): GetSearchByProfessionalRequestModelInterface;

  getTreatmentMethodsTypeCode(): string;
  setTreatmentMethodsTypeCode(treatmentMethodsTypeCode: string): GetSearchByProfessionalRequestModelInterface;

  getDisorderTreatedTypeCode(): string;
  setDisorderTreatedTypeCode(disorderTreatedTypeCode: string): GetSearchByProfessionalRequestModelInterface;

  getAwardsTypeCodes(): string;
  setAwardsTypeCodes(awardId: string): GetSearchByProfessionalRequestModelInterface;

  getProviderType(): string;
  setProviderType(providerType: string): GetSearchByProfessionalRequestModelInterface;

  getBcdTypeCodes(): string;
  setBcdTypeCodes(bdcId: string): GetSearchByProfessionalRequestModelInterface;

  getTiers(): string;
  setTiers(tiers: string): GetSearchByProfessionalRequestModelInterface;

  getCqms(): string;
  setCqms(cqmId: string): GetSearchByProfessionalRequestModelInterface;

  getIsChoicePcp(): string;
  setIsChoicePcp(isChoicePcp: string): GetSearchByProfessionalRequestModelInterface;

  getSearchForTH(): boolean;
  setSearchForTH(searchForTH: boolean): GetSearchByProfessionalRequestModelInterface;

  getExpertiseTypeCode(): string;
  setExpertiseTypeCode(expertiseTypeCode: string): GetSearchByProfessionalRequestModelInterface;
}

export interface GetSearchByProfessionalResponseModelInterface extends GeneralErrorInterface {
  totalCount: number;
  professionals: FadProfessionalInterface[];
  costDetails: CostDetails;
  facets: FacetsListInterface;
  sort: string;
  disclaimers: Disclaimers[];
  pdfRequest: FadPdfRequestInterface;
  hpnZeroResults?: boolean;
}

export interface FadPdfRequestInterface {
  filters: string[];
  queryUrl: string;
  queue: boolean;
  source: string;
  searchParams: FadSearchParamsInterface;
}

export interface FadSearchParamsInterface {
  accountId: string;
  ci: string;
  dataLanguage: string;
  geoLocation: string;
  limit: string;
  memberNumber: string;
  name: string;
  networkId: string;
  page: string;
  radius: string;
  sort: string;
}

export interface CostDetails {
  memberCost: CostAmountDetails;
  employerCost: CostAmountDetails;
  procedureCost: CostAmountDetails;
}
export interface Disclaimers {
  text: string;
  category: string;
  priority: 0;
}

export interface CostAmountDetails {
  lower: number;
  upper: number;
}

export interface FadProfessionalInterface {
  doctorName: string; 
  specialty: string; 
  locations: FadLocationDetailsInterface[];
  reviews: FadReviewsListInterface;
  professionalId?: string;
  providerId?: string;
  isChecked: boolean;
  isDisabled: boolean;
  disclaimers?: object;
}

export interface FadLocationDetailsInterface {
  id: number; 
  name: string; 
  address: string; 
  phone: string;
  facilityCost?: MemberCost;
  amenities?: FadAmenitiesInterface[];
  tiers: FadTiersInterface;
  awards: FadAwardsInterface[];
  providerCost?: MemberCost;
  endDateDisclaimers?: FadEndDateDisclaimers;
}

export interface FadEndDateDisclaimers {
  futureTerminationDate: string;
  showEndDateDisclmrs: boolean;
  text: string;
}
export interface FadTiersInterface {
  description: string;
}

export interface MemberCost {
  memberCost: number;
}

export interface FadReviewsListInterface {
  overallRating: number; //     This is the city/state of the location
  percentRecommended: number; //     This is the percentRecommended
  totalRatings: number; //     This is the totalRatings
}

export interface FacetsListInterface {
  treatedTypeCodes: FilterListItemInterface[];
  overallRating: FilterListItemInterface[];
  acceptingNewPatients: FilterCheckboxItemInterface;
  teleHealth: FilterCheckboxItemInterface;
  fieldSpecialtyIds: FilterListItemInterface[];
  groupAffiliationIds: GrpHospitalAffiliationFilterListItemInterface[];
  hospitalAffiliationIds: GrpHospitalAffiliationFilterListItemInterface[];
  isChoicePcp: FilterCheckboxItemInterface;
  isPcp: FilterCheckboxItemInterface;
  locationGeo: FilterListItemInterface[];
  professionalGender: FilterListItemInterface[];
  professionalLanguages: FilterListItemInterface[];
  techSavvy: FilterCheckboxItemInterface;
  treatmentMethodsTypeCodes: FilterListItemInterface[];
  disordersTreatedTypeCodes: FilterListItemInterface[];
  inNetwork: FilterCheckboxItemInterface;
  awardTypeCodes: FilterListItemInterface[];
  tiers: FilterListItemInterface[];
  bdcTypeCodes: FilterListItemInterface[];
  cqms: FilterListItemInterface[];
  providerType: FilterListItemInterface[];
  expertiseTypeCodes: FilterListItemInterface[];
}

export interface FiltersMetadataInterface {
  filterPCP: FilterCheckboxItemInterface;
  filterAcceptingNewPatients: FilterCheckboxItemInterface;
  filterTeleHealth: FilterCheckboxItemInterface;
  filterTechSavvy: FilterCheckboxItemInterface;
  filterInNetwork: FilterCheckboxItemInterface;
  filterLocation: FilterListItemInterface;
  filterGender: FilterListItemInterface;
  filterLanguage: FilterListItemInterface;
  filterRating: FilterListItemInterface;
  filterAges: FilterListItemInterface;
  filterSpecialities: FilterListItemInterface;
  filterDisorders: FilterListItemInterface;
  filterTreatment: FilterListItemInterface;
  filterHospitalAffilation: GrpHospitalAffiliationFilterListItemInterface;
  filterGroupAffilation: GrpHospitalAffiliationFilterListItemInterface;
  filterProviderType: FilterListItemInterface;
  filterCqms: FilterListItemInterface;
  filterBcd: FilterListItemInterface;
  filterTiers: FilterListItemInterface;
  filterisChoicePcp: FilterCheckboxItemInterface;
  filterAwards: FilterListItemInterface;
  filterAreasOfExpertise: FilterListItemInterface;
}

export interface SortMetadataInterface {
  name: string;
  value: string;
  checked: boolean;
}
export interface FadProffessionalTierInterface {
  description: string;
}
