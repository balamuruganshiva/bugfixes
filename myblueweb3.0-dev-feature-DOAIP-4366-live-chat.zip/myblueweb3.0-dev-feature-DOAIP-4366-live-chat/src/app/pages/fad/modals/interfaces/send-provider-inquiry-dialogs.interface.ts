import { GeneralErrorInterface } from "../../../../shared/models/interfaces/generic-app-models.interface";

export interface SendProviderInquiryDialog_InputDataInterface {
    paramGroupName: string;
    fromAddress: string;
    emailMessage: MessageBody_InputDataInterface;
    subject: string
}

export interface MessageBody_InputDataInterface {
    emailBody: string;
}

export interface SendProviderInquiryDialogConfirmation_InputDataInterface {
    emailId: string;
    errorFlag: boolean;
}

export interface SendProviderInquiryDialog_OutputDataInterface extends GeneralErrorInterface {
    confirmationToBeSentTo: string;
    dialogDiscardedFlag?: boolean;
    connectionFailureError?: boolean;
}

