import { FormControl } from '@angular/forms';
import { GeneralError } from '../../../../shared/models/generic-app.model';
import { GeneralErrorInterface } from '../../../../shared/models/interfaces/generic-app-models.interface';
import { FadSearchResultsService } from '../../fad-search-results/fad-search-results.service';
import { FZCSRCity } from '../fad-vitals-collection.model';
import { FadLandingPageComponentMode, FadResourceTypeCode } from '../types/fad.types';

export interface FadLandingPageCompInputInterface {
  componentMode: FadLandingPageComponentMode;
  fadBaseSearchModel: FadLandingPageSearchControlValuesInterface;
}

export interface FadLandingPageCompOutputInterface {
  searchCriteria: FadLandingPageSearchControlValuesInterface;
}

export interface FadAutoCompleteOptionForSearchTextInterface {
  category: string;
  options: FadAutoCompleteComplexOptionInterface[];

  setCategory(category: string): FadAutoCompleteOptionForSearchTextInterface;
  addOption(option: FadAutoCompleteComplexOptionInterface): FadAutoCompleteOptionForSearchTextInterface;
}

export interface FadAutoCompleteComplexOptionInterface {
  getSimpleText(): string;
  setSimpleText(simpleText: string): FadAutoCompleteComplexOptionInterface;

  getContextText(): string;
  setContextText(contextText: string): FadAutoCompleteComplexOptionInterface;

  getInfoText(): string;
  setInfoText(infoText: string): FadAutoCompleteComplexOptionInterface;

  getLink(): FadLinkOptionInterface;
  setLink(text: string, href: string): FadAutoCompleteComplexOptionInterface;

  getResourceTypeCode(): FadResourceTypeCode;
  setResourceTypeCode(resourceCodeType: FadResourceTypeCode): FadAutoCompleteComplexOptionInterface;

  getSpecialityId(): string;
  setSpecialityId(specialityId: string): FadAutoCompleteComplexOptionInterface;

  getProcedureId(): string;
  setProcedureId(procedureId: string): FadAutoCompleteComplexOptionInterface;

  isProcedure(): boolean;
  setProcedure(isProcedure: boolean): FadAutoCompleteComplexOptionInterface;

  getDescriptionText(): string;
  setDescriptionText(descriptionText: string): FadAutoCompleteComplexOptionInterface;

  getNetworkId(): number;
  setNetworkId(networkId: number): FadAutoCompleteComplexOptionInterface;

  getLocationId(): number;
  setLocationId(networkId: number): FadAutoCompleteComplexOptionInterface;
}

export interface FadLinkOptionInterface {
  text: string;
  href: string;
}

export interface FadLandingPageSearchControlsModelInterface {
  searchTypeAheadControl: FormControl;
  zipCodeTypeAheadControl: FormControl;
  dependantNameControl: FormControl;
  planControl: FormControl;

  getValues(fadSearchResultsService: FadSearchResultsService): FadLandingPageSearchControlValuesInterface;
  setValues(searchControlValues: FadLandingPageSearchControlValuesInterface): FadLandingPageSearchControlsModelInterface;
  setControls(
    searchControlValues: FadLandingPageSearchControlsModelInterface,
    fadSearchResultsService: FadSearchResultsService
  ): FadLandingPageSearchControlsModelInterface;
}

export interface FadLandingPageSearchControlValuesInterface {
  getSearchText(): FadAutoCompleteComplexOptionInterface;
  setSearchText(searchText: FadAutoCompleteComplexOptionInterface): FadLandingPageSearchControlValuesInterface;

  getZipCode(): FZCSRCity;
  setZipCode(zipCode: FZCSRCity): FadLandingPageSearchControlValuesInterface;

  getDependantName(): FadAutoCompleteComplexOptionInterface;
  setDependantName(dependantName: FadAutoCompleteComplexOptionInterface): FadLandingPageSearchControlValuesInterface;

  getPlanName(): FadAutoCompleteComplexOptionInterface;
  setPlanName(planName: FadAutoCompleteComplexOptionInterface): FadLandingPageSearchControlValuesInterface;

  isAffilatedDoctorFlag(): boolean;
  setAffiliatedDoctorFlag(affiliatedDoctorFlag: boolean): FadLandingPageSearchControlValuesInterface;
}

export interface LandingPageResponseCacheModelInterface {
  dependantsList: FadMembersInfoInterface[];
  planOptions: FadAutoCompleteOptionForSearchTextInterface[];
  userId: string;
  zipCodeOptions: FZCSRCity[];

  getZipCodeOptions(): FZCSRCity[];
  setZipCodeOptions(zipCodeOptions: FZCSRCity[]): LandingPageResponseCacheModelInterface;
}

export interface FadMembersInfoRequestModelInterface {
  useridin: string;
}

export interface FadMembersInfoResponseModelInterface extends GeneralErrorInterface {
  membersInfoList: FadMembersInfoInterface[];
}

export interface FadMembersInfoInterface {
  changeHealthcareMemberId: string;
  fadVendorMemberNumber: string;
  subscriberFirstName: string;
  subscriberMiddleName: string;
  subscriberLastName: string;
  relation: string;
}
