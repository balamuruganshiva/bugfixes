import { FadIdentifiersInterface } from "./fad-facility-profile-details.interface";

export interface FadSuggestAnEditDialog_FeedBackValuesInterface {
    feedBackValues:FadSuggestAnEditDialog_CorrectionTypeInterface;
}

export interface FadSuggestAnEditDialog_CorrectionTypeInterface {
    correctionType:string[];
}

export interface FadSuggestAnEditDialog_InputDataInterface{
    suggestingEditFor: string;
    feedBackValues: FadSuggestAnEditDialog_CorrectionTypeInterface;
    providerIdentifier: FadIdentifiersInterface[];
    providerAddress: string;
    providerPhone: string;
}

export interface FadSuggestAnEditSubmitFeedbackRequestInterface{
    fromAddress?: string;
    toAddress?: string;
    subject?: string;
    emailMessage: FadSuggestAnEditSubmitFeedbackMessageInterface;
    paramGroupName: string;
}

export interface FadSuggestAnEditSubmitFeedbackMessageInterface {
    providerName:string;
    providerIdentifier:string[];
    providerNetwork:string;
    issue:string[];
    providerAddress:string;
    providerPhone:string;
}

