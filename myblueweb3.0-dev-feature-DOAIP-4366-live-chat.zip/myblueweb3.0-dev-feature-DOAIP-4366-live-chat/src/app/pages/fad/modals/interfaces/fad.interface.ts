import { FadLandingPageCompInputInterface } from './fad-landing-page.interface';
import { FadNoDocsPageInputDataModelInterface } from './fad-no-docs-page.interface';
import {
  FadFacilityCardComponentInputModelInterface,
  FadFacilityCardComponentOutputModelInterface,
  FadProfileCardComponentInputModelInterface,
  FadProfileCardComponentOutputModelInterface,
  FadProviderCardComponentInputModelInterface,
  FadProviderCardComponentOutputModelInterface
} from './fad-profile-card.interface';
import { FadSearchFilterComponentOutputModelInterface } from './fad-search-filter.interface';
import { FadSearchListComponentInputModelInterface, FadSearchListComponentOutputModelInterface } from './fad-search-list.interface';
import { FadFacilityInterface } from './getSearchByFacility-models.interface';
import { FadProfessionalInterface } from './getSearchByProfessional-models.interface';
import { FadSpecialtyInterface } from './getSearchBySpeciality-models.interface';

export interface FadLandingPageConsumer {
  miniSearchBarData: FadLandingPageCompInputInterface;
}

export interface FadSearchFilterConsumer {
  mobileHideByFilterOverlay: boolean;
  onSearchFilterComponentInteraction(fadSearchFilterComponentOutput: FadSearchFilterComponentOutputModelInterface): void;
}

export interface FadNoSearchResultsPageConsumer {
  noSearchResultsPageData: FadNoDocsPageInputDataModelInterface;
  isNoSearchResults: boolean;
}

export interface FadSearchListConsumer {
  searchListComponentInput: FadSearchListComponentInputModelInterface;
  onSearchListComponentInteraction(fadSeachListComponentOutput: FadSearchListComponentOutputModelInterface): void;
}

// tslint:disable-next-line:no-empty-interface
export interface StarRatingComponentConsumer {}

export interface FadProfileCardConsumer {
  getProfileCardInput(professional: FadProfessionalInterface): FadProfileCardComponentInputModelInterface;
  onProfileCardComponentInteraction(profileCardCompOutput: FadProfileCardComponentOutputModelInterface): void;
}

export interface FadFacilityCardConsumer {
  getProfileCardInput(facility: FadFacilityInterface): FadFacilityCardComponentInputModelInterface;
  onProfileCardComponentInteraction(facilityCardCompOutput: FadFacilityCardComponentOutputModelInterface): void;
}

export interface FadProviderCardConsumer {
  getProfileCardInput(provider: FadSpecialtyInterface): FadProviderCardComponentInputModelInterface;
  onProfileCardComponentInteraction(providerCardCompOutput: FadProviderCardComponentOutputModelInterface): void;
}

export interface BreadCrumbInterface {
  getLabel(): string;
  setLabel(label: string): BreadCrumbInterface;
  getUrl(): string;
  setUrl(url: string): BreadCrumbInterface;
  getStackIndex(): number;
  setStackIndex(stackIndex: number): BreadCrumbInterface;
}
