import { GeneralErrorInterface } from "../../../../shared/models/interfaces/generic-app-models.interface";

export interface GetVitalsTeleHealthDetailsResponseInterface {
    //specifying the telehealth flag
    teleHealthCd: boolean;

    //specifying the telehealth prod type
    teleHealthProdType: string;

    //specifying the telehealth vendor CD type
    teleHealthVendCd: string;

    //specifying the telehealth URL
    teleHealthUrl: string;
}

export interface GetVitalsTeleHealthDetailsRequestInterface {
    useridin: string;
}