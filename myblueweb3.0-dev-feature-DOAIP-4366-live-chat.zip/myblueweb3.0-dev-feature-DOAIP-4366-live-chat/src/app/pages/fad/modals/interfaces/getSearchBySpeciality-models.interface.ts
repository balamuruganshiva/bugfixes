import { GeneralErrorInterface } from '../../../../shared/models/interfaces/generic-app-models.interface';
import { FilterCheckboxItem, FilterListItem } from '../fad-search-filter.modal';
import { AwardDetailInterface } from './fad-doctor-profile-details.interface';
import { FilterCheckboxItemInterface, FilterListItemInterface, GrpHospitalAffiliationFilterListItemInterface } from './fad-search-filter.interface';
import { CostDetails, Disclaimers, FadLocationDetailsInterface, FadReviewsListInterface, MemberCost } from './getSearchByProfessional-models.interface';
export interface GetSearchBySpecialityRequestModelInterface {
  useridin: string;
  networkId: number;
  geoLocation: string;
  limit: number;
  page: number;
  radius: number;
  searchSpecialtyId: string;
  procedureId: string;
  name: string;
  searchForTH: boolean;

  sort: string;
  contractAcceptingNewPatients: string;
  offersTeleHealth: string;
  techSavvy: string;
  inNetwork: string;
  professionalGender: string;
  isPcp: string;
  groupAffiliationCategory: string;
  hospitalAffiliationCategory: string;
  hospitalAffiliationId: string;
  groupAffiliationId: string;
  professionalLanguages: string;
  aggregateOverallRating: string;
  agestreatedTypeCode: string;
  treatmentMethodsTypeCode: string;
  disorderTreatedTypeCode: string;
  providerType: string;
  isChoicePcp: string;
  bdcId: string;
  cqmId: string;
  awardId: string;
  tiers: string;

  getGeoLocation(): string;
  setGeoLocation(geoLocation: string): GetSearchBySpecialityRequestModelInterface;

  getLimit(): number;
  setLimit(limit: number): GetSearchBySpecialityRequestModelInterface;

  getPage(): number;
  setPage(page: number): GetSearchBySpecialityRequestModelInterface;

  getRadius(): number;
  setRadius(radius: number): GetSearchBySpecialityRequestModelInterface;

  getNetworkId(): number;
  setNetworkId(networkId: number): GetSearchBySpecialityRequestModelInterface;

  getSearchSpecialtyId(): string;
  setSearchSpecialtyId(searchSpecialtyId: string): GetSearchBySpecialityRequestModelInterface;

  getProcedureId(): string;
  setProcedureId(procedureId: string): GetSearchBySpecialityRequestModelInterface;

  getUserId(): string;
  setUserId(userId: string): GetSearchBySpecialityRequestModelInterface;

  getName(): string;
  setName(name: string): GetSearchBySpecialityRequestModelInterface;

  getSort(): string;
  setSort(sort: string): GetSearchBySpecialityRequestModelInterface;

  getAcceptingNewPatients(): string;
  setAcceptingNewPatients(contractAcceptingNewPatients: string): GetSearchBySpecialityRequestModelInterface;

  getOffersTeleHealth(): string;
  setOffersTeleHealth(offersTeleHealth: string): GetSearchBySpecialityRequestModelInterface;

  getTechSavvy(): string;
  setTechSavvy(techSavvy: string): GetSearchBySpecialityRequestModelInterface;

  getInNetwork(): string;
  setInNetwork(inNetwork: string): GetSearchBySpecialityRequestModelInterface;

  getProfessionalGender(): string;
  setProfessionalGender(professionalGender: string): GetSearchBySpecialityRequestModelInterface;

  getisPcp(): string;
  setisPcp(isPcp: string): GetSearchBySpecialityRequestModelInterface;

  getIsChoicePcp(): string;
  setIsChoicePcp(isChoicePcp: string): GetSearchBySpecialityRequestModelInterface;

  getTiers(): string;
  setTiers(tiers: string): GetSearchBySpecialityRequestModelInterface;

  getAwardsTypeCodes(): string;
  setAwardsTypeCodes(awardId: string): GetSearchBySpecialityRequestModelInterface;

  getBcdTypeCodes(): string;
  setBcdTypeCodes(bdcId: string): GetSearchBySpecialityRequestModelInterface;

  getCqms(): string;
  setCqms(cqmId: string): GetSearchBySpecialityRequestModelInterface;

  getHospitalAffiliationId(): string;
  setHospitalAffiliationId(hospitalAffiliationId: string): GetSearchBySpecialityRequestModelInterface;

  getGroupAffiliationId(): string;
  setGroupAffiliationId(groupAffiliationId: string): GetSearchBySpecialityRequestModelInterface;

  getGroupAffiliationCategory(): string;
  setGroupAffiliationCategory(groupAffiliationCategory: string): GetSearchBySpecialityRequestModelInterface;

  getHospitalAffiliationCategory(): string;
  setHospitalAffiliationCategory(hospitalAffiliationCategory: string): GetSearchBySpecialityRequestModelInterface;

  getProfessionalLanguages(): string;
  setProfessionalLanguages(professionalLanguages: string): GetSearchBySpecialityRequestModelInterface;

  getproviderType(): string;
  setproviderType(providerType: string): GetSearchBySpecialityRequestModelInterface;

  getAggregateOverallRating(): string;
  setAggregateOverallRating(aggregateOverallRating: string): GetSearchBySpecialityRequestModelInterface;

  getAgestreatedTypeCode(): string;
  setAgestreatedTypeCode(agestreatedTypeCode: string): GetSearchBySpecialityRequestModelInterface;

  getTreatmentMethodsTypeCode(): string;
  setTreatmentMethodsTypeCode(treatmentMethodsTypeCode: string): GetSearchBySpecialityRequestModelInterface;

  getDisorderTreatedTypeCode(): string;
  setDisorderTreatedTypeCode(disorderTreatedTypeCode: string): GetSearchBySpecialityRequestModelInterface;

  getSearchForTH(): boolean;
  setSearchForTH(searchForTH: boolean): GetSearchBySpecialityRequestModelInterface;

  getExpertiseTypeCode(): string;
  setExpertiseTypeCode(expertiseTypeCode: string): GetSearchBySpecialityRequestModelInterface;
}

export interface GetSearchBySpecialityResponseModelInterface extends GeneralErrorInterface {
  searchSpecialties: GetSearchBySpecialityResponseSearchSpecialtiesInfoInterface[];
  proceduresList: GetSearchByProcedureResponseSearchSpecialtiesInfoInterface[];
}

export interface GetSearchBySpecialityResponseSearchSpecialtiesInfoInterface {
  id: string; // This is the id
  name: string; // This is the name of the Specialty
  resourceTypeCode: string; // This is the resourceTypeCode
  procedureDescription: string; // This is the procedureDescription
  isProcedure: boolean; // This is the isProcedure
}

export interface GetSearchByProcedureResponseSearchSpecialtiesInfoInterface {
  id: number; // This is the id
  name: string; // This is the name of the Procedure
  resourceTypeCode: string; // This is the resourceTypeCode
  description: string; // This is for Procedure description
  isProcedure: boolean; // This is the isProcedure
  procedureDescription: string; // This is the procedureDescription
}

export interface GetSearchBySpecialtyResponseModelInterface extends GeneralErrorInterface {
  totalCount: number;
  providers: FadSpecialtyInterface[];
  sort: string;
  facets: FacetsList;
  disclaimers: Disclaimers[];
  costDetails: CostDetails;
  pdfRequest: FadPdfRequestInterface;
  telehealthInd: boolean;
  hpnZeroResults?: boolean;

}

export interface FadPdfRequestInterface {
  filters: string[];
  queryUrl: string;
  queue: boolean;
  source: string;
  searchParams: FadSearchParamsInterface;
}

export interface FadSearchParamsInterface {
  accountId: string;
  ci: string;
  dataLanguage: string;
  geoLocation: string;
  limit: string;
  memberNumber: string;
  name: string;
  networkId: string;
  page: string;
  radius: string;
  sort: string;
}

export interface FadSpecialtyInterface {
  isChecked: boolean;
  providerName: string; // This is the city/state of the location
  specialty: string; // This is the name of the city
  locations: FadLocationDetailsInterface[];
  reviews: FadReviewsListInterface;
  providerId: string;
  reviewIdentifier: string;
  providerType: string;
  isDisabled: boolean;
  disclaimers?: object;
  // tiers: FadProffessionalTierInterface;
}
export class FacetsList implements SpecialtyFacetsListInterface {
  overallRating: FilterListItem[];
  awardTypeCodes: FilterListItem[];
  bdcTypeCodes: FilterListItem[];
  cqms: FilterListItem[];
  fieldSpecialtyIds: FilterListItem[];
  locationGeo: FilterListItem[];
  providerType: FilterListItem[];
  acceptingNewPatients: FilterCheckboxItem;
  teleHealth: FilterCheckboxItem;
  groupAffiliationIds: GrpHospitalAffiliationFilterListItemInterface[];
  hospitalAffiliationIds: GrpHospitalAffiliationFilterListItemInterface[];
  professionalGender: FilterListItem[];
  professionalLanguages: FilterListItem[];
  techSavvy: FilterCheckboxItem;
  isPcp: FilterCheckboxItem;
  isChoicePcp: FilterCheckboxItem;
  treatmentMethodsTypeCodes: FilterListItem[];
  treatedTypeCodes: FilterListItem[];
  disordersTreatedTypeCodes: FilterListItem[];
  inNetwork: FilterCheckboxItem;
  tiers: FilterListItem[];
  expertiseTypeCodes: FilterListItem[];
}

export interface SpecialtyFacetsListInterface {
  overallRating: FilterListItemInterface[];
  awardTypeCodes: FilterListItemInterface[];
  bdcTypeCodes: FilterListItemInterface[];
  cqms: FilterListItemInterface[];
  fieldSpecialtyIds: FilterListItemInterface[];
  locationGeo: FilterListItemInterface[];
  providerType: FilterListItemInterface[];
  acceptingNewPatients: FilterCheckboxItemInterface;
  teleHealth: FilterCheckboxItemInterface;
  groupAffiliationIds: GrpHospitalAffiliationFilterListItemInterface[];
  hospitalAffiliationIds: GrpHospitalAffiliationFilterListItemInterface[];
  professionalGender: FilterListItemInterface[];
  professionalLanguages: FilterListItemInterface[];
  techSavvy: FilterCheckboxItemInterface;
  isPcp: FilterCheckboxItemInterface;
  isChoicePcp: FilterCheckboxItemInterface;
  treatmentMethodsTypeCodes: FilterListItemInterface[];
  treatedTypeCodes: FilterListItemInterface[];
  disordersTreatedTypeCodes: FilterListItemInterface[];
  inNetwork: FilterCheckboxItemInterface;
  tiers: FilterListItemInterface[];
  expertiseTypeCodes: FilterListItem[];
}

export interface FadLocationDetailsInterface {
  id: number; //    This is the location
  name: string; //     This is the location name
  address: string; //     This is the address info
  phone: string; //     This is the phone info
  awards: FadLocationAwardsDetailsInterface[];
  providerCost?: MemberCost;
  facilityCost?: MemberCost;
}

export interface FadLocationAwardsDetailsInterface {
  name: string;
  typeCode: string;
  awardDetails: AwardDetailInterface[];
}
export interface FadReviewsListInterface {
  overallRating: number; //     This is the city/state of the location
  percentRecommended: number; //     This is the percentRecommended
  totalRatings: number; //     This is the totalRatings
}
