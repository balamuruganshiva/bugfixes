import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { FadConstants } from '../../constants/fad.constants';

@Component({
  selector: 'app-help-choosing-network',
  templateUrl: './help-choosing-network.component.html',
  styleUrls: ['./help-choosing-network.component.scss']
})
export class HelpChoosingNetworkComponent implements OnInit, OnDestroy  {

  constructor(    public dialogRef: MatDialog ) { }

  ngOnInit() {
    const cdkOverlayContainer = this.dialogRef['_overlayContainer']._containerElement;
    cdkOverlayContainer.className = FadConstants.text.cdkAscendLayerClassGroup;
  }

  ngOnDestroy() {
    const cdkOverlayContainer = this.dialogRef['_overlayContainer']._containerElement;
    cdkOverlayContainer.className = FadConstants.text.cdkNormalLayerClassGroup;
  }

  cancel(): void {
    this.dialogRef.closeAll();
  }
}
