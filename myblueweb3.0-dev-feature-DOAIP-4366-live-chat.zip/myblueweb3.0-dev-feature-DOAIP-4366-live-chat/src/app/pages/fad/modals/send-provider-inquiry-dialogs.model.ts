import { GeneralError } from "../../../shared/models/generic-app.model";
import { MessageBody_InputDataInterface, SendProviderInquiryDialogConfirmation_InputDataInterface, SendProviderInquiryDialog_InputDataInterface, SendProviderInquiryDialog_OutputDataInterface } from "./interfaces/send-provider-inquiry-dialogs.interface";

export class SendProviderInquiryDialog_InputData implements SendProviderInquiryDialog_InputDataInterface {
    paramGroupName: string = "FAD_PROVIDER_DIR_CONFIG";
    fromAddress: string;
    emailMessage: MessageBody_InputDataInterface;
    subject: string
}

export class SendProviderInquiryDialogConfirmation_InputData implements SendProviderInquiryDialogConfirmation_InputDataInterface {
    emailId: string;
    errorFlag: boolean;
}

export class MessageBody_InputData implements MessageBody_InputDataInterface {
    emailBody: string;
}

export class SendProviderInquiryDialog_OutputData extends GeneralError implements SendProviderInquiryDialog_OutputDataInterface {
    confirmationToBeSentTo: string;
    dialogDiscardedFlag: boolean;
    connectionFailureError: boolean;
}