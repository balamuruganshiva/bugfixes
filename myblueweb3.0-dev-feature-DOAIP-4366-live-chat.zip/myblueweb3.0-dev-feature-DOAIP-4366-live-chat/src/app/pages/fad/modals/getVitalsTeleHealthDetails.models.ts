import { GetVitalsTeleHealthDetailsResponseInterface, GetVitalsTeleHealthDetailsRequestInterface } from "./interfaces/getVitalsTeleHealthDetails-models.interface";
import { GeneralError } from "../../../shared/models/generic-app.model";


export class GetVitalsTeleHealthDetailsResponseModel extends GeneralError implements GetVitalsTeleHealthDetailsResponseInterface {
    //specifying the telehealth flag
    teleHealthCd: boolean;

    //specifying the telehealth prod type
    teleHealthProdType: string;

    //specifying the telehealth vendor CD type
    teleHealthVendCd: string;

    //specifying the telehealth URL
    teleHealthUrl: string;
}

export class GetVitalsTeleHealthDetailsRequestModel implements GetVitalsTeleHealthDetailsRequestInterface {
    useridin: string;
}