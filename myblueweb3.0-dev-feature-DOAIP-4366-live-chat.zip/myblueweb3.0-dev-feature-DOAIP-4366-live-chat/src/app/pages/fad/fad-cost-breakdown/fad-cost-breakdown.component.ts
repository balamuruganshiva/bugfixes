import { TitleCasePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LineChartOptionsInterface } from '../../../shared/components/alegeus-line-chart/line-chart.interface';
import { LineChartOptions } from '../../../shared/components/alegeus-line-chart/line-chart.model';
import { FilterInterface } from '../../../shared/components/cost-breakdown-financialsfilter/filter.model';
import { FilterRadioChange, FilterSelection, FilterToggle } from '../../../shared/components/filter/filter.model';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService } from '../../../shared/services/auth.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { GlobalService } from '../../../shared/services/global.service';
import { FadConstants } from '../constants/fad.constants';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadCostBreakdownService } from '../fad-cost-breakdown/fad-cost-breakdown.service';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadService } from '../fad.service';
import { FadDoctorProfileRequestModel } from '../modals/fad-doctor-profile-details.model';
import { FadFacilityProfileRequestModel } from '../modals/fad-facility-profile-details.model';
import { FadDoctorProfileRequestModelInterface } from '../modals/interfaces/fad-doctor-profile-details.interface';
import { FadCostBenefitsInterface, FadFacilityCostInterface, FadFacilityProfileRequestModelInterface, LocationListInterface } from '../modals/interfaces/fad-facility-profile-details.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { BreadCrumb } from '../utils/fad.utils';

@Component({
  selector: 'app-fad-cost-breakdown',
  templateUrl: './fad-cost-breakdown.component.html',
  styleUrls: ['./fad-cost-breakdown.component.scss']
})
export class FadCostBreakdownComponent implements OnInit {
  public fadConstants = FadConstants;
  public hideMainContentOnFilterToggleForMobile = false;
  public filterConfig: FilterInterface;
  public totalCostbreakDownData: FadFacilityCostInterface;
  public costBreakdownData: FadCostBenefitsInterface;
  public memberFirstName: string;
  public selectedMember: string;
  public isProcedure: boolean;
  public procedureTitle: string;
  public parentPage = '';
  public mobileHideByFilterOverlay = false;
  public selectedLocationDetails: LocationListInterface;
  public breakdownCostFlag: boolean = false;
  public totalCostbreakDownDataFlag: boolean = false;
  public showFamilyGraph: boolean = false;
  public relation: string = '';
  public providerName: string;
  public isMobileView = false;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private fadCostBreakdownService: FadCostBreakdownService,
    private authService: AuthService,
    private globalService: GlobalService,
    private titleCase: TitleCasePipe,
    private fadSearchResultsService: FadSearchResultsService,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    public landingPageService: FadLandingPageService,
    private fadFacilityProfileService: FadFacilityProfileService,
    private fadDoctorProfileService: FadDoctorProfileService,
    private fadService: FadService,
    private http: HttpClient,
    private cdRef: ChangeDetectorRef,
    private authHttp: AuthHttp
  ) {

    this.totalCostbreakDownData = this.fadCostBreakdownService.facilityCostData;
    this.costBreakdownData = this.fadCostBreakdownService.costBenefitsData;
    this.parentPage = this.fadCostBreakdownService.parentPage;
    this.providerName = this.fadCostBreakdownService.providerName;
    this.totalCostbreakDownData && this.totalCostbreakDownData.copay > 0 ? this.breakdownCostFlag = true : this.breakdownCostFlag = false;
    if (this.totalCostbreakDownData.copay === null || this.totalCostbreakDownData.coinsuranceAmount === null ||
      this.totalCostbreakDownData.deductibleAmount === undefined || this.totalCostbreakDownData.copay === undefined || this.totalCostbreakDownData.coinsuranceAmount === null ||
      this.totalCostbreakDownData.deductibleAmount === undefined) {
      this.totalCostbreakDownDataFlag = false;
    } else {
      this.totalCostbreakDownDataFlag = true;
    }
    if (this.parentPage === undefined) {
      const parentPage = sessionStorage.getItem('cost-breakdown-parent');

      if (parentPage === this.fadConstants.text.facilityPage) {
        this.router.navigate(['/fad/facility-profile']);
      } else if (parentPage === this.fadConstants.text.doctorPage) {
        this.router.navigate(['/fad/doctor-profile']);
      }
    } else {
      sessionStorage.setItem('cost-breakdown-parent', this.parentPage);
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.isMobileView = event.target.innerWidth <= 992;
  }

  ngOnInit() {
    const userFullName = this.authService.fetchUserFullName();

    this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Cost Breakdown').setUrl('/fad/cost-breakdown'));

    this.filterConfig = {
      items: [
        {
          list: [

          ],
          type: 'radio',
          divider: false,
          multi: false,
          headerText: 'Member',
          hideToggle: false,
          expanded: false,
          disabled: false,
          disableRipple: false,
          collapsedHeight: null,
          expandedHeight: '44px',
          titlecase: false
        }
      ],
      hasSearch: false
    };
    this.memberFirstName =
      this.authService && this.authService.authToken && this.authService.authToken.firstName ? this.authService.authToken.firstName : '';
    this.landingPageService.getVitalsDependantList().subscribe(response => {
      for (let i = 0; i < response.membersInfoList.length; i++) {
        const selectedvalue = false;

        const relation = response.membersInfoList[i].relation;
        if (sessionStorage.getItem('fadVendorMemberNumber')) {
          if (response.membersInfoList[i].fadVendorMemberNumber === sessionStorage.getItem('fadVendorMemberNumber')) {
            this.filterConfig.items[0].list.push({
              text: response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')',
              value: response.membersInfoList[i].fadVendorMemberNumber,
              fadVendorMemberNumber: response.membersInfoList[i].fadVendorMemberNumber,
              selected: true,
              disabled: false
            });
            this.relation = relation;
            this.selectedMember = response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')';
          } else {
            this.filterConfig.items[0].list.push({
              text: response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')',
              value: response.membersInfoList[i].fadVendorMemberNumber,
              fadVendorMemberNumber: response.membersInfoList[i].fadVendorMemberNumber,
              selected: selectedvalue,
              disabled: false
            });

          }
        } else {
          if (relation === 'Subscriber') {
            this.filterConfig.items[0].list.push({
              text: response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')',
              value: response.membersInfoList[i].fadVendorMemberNumber,
              fadVendorMemberNumber: response.membersInfoList[i].fadVendorMemberNumber,
              selected: true,
              disabled: false
            });
            this.relation = relation;
            this.selectedMember = response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')';
          } else {
            this.filterConfig.items[0].list.push({
              text: response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')',
              value: response.membersInfoList[i].fadVendorMemberNumber,
              fadVendorMemberNumber: response.membersInfoList[i].fadVendorMemberNumber,
              selected: selectedvalue,
              disabled: false
            });

          }
        }
      }

      if (this.filterConfig.items[0].list && this.filterConfig.items[0].list.length === 1 && this.relation !== 'Subscriber') {
        this.showFamilyGraph = true;
      }
    });

    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

    if (searchCriteria) {
      this.isProcedure = searchCriteria.getSearchText().isProcedure();
      this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
    }
  }

  public getCostBreakDownData(event) {

    if (this.parentPage == 'doctor') {
      const professionalId = parseInt(sessionStorage.getItem('professionalId'));
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      const networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FadConstants.defaults.networkId;
      const geoLocation =
        searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FadConstants.defaults.geo;
      const locationId = sessionStorage.getItem('locationId');
      const procedureID = searchCriteria.getSearchText().getProcedureId();

      const fadDoctorProfileRequestParams: FadDoctorProfileRequestModelInterface = new FadDoctorProfileRequestModel();
      fadDoctorProfileRequestParams
        .setGeoLocation(geoLocation)
        .setProfessional(professionalId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));
      if (procedureID) {
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(FadConstants.defaults.radius);
      }

      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }
      const mleIndicator = this.authService.getMleEligibility();
      if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
        fadDoctorProfileRequestParams['fadVendorMemberNumber'] = event.selectedOption.value;
      }
      this.authHttp.showSpinnerLoading();
      this.fadDoctorProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(
        data => {
          this.authHttp.hideSpinnerLoading();
          if (data && Object.keys(data).length > 0) {
            this.totalCostbreakDownData = data.locations[0].facilityCost;
            if (
              this.totalCostbreakDownData.copay === null ||
              this.totalCostbreakDownData.coinsuranceAmount === null ||
              this.totalCostbreakDownData.deductibleAmount === undefined ||
              this.totalCostbreakDownData.copay === undefined ||
              this.totalCostbreakDownData.coinsuranceAmount === null ||
              this.totalCostbreakDownData.deductibleAmount === undefined
            ) {
              this.totalCostbreakDownDataFlag = false;
            } else {
              this.totalCostbreakDownDataFlag = true;
            }
            this.totalCostbreakDownData && this.totalCostbreakDownData.copay > 0
              ? (this.breakdownCostFlag = true)
              : (this.breakdownCostFlag = false);
            this.costBreakdownData = data.locations[0].costBenefit;
          }
        },
        error => {
          this.authHttp.hideSpinnerLoading();
        }
      );
    } else if (this.parentPage == 'facility') {
      const facilityProfileId = parseInt(sessionStorage.getItem('facilityProfileId'));
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

      const networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FadConstants.defaults.networkId;
      const geoLocation =
        searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FadConstants.defaults.geo;
      const locationId = sessionStorage.getItem('locationId');
      const procedureID = searchCriteria.getSearchText().getProcedureId();

      const fadDoctorProfileRequestParams: FadFacilityProfileRequestModelInterface = new FadFacilityProfileRequestModel();
      fadDoctorProfileRequestParams
        .setGeoLocation(geoLocation)
        .setfacilityId(facilityProfileId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));

      if (procedureID) {
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(FadConstants.defaults.radius);
      }

      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }
      const mleIndicator = this.authService.getMleEligibility();
      if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
        fadDoctorProfileRequestParams['fadVendorMemberNumber'] = event.selectedOption.value;
      }

      this.authHttp.showSpinnerLoading();
      this.fadFacilityProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(
        data => {
          this.authHttp.hideSpinnerLoading();
          if (data && Object.keys(data).length > 0) {
            this.totalCostbreakDownData = data.facility.location[0].facilityCost;
            this.totalCostbreakDownData && this.totalCostbreakDownData.copay > 0
              ? (this.breakdownCostFlag = true)
              : (this.breakdownCostFlag = false);
            this.costBreakdownData = data.facility.location[0].costBenefit;
          }
        },
        error => {
          this.authHttp.hideSpinnerLoading();
        }
      );
      this.cdRef.detectChanges();
    }
  }

  public costBreakdownAsLineChartOptions(chartNumber = FadConstants.text.chart1) {
    const linechartOption: LineChartOptionsInterface = new LineChartOptions();
    try {
      if (this.selectedMember === 'Family') {
        switch (chartNumber) {
          case FadConstants.text.chart1:
            linechartOption.headerText = FadConstants.text.chart1HeaderText;
            linechartOption.chartOption1Text = FadConstants.text.chart1Param1Text;
            linechartOption.chartOption2Text = FadConstants.text.chart1Param2Text;
            linechartOption.chartOption3Text = FadConstants.text.chart1Param3Text;
            linechartOption.AnnualElection = this.costBreakdownData.overallDeductibleLimit;
            linechartOption.totalValue = this.costBreakdownData.overallDeductibleAccumulated;
            linechartOption.chartOption3Value = this.totalCostbreakDownData.deductibleAmount;
            linechartOption.chartValue = linechartOption.AnnualElection - (linechartOption.totalValue + linechartOption.chartOption3Value);
            linechartOption.showOption3 = true;
            linechartOption.chartOption3BackgroundColor = FadConstants.text.chart2BarColorRemaining;
            break;
          case FadConstants.text.chart2:
            linechartOption.headerText = FadConstants.text.chart2HeaderText;
            linechartOption.chartOption1Text = FadConstants.text.chart2Param1Text;
            linechartOption.chartOption2Text = FadConstants.text.chart2Param2Text;
            linechartOption.chartColor = FadConstants.text.chart2BarColor;
            linechartOption.AnnualElection = this.costBreakdownData.familyOutofPocketLimit;
            linechartOption.totalValue = this.costBreakdownData.familyOutofPocketAccumulated;
            linechartOption.chartValue = linechartOption.AnnualElection - linechartOption.totalValue;
            break;
          default:
            break;
        }
      } else {
        switch (chartNumber) {
          case FadConstants.text.chart1:
            linechartOption.headerText = FadConstants.text.chart1HeaderText;
            linechartOption.chartOption1Text = FadConstants.text.chart1Param1Text;
            linechartOption.chartOption2Text = FadConstants.text.chart1Param2Text;
            linechartOption.chartOption3Text = FadConstants.text.chart1Param3Text;
            linechartOption.AnnualElection = this.costBreakdownData.individualDeductibleLimit;
            linechartOption.totalValue = this.costBreakdownData.individualDeductibleAccumulated;
            linechartOption.chartOption3Value = this.totalCostbreakDownData.deductibleAmount;
            linechartOption.chartValue = linechartOption.AnnualElection - (linechartOption.totalValue + linechartOption.chartOption3Value);
            linechartOption.showOption3 = true;
            linechartOption.chartValue = linechartOption.chartValue < 0 ? 0 : linechartOption.chartValue;
            linechartOption.chartOption3BackgroundColor = FadConstants.text.chart2BarColorRemaining;
            break;
          case FadConstants.text.chart2:
            linechartOption.headerText = FadConstants.text.chart2HeaderText;
            linechartOption.chartOption1Text = FadConstants.text.chart2Param1Text;
            linechartOption.chartOption2Text = FadConstants.text.chart2Param2Text;
            linechartOption.chartOption3Text = FadConstants.text.chart1Param3Text;
            linechartOption.chartColor = FadConstants.text.chart2BarColor;
            linechartOption.AnnualElection = this.costBreakdownData.individualOutofPocketLimit;
            linechartOption.totalValue = this.costBreakdownData.individualOutofPocketAccumulated;
            linechartOption.chartOption3Value = this.totalCostbreakDownData.memberCost;
            linechartOption.chartValue = linechartOption.AnnualElection - (linechartOption.totalValue + linechartOption.chartOption3Value);
            linechartOption.chartValue = linechartOption.chartValue < 0 ? 0 : linechartOption.chartValue;
            linechartOption.showOption3 = true;
            linechartOption.chartOption3BackgroundColor = FadConstants.text.chart2BarColorRemaining;

            break;
          case FadConstants.text.chart3:
            linechartOption.headerText = FadConstants.text.chart1HeaderText;
            linechartOption.chartOption1Text = FadConstants.text.chart1Param1Text;
            linechartOption.chartOption2Text = FadConstants.text.chart1Param2Text;
            linechartOption.chartOption3Text = FadConstants.text.chart1Param3Text;
            linechartOption.AnnualElection = this.costBreakdownData.overallDeductibleLimit;
            linechartOption.totalValue = this.costBreakdownData.overallDeductibleAccumulated;
            linechartOption.chartOption3Value = this.totalCostbreakDownData.deductibleAmount;
            linechartOption.chartValue = linechartOption.AnnualElection - (linechartOption.totalValue + linechartOption.chartOption3Value);
            linechartOption.chartValue = linechartOption.chartValue < 0 ? 0 : linechartOption.chartValue;
            linechartOption.showOption3 = true;
            linechartOption.chartOption3BackgroundColor = FadConstants.text.chart2BarColorRemaining;
            break;
          case FadConstants.text.chart4:
            linechartOption.headerText = FadConstants.text.chart2HeaderText;
            linechartOption.chartOption1Text = FadConstants.text.chart2Param1Text;
            linechartOption.chartOption2Text = FadConstants.text.chart2Param2Text;
            linechartOption.chartOption3Text = FadConstants.text.chart1Param3Text;
            linechartOption.chartColor = FadConstants.text.chart2BarColor;
            linechartOption.AnnualElection = this.costBreakdownData.familyOutofPocketLimit;
            linechartOption.totalValue = this.costBreakdownData.familyOutofPocketAccumulated;
            linechartOption.chartOption3Value = this.totalCostbreakDownData.memberCost;
            linechartOption.chartValue = linechartOption.AnnualElection - (linechartOption.totalValue + linechartOption.chartOption3Value);
            linechartOption.chartValue = linechartOption.chartValue < 0 ? 0 : linechartOption.chartValue;
            linechartOption.showOption3 = true;
            linechartOption.chartOption3BackgroundColor = FadConstants.text.chart2BarColorRemaining;

            break;
          default:
            break;
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadCostBreakdownComponent,
        FadConstants.methods.costBreakdownAsLineChartOptions
      );
    }

    return linechartOption;
  }

  // Methods to convert Transaction amount into decimal values
  public convertAmountToBaseValue(value) {
    return Math.trunc(value);
  }

  public reviewBenefits(): void {
    this.fadService.reviewMyBenfits();
  }

  public requestWrittenEstimte() {
    this.fadService.requestWrittenEstimate();
  }

  public convertAmountToDecimalValue(value) {
    const int_part = Math.trunc(value);
    const float_part = Number((value - int_part).toFixed(2));
    const decimal: string[] = float_part.toString().split('.');
    if (!decimal[1]) {
      const zero = '00';
      return zero;
    }
    return decimal[1];
  }

  toggleFilter(event: FilterToggle) {
    this.hideMainContentOnFilterToggleForMobile = !this.hideMainContentOnFilterToggleForMobile;

    // toggle filter section display as necessary
    if (this.hideMainContentOnFilterToggleForMobile) {
      this.mobileHideByFilterOverlay = true;
    } else {
      this.mobileHideByFilterOverlay = false;
    }
  }

  applyFilter(event: FilterSelection) {
    const newLocal = (this.hideMainContentOnFilterToggleForMobile = false);
  }

  clearFilter(event: FilterSelection) {
    this.hideMainContentOnFilterToggleForMobile = false;
  }

  onRadioButtonChange(event: FilterRadioChange) {
    this.getCostBreakDownData(event);
    sessionStorage.setItem('fadVendorMemberNumber', event.selectedOption.value);
    this.selectedMember = this.filterConfig.items[0].list.find(p => p.fadVendorMemberNumber == event.selectedOption.value).text;
    this.hideMainContentOnFilterToggleForMobile = false;
    this.mobileHideByFilterOverlay = false;
  }
}
