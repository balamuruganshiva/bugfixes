import { ChangeDetectorRef, Component, HostListener, Inject, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { MessageBody_InputDataInterface, SendProviderInquiryDialog_InputDataInterface, SendProviderInquiryDialog_OutputDataInterface } from '../modals/interfaces/send-provider-inquiry-dialogs.interface';
import { MessageBody_InputData, SendProviderInquiryDialog_InputData, SendProviderInquiryDialog_OutputData } from '../modals/send-provider-inquiry-dialogs.model';
import { SendProviderEmailInquiryService } from './send-provider-email-inquiry.service';

@Component({
  selector: 'app-send-provider-email-inquiry',
  templateUrl: './send-provider-email-inquiry.component.html',
  styleUrls: ['./send-provider-email-inquiry.component.scss']
})
export class SendProviderEmailInquiryComponent implements OnInit, OnDestroy {

  public sendProvEmailGroup: FormGroup;
  public isFormSubmitted = false;
  public userEmail: string = null;
  private isMobileView = false;
  private mobileViewWidthLimit = 992;
  private emailRegex: RegExp;

  public userMessageCustomMessages = {
    required: 'Message is required.',
  }

  public fromEmailCustomMessages = {
    required: 'Email Address is required.',
    invalidEmail: 'Email Address is not valid',
  }

  public confirmEmailCustomMessages = {
    required: 'Email Address does not match',
    invalidEmail: 'Confirm Email Address is not valid',
    confirmEmail: 'Email Address does not match'
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.isMobileView = event.target.innerWidth <= this.mobileViewWidthLimit;
    this.modifyPopupLayout();
  }

  constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<SendProviderEmailInquiryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public sendProviderEmailInquiryService: SendProviderEmailInquiryService,
    private profileService: ProfileService,
    private cdr: ChangeDetectorRef,
    private authHttp: AuthHttp
  ) {
    //clicking outside the popup should not close the dialog
    dialogRef.disableClose = true;
    this.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    let userProfile = this.profileService.getProfile();

    const useridin = sessionStorage.getItem('useridin');
    if (!userProfile) {
      if (useridin && useridin != "undefined" && useridin !== "null") {
        this.profileService.fetchProfileInfo().subscribe(profile => {
          if (profile) {
            this.profileService.setProfile(profile);
            this.userEmail = profile.emailAddress;

            this.sendProvEmailGroup = this.fb.group({
              userMessage: ['', [Validators.required]],
            });

            this.cdr.detectChanges();

            this.modifyPopupLayout();
            this.authHttp.hideSpinnerLoading();
          }
        });
      }
    }

    if (userProfile && userProfile.isVerifiedEmail) {
      this.userEmail = userProfile.emailAddress;

      this.sendProvEmailGroup = this.fb.group({
        userMessage: ['', [Validators.required]],
      });


    } else {
      this.sendProvEmailGroup = this.fb.group({
        fromEmailAddress: ['', []],
        confirmfromEmailAddress: ['', []],
        userMessage: ['', [Validators.required]],
      });
      this.sendProvEmailGroup.controls['fromEmailAddress'].setValidators([Validators.required, this.emailValidator(),
      this.checkConfirmEmailValidator(this.sendProvEmailGroup.controls['confirmfromEmailAddress'])])

      this.sendProvEmailGroup.controls['confirmfromEmailAddress'].setValidators([Validators.required, this.emailValidator(),
      this.checkConfirmEmailValidator(this.sendProvEmailGroup.controls['fromEmailAddress'], true)]);
    }
  }

  public blockedOp() {
    return false;
  }

  private modifyPopupLayout() {
    const dialogContainer: HTMLElement = <HTMLElement>document.getElementsByClassName('send-provider-email-inquiry-dialog')[0];
    if (this.userEmail) {
      dialogContainer.style.height = '100%';//'49vh';
      const cdkOverlayPane: HTMLElement = <HTMLElement>document.getElementsByClassName('cdk-overlay-pane')[0];

      if (this.isMobileView) {
        cdkOverlayPane.style.maxWidth = '90vw';
        cdkOverlayPane.style.maxHeight = '85vh';
        cdkOverlayPane.style.height = '100%';
      } else {
        cdkOverlayPane.style.maxWidth = '50vw';
        cdkOverlayPane.style.maxHeight = '520px';
        cdkOverlayPane.style.height = '441px';
      }

    } else {
      const cdkOverlayPane: HTMLElement = <HTMLElement>document.getElementsByClassName('cdk-overlay-pane')[0];

      if (this.isMobileView) {

        cdkOverlayPane.style.maxWidth = '90vw';
        cdkOverlayPane.style.maxHeight = '85vh';
        cdkOverlayPane.style.height = '100%';
      } else {
        cdkOverlayPane.style.maxWidth = '50vw';
        cdkOverlayPane.style.maxHeight = '520px';
        cdkOverlayPane.style.height = '520px';
      }
    }

    let matDialogContainer: HTMLElement = <HTMLElement>document.getElementsByTagName('mat-dialog-container')[0];
    matDialogContainer.style.overflow = 'hidden';
  }
  ngOnInit() {
    this.isMobileView = window.innerWidth <= this.mobileViewWidthLimit;
    this.modifyPopupLayout();
  }

  ngOnDestroy() {
    let cdkOverlayContainer = <HTMLElement>document.getElementsByClassName('cdk-overlay-container')[0];
    cdkOverlayContainer.style.zIndex = '1000';
  }

  submit() {
    this.isFormSubmitted = true;
    const request: SendProviderInquiryDialog_InputDataInterface = new SendProviderInquiryDialog_InputData();
    const message: MessageBody_InputDataInterface = new MessageBody_InputData();
    message.emailBody = this.sendProvEmailGroup.value.userMessage;

    if (this.userEmail) {
      request.fromAddress = this.userEmail;
    } else {
      request.fromAddress = this.sendProvEmailGroup.value.fromEmailAddress;
    }

    request.emailMessage = message;
    request.subject = this.sendProvEmailGroup.value.subject;
    this.sendProviderEmailInquiryService.submitSendProviderEmailInquiry(request).subscribe(data => {
      const modifiedResponse: SendProviderInquiryDialog_OutputDataInterface = Object.assign((new SendProviderInquiryDialog_OutputData()), data)
      modifiedResponse.confirmationToBeSentTo = request.fromAddress;
      this.dialogRef.close(modifiedResponse);
    }, err => {
      console.log("Error received ", err);
      const errorDialogResponse: SendProviderInquiryDialog_OutputDataInterface = err;
      errorDialogResponse.connectionFailureError = true;
      this.dialogRef.close(errorDialogResponse);
    });
  }

  cancel(): void {
    const discardedDialogResponse: SendProviderInquiryDialog_OutputDataInterface = new SendProviderInquiryDialog_OutputData();
    discardedDialogResponse.dialogDiscardedFlag = true;
    this.dialogRef.close(discardedDialogResponse);
  }

  emailValidator() {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        return null;
      }
      const value = control.value;
      let hasError = false;

      hasError = value && !this.emailRegex.test(value);
      return hasError ? { invalidEmail: { value: true } } : null;
    };
  }

  private checkConfirmEmailValidator(compareControl: AbstractControl, isConfirmField?: boolean): any {
    return (control: AbstractControl) => {
      const val = control.value;
      if (val && compareControl.value) {
        if (val !== compareControl.value) {
          if (isConfirmField) {
            return { confirmEmail: { value: true } };
          } else {
            return compareControl.setErrors({ confirmEmail: true });
          }
        }
        this.clearErrorInControl(control, 'confirmEmail');
        this.clearErrorInControl(compareControl, 'confirmEmail');
      }
      return null;
    };
  }

  clearErrorInControl(control: AbstractControl, errorType: string) {
    if (control.errors && control.errors[errorType]) {
      const errorList = {};
      let hasErrors = false;
      for (const error in control.errors) {
        if (error && error !== errorType) {
          hasErrors = true;
          errorList[error] = control.errors[error];
        }
      }
      control.setErrors(hasErrors ? errorList : null);
    }
  }

  closeModalIfTimedOut() {
    let token = sessionStorage['authToken'];
    let isUserLoginValid = (token !== undefined && token !== 'undefined' ? 
        JSON.parse(token) : null) ? true : false;
    if (!isUserLoginValid) {
      this.dialogRef.close(null);
    }
    return isUserLoginValid;
  }
}
