import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../../shared/services/auth.service';
import { MigrationService } from '../../migration.service';

declare let $: any;

@Component({
  selector: 'app-migration-success',
  templateUrl: './migration-success.component.html',
  styleUrls: ['./migration-success.component.scss']
})
export class MigrationSuccessComponent implements OnInit {
  public userid: string = localStorage['login-user'];

  constructor(
    private location: Location,
    private router: Router,
    private authService: AuthService,
    public migrationService: MigrationService
  ) {}

  ngOnInit() {
    this.authService.logout();
  }

  exploreNew(): void {
    this.router.navigate(['/login']);
  }
}
