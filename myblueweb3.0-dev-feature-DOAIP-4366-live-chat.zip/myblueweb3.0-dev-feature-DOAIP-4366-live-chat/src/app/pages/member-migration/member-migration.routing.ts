import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MigrationSuccessComponent } from '../member-migration/profile-info-update/migration-success/migration-success.component';
import { UpdatePasswordComponent } from '../member-migration/profile-info-update/update-password/update-password.component';
import { VerifyEmailMobileComponent } from '../member-migration/profile-info-update/verify-email-mobile/verify-email-mobile.component';
import { MigrationGuard } from './migration.guard';
import { MigrationConfirmationComponent } from './profile-info-update/migration-confirmation/migration-confirmation.component';
import { ProfileInfoComponent } from './profile-info/profile-info.component';

const MEM_MIGRATION_ROUTER: Routes = [
  {
    path: '',
    component: ProfileInfoComponent,
    data: {
      pageTitle: 'Member-Migration'
    },
    canActivate: [MigrationGuard]
  },
  {
    path: 'verify',
    component: VerifyEmailMobileComponent,
    canActivate: [MigrationGuard]
  },
  {
    path: 'updatePassword',
    component: UpdatePasswordComponent,
    canActivate: [MigrationGuard]
  },
  {
    path: 'success',
    component: MigrationSuccessComponent
  },
  {
    path: 'confirm',
    component: MigrationConfirmationComponent,
    canActivate: [MigrationGuard]
  }
];

export const MigrationRouter = RouterModule.forChild(MEM_MIGRATION_ROUTER);
