import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../../shared/shared.module';
import { MigrationRouter } from './member-migration.routing';
import { MigrationGuard } from './migration.guard';
import { MigrationService } from './migration.service';
import { MigrationConfirmationComponent } from './profile-info-update/migration-confirmation/migration-confirmation.component';
import { MigrationSuccessComponent } from './profile-info-update/migration-success/migration-success.component';
import { UpdatePasswordComponent } from './profile-info-update/update-password/update-password.component';
import { VerifyEmailMobileComponent } from './profile-info-update/verify-email-mobile/verify-email-mobile.component';
import { ProfileInfoComponent } from './profile-info/profile-info.component';

@NgModule({
  imports: [
    MatSelectModule,
    CommonModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatRadioModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    MigrationRouter,
    TextMaskModule
  ],
  declarations: [
    ProfileInfoComponent,
    UpdatePasswordComponent,
    VerifyEmailMobileComponent,
    MigrationSuccessComponent,
    MigrationConfirmationComponent
  ],
  providers: [MigrationService, MigrationGuard]
})
export class MemberMigrationModule {}
