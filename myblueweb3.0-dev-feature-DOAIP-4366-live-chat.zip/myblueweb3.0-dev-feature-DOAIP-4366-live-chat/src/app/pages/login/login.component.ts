import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/services/auth.service';
import { ConstantsService } from '../../shared/services/constants.service';
import { DependantsService } from '../../shared/services/dependant.service';
import { GlobalService } from '../../shared/services/global.service';
import { ValidationService } from '../../shared/services/validation.service';
import { AlertService } from '../../shared/shared.module';
import { LandingService } from '../landing/landing.service';
import { LoginService } from './login.service';

declare let $: any;

@Component({
  selector: 'app-core-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  type: string;
  typePlaceholder: string;
  isFormSubmitted = false;
  isApiCalled = false;
  loginForm: FormGroup;
  appStoreWebLink: boolean;
  appStoreMebLink: boolean;
  mobileNumberRegex = new RegExp('^[0-9]{10}');
  useridCustomMessages = {};
  pwdCustomMessages = {};
  destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private loginService: LoginService,
    private alertService: AlertService,
    private dependantService: DependantsService,
    private constants: ConstantsService,
    private authService: AuthService,
    private authHttp: AuthHttp,
    private router: Router,
    private validationService: ValidationService,
    private globalService: GlobalService,
    private landingService: LandingService
  ) {
    this.type = 'password';
    this.typePlaceholder = 'Show';
    this.appStoreWebLink = false;
    this.appStoreMebLink = false;

    this.loginForm = this.fb.group({
      useridin: ['', [Validators.required, Validators.maxLength(100), this.validationService.noWhitespaceValidator]],
      passwordin: ['', [Validators.required, this.validationService.noWhitespaceValidator]]
    });
    this.useridCustomMessages = {
      required: 'You must enter a valid username.',
      whitespace: 'You must enter a valid username.'
    };
    this.pwdCustomMessages = {
      required: 'You must enter a valid password.',
      whitespace: 'You must enter a valid password.'
    };
  }

  ngOnInit() {
    // login clears session. so always Anonymous
    if (!(window as any)._waDataLayer) {
      (window as any)._waDataLayer = new Object();
    }
    (window as any)._waDataLayer.UID = 'Anonymous';

    if (localStorage['login-user']) {
      this.loginForm.patchValue({
        useridin: localStorage['login-user']
      });
    }
    this.handleCheckBox();
    this.authService.logout();
  }

  handleCheckBox() {
    if (localStorage['rememberMe'] === undefined) {
      localStorage['rememberMe'] = true;
      $('#remember-me').prop('checked', true);
    } else if (localStorage['rememberMe'] === 'true') {
      localStorage['rememberMe'] = true;
      $('#remember-me').prop('checked', true);
    } else if (localStorage['rememberMe'] === 'false') {
      localStorage['rememberMe'] = false;
      $('#remember-me').prop('checked', false);
    }

    if (this.globalService.isMobile() && localStorage['login-user']) {
      this.appStoreMebLink = true;
    } else {
      this.appStoreWebLink = true;
    }
  }

  ngOnDestroy() {
    this.alertService.clearError();
    this.destroy$.next();
    this.destroy$.complete();
  }
  registerNow(){
    if(localStorage.getItem('targetRoute') && localStorage.getItem('targetRoute').includes(this.constants.pswLandingUrl)){
      const targetRoute = localStorage.getItem('targetRoute');
      const instanceIdVal = targetRoute.split('InstanceId=')[1];
      if(instanceIdVal !== undefined && instanceIdVal !== "" && instanceIdVal !== null) {
        this.router.navigate(['/register'], { queryParams: { from: 'MPSW' , InstanceId : instanceIdVal } });
      } else{
        this.router.navigate(['/register'], { queryParams: { from: 'MPSW'} });
      } 
    } else{
      this.router.navigate(['/register']);
    }
  }
  onSubmit() {
    if (!this.isApiCalled) {
      this.rememberMe();
      this.loginForm.value.useridin =
        this.loginForm && this.loginForm.value.useridin ? (this.loginForm.value.useridin = this.loginForm.value.useridin.trim()) : '';
      this.loginForm.value.passwordin =
        this.loginForm && this.loginForm.value.passwordin ? (this.loginForm.value.passwordin = this.loginForm.value.passwordin.trim()) : '';

      const loginData = this.loginForm.value;
      this.globalService.markFormGroupTouched(this.loginForm);
      this.isFormSubmitted = true;
      if (this.loginForm.valid) {
        this.isApiCalled = true;
        sessionStorage.setItem('key', this.loginForm.controls.useridin.value);
        this.alertService.clearError();
        this.loginService
          .login(loginData)
          .pipe(takeUntil(this.destroy$))
          .subscribe(
            response => {
              // redirect to targetRoute if needed
              const tr = localStorage.getItem('targetRoute');
              this.globalService.setUserData({ useridin: loginData.useridin });
              localStorage.removeItem('targetRoute');
              this.globalService.initTelehealthEligibility();
              this.globalService.setAdobe();
              if (tr) {
                this.router.navigateByUrl(tr);
              } else {
                this.redirectToSavedPage(response);
              }
              this.globalService.resetObservables();
              if (!tr || (tr && !tr.includes('from=MPSW'))) {
                this.globalService.initIsSearchEnabled();
              }
              this.landingService.clearCache();
            },
            err => {
              this.isApiCalled = false;

              if (err.status >= 500) {
                this.authHttp.hideSpinnerLoading();
                let message = 'Oops Something went wrong. Please try again!';
                if (err && err.error && err.error.result) {
                  message = message + ' (' + err.error.result + ')';
                  this.authHttp.CaptureAPIErrorInAdobe(err.status, err.error.result, message);
                }
                $('#requestTimeoutError').modal('open');
                $('#timeOutErrorText')[0].innerHTML = message;
              } else if (err.status === 404) {
                this.authHttp.handleError(err);
              } else {
                this.globalService.handleError(err.error, this.constants.displayMessage);
                this.validationService.focusFirstError();
              }
            }
          );
      }
    }
  }

  authRestartScreen() {
    this.globalService.setUserData(this.loginForm.value);
    this.globalService
      .redirectionRoute()
      .then(response => {
        this.router.navigate([response]);
      })
      .catch(route => {
        this.router.navigate([route]);
      });
  }

  redirectToSavedPage(response?) {
    if (response && response.destinationURL && response.migrationtype === 'NONE') {
      if (response.scopename === 'AUTHENTICATED-NOT-VERIFIED') {
        this.authRestartScreen();
      } else {
        localStorage.setItem('destinationURL', response.destinationURL);
        this.router.navigate([response.destinationURL]);
      }
    } else {
      if (response.scopename === 'REGISTERED-AND-VERIFIED') {
        this.authRestartScreen();
      } else {
        this.router.navigate(['/home']);
      }
    }
  }

  togglePasswordVisibility() {
    const typeDetails = this.globalService.togglePasswordType(this.type);
    this.type = typeDetails.type;
    this.typePlaceholder = typeDetails.placeHolder;
  }

  rememberMe() {
    localStorage['rememberMe'] = $('#remember-me').is(':checked');
    if (localStorage['rememberMe'] === 'true') {
      localStorage['login-user'] = this.loginForm.value.useridin;
      localStorage['rememberMe'] = $('#remember-me').is(':checked');
    } else {
      const storeTargetUrl = localStorage['targetRoute'];
      localStorage.clear();
      localStorage['targetRoute'] = storeTargetUrl || '';
      localStorage['rememberMe'] = false;
    }
  }

  navigateToForgotPassword() {
    const userName =
      this.loginForm && this.loginForm.controls && this.loginForm.controls['useridin'] ? this.loginForm.controls['useridin'].value : '';
    if (userName) {
      this.router.navigate(['/account/forgotPassword', userName]);
    } else {
      this.router.navigate(['/account/forgotPassword']);
    }
  }

  navigateToForgotUsername() {
    this.router.navigate(['/account/forgotusername']);
  }

  openhelp(){
    window.open("https://www.bluecrossma.org/myblue/myblue-app#faq","_blank");
  }
}
