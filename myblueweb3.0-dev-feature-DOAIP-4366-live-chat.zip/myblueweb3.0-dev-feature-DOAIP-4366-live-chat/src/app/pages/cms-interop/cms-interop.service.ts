import { DOCUMENT } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService, ConstantsService } from '../../shared/shared.module';
import { GetMemBasicInfoRequestModel, GetMemBasicInfoResponseModel } from '../medications/models/get-member-basic-info.model';
import {
  GetMemBasicInfoRequestModelInterface,
  GetMemBasicInfoResponseModelInterface
} from '../medications/models/interfaces/get-member-basic-info-model.interface';
import { GetMemberProfileRequestModel, GetMemberProfileResponseModel } from '../my-profile/models/get-member-profile-request.model';

@Injectable()
export class CmsInteropService {
  private httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.authService.getAuthToken()}`
    })
  };
  constructor(
    @Inject(DOCUMENT) private document: Document,
    public http: HttpClient,
    private authService: AuthService,
    private constantService: ConstantsService,
    private authHttp: AuthHttp,
    private activatedRoute: ActivatedRoute
  ) {
    this.activatedRoute.queryParams.subscribe(params => {
      // Get client_id and redirct_uri from the URL to store it in session storage
      const clientId = params['client_id'];
      const redirectUrl = params['redirect_url'];
      if (clientId) {
        const sessionStoragePara = {
          client_id: clientId,
          redirect_url: redirectUrl
        };
        sessionStorage.setItem('interopParaClientId', JSON.stringify(sessionStoragePara));
      }
      const uuid = params['uuid'];
      if (uuid) {
        const sessionStorageParaUuid = {
          uuid: uuid
        };
        sessionStorage.setItem('interopParaUuid', JSON.stringify(sessionStorageParaUuid));
      }
    });
  }

  /**
   *
   * @returns user basic info
   */
  getMemBasicInfo(): Observable<GetMemBasicInfoResponseModelInterface> {
    if (this.authService.basicMemInfo) {
      return Observable.of(this.authService.basicMemInfo);
    }
    const request: GetMemBasicInfoRequestModelInterface = new GetMemBasicInfoRequestModel();
    request.useridin = this.authService.useridin;

    return this.authHttp.encryptPost(this.constantService.getMemBasicInfoUrl, request).map(response => {
      if (response.result < 0) {
        return new GetMemBasicInfoResponseModel();
      } else {
        const basicInfo = new GetMemBasicInfoResponseModel();
        basicInfo.rxSummary = response.getMemBasicInfoResponse;
        this.authService.basicMemInfo = basicInfo;
        return basicInfo as GetMemBasicInfoResponseModel;
      }
    });
  }

  /**
   *
   * @returns will call getmemprofile api.
   * we need user email address
   */
  fetchProfileInfo(): Observable<GetMemberProfileResponseModel> {
    const request: GetMemberProfileRequestModel = new GetMemberProfileRequestModel();
    request.useridin = this.authService.useridin;

    return this.authHttp
      .post(this.constantService.getmemprofile, this.authHttp.handleRequest(request))
      .map(res1 => this.authHttp.handleDecryptedResponse(res1))
      .flatMap(memberProfileResp => {
        return Observable.of(memberProfileResp as GetMemberProfileResponseModel);
      });
  }

  /**
   *
   * @returns get consent
   */
  getConsent(): Observable<any> {
    const client_id = JSON.parse(sessionStorage.getItem('interopParaClientId')).client_id;
    const url = `${this.constantService.interopConsent}?clientId=${client_id}`;

    return this.authHttp.get(url, this.httpOptions, true).pipe(map(data => data as any));
  }

  /**
   *
   * @returns Drupal response of Consent part
   */
  getConsentDrupalContent(): Observable<any> {
    return this.authHttp.get(this.constantService.drupalWarningMessage, this.httpOptions, true).pipe(
      map(drupalres => {
        return drupalres as any;
      })
    );
  }

  /**
   *
   * @returns Drupal response of Consent part
   */
  getAcknowledgeDrupalContent(): Observable<any> {
    return this.authHttp.get(this.constantService.drupalFinalWarning, this.httpOptions, true).pipe(
      map(drupalres => {
        return drupalres as any;
      })
    );
  }

  /**
   *
   * @param isConsented is Boolean: true or false
   * @returns
   */
  postConsent(isConsented: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: `Bearer ${this.authService.getAuthToken()}`,
        uitxnid: 'WEB_v3.0_' + this.authHttp.uuid()
      })
    };
    const interOpData = JSON.parse(sessionStorage.getItem('interopParaClientId'));
    const request = {
      clientId: interOpData.client_id,
      isConsented: isConsented
    };
    const postConsent = this.authHttp.post(this.constantService.interopConsent, request, httpOptions).toPromise();
    return postConsent.then(item => {
      // console.log('post consent :', item);
    });
  }

  /**
   * user Decline from consent it will redirect to 3rd party app
   */
  redirectDeclineToThirdPartyApp() {
    const interOpData = JSON.parse(sessionStorage.getItem('interopParaClientId'));
    this.document.location.replace(interOpData.redirect_url + '?error_description=User declined');
  }

  /**
   *
   * @returns Authorized acknowledgement
   */
  putAcknowledgement() {
    const uuid = JSON.parse(sessionStorage.getItem('interopParaUuid')).uuid;
    const request = {
      UUID: uuid
    };
    const putack = this.http.put(this.constantService.interopAcknowledgement, request, this.httpOptions).toPromise();
    return putack.then(item => {
      // console.log('put acknowledge :', item)
    });
  }

  /**
   *
   * @returns post outh/authorized call when consent and ack is already true.
   */
  postUserAuthorized() {
    const headerJson = {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: `Bearer ${this.authService.getAuthToken()}`
    };

    const headers = new HttpHeaders(headerJson);
    const interOpData = JSON.parse(sessionStorage.getItem('interopParaClientId'));
    const client_id = interOpData.client_id;
    const redirectUri = encodeURIComponent(interOpData.redirect_url);
    const body = `client_id=${client_id}&redirect_uri=${redirectUri}&response_type=code`;

    const postAckCall = this.http.post(this.constantService.interopUserAuthorized, body.toString(), { headers: headers }).toPromise();
    return postAckCall.then(item => {
      this.document.location.replace(interOpData.redirect_url + '?code=' + item['code']);
      // console.log('post userAuthorized :', item);
    });
  }
}
