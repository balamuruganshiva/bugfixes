import { RouterModule, Routes } from '@angular/router';
import { AcknowledgementComponent } from './acknowledgement/acknowledgement.component';
import { ConsentKnowledgeComponent } from './consent-knowledge/consent-knowledge.component';
import { InteroperabilityGuard } from './interoperability.guard';
import { UserDeclineComponent } from './user-decline/user-decline.component';
import { UserNotEligibleComponent } from './user-not-eligible/user-not-eligible.component';

const CMS_ROUTER: Routes = [
  {
    path: 'consent',
    component: ConsentKnowledgeComponent,
    canActivate: [InteroperabilityGuard]
  },
  {
    path: 'not-eligible',
    component: UserNotEligibleComponent
  },
  {
    path: 'acknowledge',
    component: AcknowledgementComponent,
    canActivate: [InteroperabilityGuard]
  },
  {
    path: 'user-decline',
    component: UserDeclineComponent
  }
];
export const cmsInteropRouter = RouterModule.forChild(CMS_ROUTER);
