import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsentKnowledgeComponent } from './consent-knowledge.component';

describe('ConsentKnowledgeComponent', () => {
  let component: ConsentKnowledgeComponent;
  let fixture: ComponentFixture<ConsentKnowledgeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConsentKnowledgeComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsentKnowledgeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
