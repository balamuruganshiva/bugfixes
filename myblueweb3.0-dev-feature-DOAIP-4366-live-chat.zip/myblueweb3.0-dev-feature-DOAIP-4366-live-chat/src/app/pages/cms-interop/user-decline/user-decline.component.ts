import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalService } from '../../../shared/services/global.service';
import { AlertService } from '../../../shared/shared.module';
import { CmsInteropService } from '../cms-interop.service';

@Component({
  selector: 'app-user-decline',
  templateUrl: './user-decline.component.html',
  styleUrls: ['./user-decline.component.scss']
})
export class UserDeclineComponent implements OnInit {
  getConsentData$: Observable<any>;
  firstPageContent;
  constructor(private alertService: AlertService, private globalService: GlobalService, private cmsService: CmsInteropService) {}

  ngOnInit() {
    this.drupalContent();
  }

  /**
   * Getting all drupal content as warning-message
   */
  drupalContent() {
    this.getConsentData$ = this.cmsService.getConsentDrupalContent();
    this.getConsentData$.subscribe(drupalres => {
      // console.log('🚀 ~ file: consent-knowledge.component.ts ~ line 62 ~ ConsentKnowledgeComponent ~ ngOnInit ~ drupalres', drupalres);
      this.firstPageContent = drupalres[7];
    });
  }

  /**
   * done - Logout()
   * if it is from consent it will redirect to 3rd party app
   * if it is from ack flow, then it will just logout
   */
  done() {
    if (sessionStorage.getItem('interopParaClientId')) {
      this.logout();
      this.cmsService.redirectDeclineToThirdPartyApp();
    } else {
      this.logout();
    }
  }

  /**
   * logout of application!
   */
  logout() {
    const tr = localStorage.getItem('interopRoute');
    localStorage.setItem('targetRoute', tr);
    this.alertService.clearError();
    this.globalService.logout();
  }
}
