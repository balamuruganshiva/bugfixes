import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material';
import { MaterializeModule } from 'angular2-materialize';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { SharedModule } from '../../shared/shared.module';
import { cmsInteropRouter } from './cms-interop.route';
import { ConsentKnowledgeComponent } from './consent-knowledge/consent-knowledge.component';
import { EmailAsteriskPipe } from './email-asterisk.pipe';
import { InteroperabilityGuard } from './interoperability.guard';
import { UserNotEligibleComponent } from './user-not-eligible/user-not-eligible.component';
import { AcknowledgementComponent } from './acknowledgement/acknowledgement.component';
import { UserDeclineComponent } from './user-decline/user-decline.component';
import { CmsInteropService } from './cms-interop.service';

@NgModule({
  imports: [CommonModule, cmsInteropRouter, SharedModule, InfiniteScrollModule, MaterializeModule, MatSlideToggleModule],
  declarations: [ConsentKnowledgeComponent, UserNotEligibleComponent, EmailAsteriskPipe, AcknowledgementComponent, UserDeclineComponent],
  providers: [InteroperabilityGuard, CmsInteropService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CmsInteropModule {}
