import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { MessageDetailsSearchResponseModelInterface } from '../modals/interfaces/message-center-search.interface';
import { MessageDetailsSearchResponseModel } from '../modals/message-center-search.model';

@Injectable()
export class MessageCenterSearchService {
  public cachedSearchCriteriaData: MessageDetailsSearchResponseModelInterface;
  public isPersistSearchCriteria = false;

  constructor(private bcbsmaHttpService: BcbsmaHttpService) {}

  getSearchFilters(): Observable<MessageDetailsSearchResponseModel> {
    const MESSAGE_CENTER_SEARCH_FILTERS_URL = '/assets/data/messageCenterModule/messageListingComponent_SampleData.json';
    return this.bcbsmaHttpService.get(MESSAGE_CENTER_SEARCH_FILTERS_URL);
  }
}
