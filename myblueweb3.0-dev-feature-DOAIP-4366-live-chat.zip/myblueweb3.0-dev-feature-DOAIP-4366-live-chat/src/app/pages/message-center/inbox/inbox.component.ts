import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BreadCrumb } from '../../../shared/components/breadcrumbs/breadcrumbs';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { HeaderService } from '../../../shared/layouts/header/header.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { ConstantsService } from '../../../shared/shared.module';
import { PreferenceModalService } from '../../preference-modal/preference-modal.service';
import { AuthService } from '../../registration/registration.module';
import { MessageCenterConstants } from '../constants/messageCenter.constants';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent implements OnInit {
  public unreadMsgCount: number;
  public breadCrumbs: BreadCrumb[];
  fpoTargetUrl: string = this.constants.drupalTestUrl + '/page/myinbox-landingscreen';
  showPrefPromo = false;

  constructor(
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    public headerService: HeaderService,
    private router: Router,
    public preferenceModalService: PreferenceModalService,
    public profileService: ProfileService,
    private constants: ConstantsService,
    public authService: AuthService) {
    this.showPrefPromo = this.preferenceModalService.showPreference();
  }

  ngOnInit() {
    // Show paperless promo
    this.preferenceModalService.initiatePromo();
    this.initBreadcrumbs();
  }

  initBreadcrumbs() {
    this.breadCrumbs = [
      {
        label: 'Home',
        url: ['/home']
      },
      {
        label: 'My Inbox',
        url: ['/message-center']
      }
    ];
  }

  goToDocumentsHome() {
    this.router.navigate(['/message-center/documents/home']);
  }

  public openComponent(targetComponent: string): void {
    try {
      switch (targetComponent) {
        case 'messages':
          this.router.navigate([`/message-center/messages`]);
          break;
        case 'chats':
          break;
        default:
          break;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.messageCenterModule,
        MessageCenterConstants.components.inboxComponent,
        MessageCenterConstants.methods.openComponent
      );
    }
  }
}
