export interface TaxFormModel {
    year: string;
    name: string;
    file: string;
}

export interface TaxFileModel {
    forms: TaxFormModel[];
    memberRightsFlag: boolean;
    displaymessage: string;
    data: any;
    hasFileIcon: boolean;
}
