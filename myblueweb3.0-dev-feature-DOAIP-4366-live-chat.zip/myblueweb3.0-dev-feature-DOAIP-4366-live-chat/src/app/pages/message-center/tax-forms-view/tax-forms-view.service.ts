import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService, ConstantsService } from '../../../shared/shared.module';

@Injectable()
export class TaxFormService {


    constructor(
      private http: AuthHttp,
      private constantsService: ConstantsService,
      public authService: AuthService,
      ) { }

    getTaxForms(taxyear: any) {
      const request = {
        useridin: this.authService.useridin,
        cryptoToken: this.authService.cryptoToken.key2id,
        year: Number(taxyear)
      };
      return this.http.encryptPost(this.constantsService.getTaxFormsUrl, request);
    }
}
