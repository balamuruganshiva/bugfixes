import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BreadCrumb } from '../../../shared/components/breadcrumbs/breadcrumbs';
import { AuthService } from '../../../shared/services/auth.service';
import { TaxFormService } from './tax-forms-view.service';
import { TaxFileModel } from './tax-forms.model';

declare let $: any;


@Component({
  selector: 'app-tax-forms-view',
  templateUrl: './tax-forms-view.component.html',
  styleUrls: ['./tax-forms-view.component.scss']
})
export class TaxFormsviewComponent implements OnInit {
  public parentFolderName: string;
  public breadCrumbs: BreadCrumb[] = [];
  fileData: TaxFileModel;
  year: string;
  taFormData = [];
  maintananceFlag = false;
  isMonthDisabled = false;
  messageToDisplay: any;
  memberRightsFlag: boolean;
  medicareFlag = false;
  hasFileIcon = false;

  constructor(
    private router: Router,
    private taxFormService: TaxFormService,
    private route: ActivatedRoute,
    private authService: AuthService
  ) {}

  prepareChildBreadCrumbs(folderId) {
    this.breadCrumbs.push({
      label: 'Home',
      url: ['/home']
    });
    this.breadCrumbs.push({
      label: 'My Inbox',
      url: ['/message-center']
    });
    this.breadCrumbs.push({
      label: 'My Documents',
      url: ['/message-center/documents/home']
    });
    this.breadCrumbs.push({
      label: 'Tax Forms',
      url: ['/message-center/documents/tax-forms']
    });
    this.breadCrumbs.push({
      label: `${this.year} Tax Forms`,
      url: ['/message-center/documents/tax-forms/details'],
      queryParams: {year : this.year}
    });
  }

  ngOnInit() {
    this.route.queryParams
      .filter(params => params.year)
      .subscribe(params => {
        this.year = params.year;
      });
    this.isMonthDisabled = false;
    const taxFormDataExistData = this.taxFormDataExist();
    this.medicareCheck();
    if (taxFormDataExistData.length < 1 && !this.medicareFlag) {
      this.taxFormService.getTaxForms(this.year).subscribe(taxFileModel => {
        this.messageToDisplay = taxFileModel.displaymessage;
        this.taFormData = JSON.parse(sessionStorage.getItem('fileData')) === null ? [] : JSON.parse(sessionStorage.getItem('fileData'));
        if (taxFileModel.result < 1) {
          this.memberRightsFlag =
            taxFileModel.result === -95403 || taxFileModel.result === -95404 || taxFileModel.result === -95406 ? true : false;
          this.hasFileIcon = taxFileModel.result === -95403 || taxFileModel.result === -95404 ||
            taxFileModel.result === -95406 || taxFileModel.result === -95407 ? true : false;
            let errorMessage = '';
            if (taxFileModel.result === -1) {
              errorMessage = 'Sorry for the inconvenience,but we’re performing some maintenance at' +
              'the moment. We’ll be back online shortly.';
            } else {
              errorMessage =  taxFileModel.displaymessage;
            }
            this.taFormData.push({
            year: this.year,
            data: [],
            displaymessage: errorMessage,
            memberRightsFlag: this.memberRightsFlag,
            hasFileIcon : this.hasFileIcon
          });
        } else {
          this.taFormData.push({ year: this.year, data: taxFileModel, displaymessage: '', hasFileIcon: this.hasFileIcon });
        }
        sessionStorage.setItem('fileData', JSON.stringify(this.taFormData));
        const tfdada = this.taxFormDataExist();
        this.fileData = tfdada && tfdada.length > 0 && tfdada[0];
      });
    } else {
      this.fileData = taxFormDataExistData && taxFormDataExistData.length > 0 && taxFormDataExistData[0];
    }
    this.prepareChildBreadCrumbs(this.router.url.split('/')[this.router.url.split('/').length - 1]);
  }

  private medicareCheck() {
    if (this.authService && this.authService.authToken && this.authService.authToken.userType) {
      this.medicareFlag =
        this.authService.authToken.userType === 'MEDEX' || this.authService.authToken.userType === 'MEDICARE' ? true : false;
    }
  }

  private taxFormDataExist() {
    const fileData = JSON.parse(sessionStorage.getItem('fileData'));
    if (fileData) {
      return fileData.filter(item => item.year === this.year);
    } else {
      return [];
    }
  }
  openModal() {
    $('#openTaxformFalse').modal('open');
  }

  openFile(index: number) {
    const detectIEEdgeFlag = this.detectIEEdge();
    const file = this.fileData.data.forms[index].file;
    const byteCharacters = atob(this.hexToBase64(file));
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: 'application/pdf' });
    const fileName =  this.fileData.data.forms[index].name + '.pdf';
    if (detectIEEdgeFlag) {
      window.navigator.msSaveBlob(blob, fileName);
    } else {
      const url = window.URL.createObjectURL(blob);
      window.open(url, '_blank');
    }
  }

  private detectIEEdge() {
    const ua = window.navigator.userAgent;
    const msie = ua.indexOf('MSIE ');
    if (msie > 0) {
        return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
    }
    const trident = ua.indexOf('Trident/');
    if (trident > 0) {
        return true;
    }
    const edge = ua.indexOf('Edge/');
    if (edge > 0) {
       return true;
    }
    return false;
 }

  hexToBase64(hexstring) {
    return btoa(
      hexstring
        .match(/\w{2}/g)
        .map(function(a) {
          return String.fromCharCode(parseInt(a, 16));
        })
        .join('')
    );
  }

}
