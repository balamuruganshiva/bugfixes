export enum MessageCenter_BenefitTextType {
  eligibilityTextReply,
  claimFilingTextReply,
  COBTextReply,
  limitationTextReply
}
