import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { BreadCrumb } from '../../../shared/components/breadcrumbs/breadcrumbs';
import { AuthService } from '../../../shared/services/auth.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { ConstantsService } from '../../../shared/shared.module';
import { HomePageInfoModel } from '../../landing/landing.model';
import { PreferenceModalService } from '../../preference-modal/preference-modal.service';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import {
  GetPlansBenefitsListPlanItemInterface,
  GetPlansBenefitsListResponseModelInterface
} from '../modals/interfaces/get-plans-benefits-list-models.interface';
import { EocPolicyInterface, GetBenefitCoverageResponseModelInterface } from '../modals/interfaces/getBenefitCoverage-models.interface';
import { NoDocumentsFoundComponentModel } from '../modals/message-center.modal';


@Component({
  selector: 'app-tax-forms-overall-view',
  templateUrl: './tax-forms-overall-view.component.html',
  styleUrls: ['./tax-forms-overall-view.component.scss']
})
export class TaxFormsOverallViewComponent implements OnInit {

  public memberInfo: HomePageInfoModel;
  public breadCrumbs: BreadCrumb[] = [];
  public planBenefitsList: GetPlansBenefitsListResponseModelInterface = null;
  public benefitCoverageDocs: GetBenefitCoverageResponseModelInterface = null;
  public policiesInBenefitCoverage: EocPolicyInterface = null;
  public hasContents: boolean;
  title: string = 'Explanation of Benefits';
  public oMemberInboxLinks;
  fpoHomeTargetUrl: string = this.constants.drupalTestUrl + '/page/mydocuments';
  fpoMyPlanDocumentTargetUrl: string = this.constants.drupalTestUrl + '/page/myplan-documents';
  fpobenefitCoverageListTargetUrl: string = this.constants.drupalTestUrl + '/page/bluecare-documents';
  public no_doc_found_component_mode: NoDocumentsFoundComponentModel = new NoDocumentsFoundComponentModel();
  public selectedPlan: GetPlansBenefitsListPlanItemInterface;
  isTaxFormsEnabled: boolean = false;
  years: string[] = [new Date().getFullYear() - 1 + '', new Date().getFullYear() - 2 + ''];
  showPrefPromo = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private constants: ConstantsService,
    public preferenceModalService: PreferenceModalService,
    public profileService: ProfileService,
    private authService: AuthService
  ) {
    this.no_doc_found_component_mode.mode = MessageCenterConstants.flags.documentsMode;
    this.showPrefPromo = preferenceModalService.showPreference();
  }

  ngOnInit() {
    this.isTaxFormsEnabled = environment.enableTaxForms;
    // Show paperless promo
    this.preferenceModalService.initiatePromo();

    this.prepareChildBreadCrumbs(this.router.url.split('/')[this.router.url.split('/').length - 1]);

  }



  openTaxForms(year: string) {
    this.router.navigate(['/message-center/documents/tax-forms/details'], { queryParams: { year: year } });
  }

  prepareChildBreadCrumbs(folderId) {
    this.breadCrumbs.push({
      label: 'Home',
      url: ['/home']
    });
    this.breadCrumbs.push({
      label: 'My Inbox',
      url: ['/message-center']
    });
    this.breadCrumbs.push({
      label: 'My Documents',
      url: ['/message-center/documents/home']
    });
    this.breadCrumbs.push({
      label: 'Tax Forms',
      url: ['/message-center/documents/tax-forms']
    });

  }

}
