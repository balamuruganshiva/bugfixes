import { RouterModule, Routes } from '@angular/router';
import { EnrollComponent } from './enroll.component';

const ENROLL_ROUTER: Routes = [
  {
    path: '',
    component: EnrollComponent,
  }
];

export const enrollRouter = RouterModule.forChild(ENROLL_ROUTER);
