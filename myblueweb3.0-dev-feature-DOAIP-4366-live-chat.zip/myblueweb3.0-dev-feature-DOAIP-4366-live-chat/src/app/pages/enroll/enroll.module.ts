import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatCardModule,
  MatCheckboxModule,
  MatInputModule,
  MatRadioModule,
  MatSelectModule,
  MatStepperModule
} from '@angular/material';
import { TextMaskModule } from 'angular2-text-mask';
import { RegistrationService } from '../registration/registration.module';
import { EnrollComponent } from './enroll.component';
import { enrollRouter } from './enroll.routing';

@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatButtonModule,
    MatRadioModule,
    MatAutocompleteModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatStepperModule,
    MatCardModule,
    MatCheckboxModule,
    TextMaskModule,
    enrollRouter
  ],
  declarations: [EnrollComponent],
  providers: [RegistrationService]
})
export class EnrollModule { }
