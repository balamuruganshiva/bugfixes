import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalService } from '../../../shared/services/global.service';
import { ConstantsService } from '../../../shared/shared.module';
import { BenefitSearchResultGroup } from '../model/benefit-search-result-item.model';
import { OTHER_POPULAR_LINKS } from './benefit-search-landing-constants';

@Component({
  selector: 'app-benefit-search-landing',
  templateUrl: './benefit-search-landing.component.html',
  styleUrls: ['./benefit-search-landing.component.scss']
})
export class BenefitSearchLandingComponent implements OnInit, AfterViewInit {
  productTypes: string[] = [];
  selectedProductType: string;
  allBenefits = 'All Benefits';
  searchForm: FormGroup;
  isLoading = true;
  searchKeyword: string;
  searchResponse: BenefitSearchResultGroup[];
  pager: any = {};
  pagedItems: BenefitSearchResultGroup[];
  page = 1;
  itemsPerPage = 10;
  fpoLastUpdateUrl: string;
  popularLinks = OTHER_POPULAR_LINKS;
  retryCount = 1;

  constructor(private fb: FormBuilder,
    private globalService: GlobalService,
    private route: ActivatedRoute,
    private router: Router,
    private constants: ConstantsService) {
      this.fpoLastUpdateUrl = this.constants.drupalSearchLastRefresh;
    }

  ngOnInit() {
    this.route.paramMap.subscribe(paramsMap => {
      this.searchKeyword = paramsMap.get('keyword');
    });
    this.searchForm = this.fb.group({
      query: [this.searchKeyword, [Validators.required]]
    });
  }

  ngAfterViewInit() {
    this.doSearch();
  }

  onProductTypeChange($event) {
    this.page = 1;
    this.selectedProductType = $event.value;
  }

  clearSearch() {
    this.searchForm.reset();
  }
  onSubmit() {
    if (this.searchForm.valid) {
      this.router.navigate(['/benefit-search', this.searchForm.value.query.trim()]);
    }
  }

  convertToTitlecase(text: string) {
    return text ? text[0].toUpperCase() + text.substring(1) : text;
  }

  doSearch() {
    if (!sessionStorage.getItem('searchableCPCsResult') && this.retryCount <= 10) {
      this.retryCount++;
      setTimeout(() => {
        this.doSearch();
      }, 2000);
    } else {
      if (this.searchForm.valid) {
        this.searchKeyword = this.searchForm.value.query;
        this.globalService.getSearchResults(this.searchKeyword).subscribe(result => {
          this.productTypes = result.searchResults
            .filter(plan => plan.benefits && plan.benefits.length > 0)
            .map(e => this.convertToTitlecase(e.productType));
          this.productTypes.unshift(this.allBenefits);
          this.productTypes = this.productTypes.filter((planType, index, planTypes) => planTypes.indexOf(planType) === index);
          this.selectedProductType = this.productTypes[0];
          this.searchResponse = result.searchResults
            .map(response => ({
              ...response,
              benefits: (response.benefits || []).map(item => ({
                ...item,
                cpcCode: response.cpcCode,
                planName: response.planName,
                productType: this.convertToTitlecase(response.productType)
              }))
            }))
            .reduce((acc, res) => acc.concat(res.benefits), []);
          this.isLoading = false;
        });
      }
    }
  }

  navigateTo(link) {
    if (link.external) {
      window.open(link.url, '_blank');
    } else {
      this.router.navigate([link.url || link]);
    }
  }
}
