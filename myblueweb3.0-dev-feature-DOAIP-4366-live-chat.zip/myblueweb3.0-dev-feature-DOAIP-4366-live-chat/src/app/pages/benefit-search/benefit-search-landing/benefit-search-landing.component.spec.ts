import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs/observable/of';
import { GlobalService } from '../../../shared/services/global.service';

import { BenefitSearchLandingComponent } from './benefit-search-landing.component';

const fakeResultResponse = [{
  cpcCode: "1232", planType: "Medical",
  "benefits": [{
    benefitShortDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed.',
    benefitCategoryName: 'Ambulance Services',
    benefitCategoryID: 9
  },
  {
    benefitShortDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed.',
    benefitCategoryName: 'Internal Medicine',
    benefitCategoryID: 10
  },
  {
    benefitShortDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed.',
    benefitCategoryName: 'In Patient',
    benefitCategoryID: 10
  }]
}];

describe('BenefitSearchLandingComponent', () => {
  let component: BenefitSearchLandingComponent;
  let fixture: ComponentFixture<BenefitSearchLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BenefitSearchLandingComponent ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            paramMap: of({
              keyword: 'family'
            })
          }
        },
        {
          provie: GlobalService,
          useValue: jasmine.createSpyObj('globalService', ['getSearchResults'])
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BenefitSearchLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('onInit', () => {
    it('should initialises the form oninit', () => {
      const formBuilderStub: FormBuilder = fixture.debugElement.injector.get(FormBuilder);
      spyOn(formBuilderStub, 'group').and.callThrough();
      component.ngOnInit();
      expect(formBuilderStub.group).toHaveBeenCalled();
    });
    it('should initialises the searchKeyword', fakeAsync(() => {
      component.ngOnInit();
      tick();
      expect(component.searchKeyword).toEqual('family');
    }));
  });

  describe('afterViewInit', () => {
    it('should invoke the doSearch method', () => {
      spyOn(component, 'doSearch').and.callThrough();
      component.ngAfterViewInit();
      expect(component.doSearch).toHaveBeenCalled();
    });
  });

  it('convertToTitlecase method should convert the text to titlecase', () => {
    const title = component.convertToTitlecase('medical');
    expect(title).toEqual('Medical');
    const emptyTitle = component.convertToTitlecase('');
    expect(emptyTitle).toEqual('');
  });

  it('onPlanChange method should updated the current selected plan', () => {
    component.onPlanChange({value: 'Medical'});
    fixture.detectChanges();
    expect(component.selectedPlan).toEqual('Medical');
  });

  it('clearSearch method should clear the form', () => {
    const queryControl = component.searchForm.get('query');
    queryControl.setValue('Family');
    fixture.detectChanges();
    component.clearSearch();
    fixture.detectChanges();
    expect(queryControl.value).toBeFalsy();
  });

  describe('search', () => {
    it('should do the search when the form is valid', fakeAsync(() => {
      const globalService: GlobalService = fixture.debugElement.injector.get(GlobalService);
      const queryControl = component.searchForm.get('query');
      const planTypes = fakeResultResponse.map(e => component.convertToTitlecase(e.planType));
      queryControl.setValue('Family');
      spyOn(globalService, 'getSearchResults').and.returnValue(fakeResultResponse);
      tick();
      fixture.detectChanges();
      expect(component.searchResponse).toEqual(fakeResultResponse);
      expect(component.planTypes).toEqual(planTypes);
      expect(component.selectedPlan).toEqual(component.allBenefits);
    }));
  });

});
