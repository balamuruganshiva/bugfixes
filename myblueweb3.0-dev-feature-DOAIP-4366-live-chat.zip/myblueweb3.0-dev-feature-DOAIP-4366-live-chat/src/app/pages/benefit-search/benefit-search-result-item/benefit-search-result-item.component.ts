import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BenefitSearchResultItem } from './../model/benefit-search-result-item.model';
import { MyplansService } from '../../myplans/myplans.service';
import { AuthService } from '../../../shared/shared.module';

@Component({
  selector: 'app-benefit-search-result-item',
  templateUrl: './benefit-search-result-item.component.html',
  styleUrls: ['./benefit-search-result-item.component.scss']
})
export class BenefitSearchResultItemComponent implements OnInit {
  @Input() resultItem: BenefitSearchResultItem;
  @Input() keyword: string;

  constructor(private router: Router, private myPlanService: MyplansService, private authService: AuthService) {}

  ngOnInit() {}

  viewDetails() {
    // const cpcList = JSON.parse(sessionStorage.getItem('searchableCPCs'));
    // const filtered = cpcList.filter(cpcItem => cpcItem.cpcCode === this.resultItem.cpcCode);
    // const planName = filtered.length > 0 ? filtered[0].planName : '';
    this.myPlanService.setPlanBenefitRequest({
      planName: this.resultItem.planName,
      cpcCode: this.resultItem.cpcCode,
      coveragePackageCode: this.resultItem.cpcCode,
      useridin: this.authService.useridin,
      benefitCategoryID: '' + this.resultItem.benefitCategoryID,
      benefitCategoryName: this.resultItem.benefitCategoryName
    });
    this.myPlanService.setServiceBenefitCategoryName(this.resultItem.benefitCategoryName);
    this.router.navigate(['/myplans', 'benefitdetails'], { queryParams: { keyword: this.keyword } });
  }
}
