import { Location } from '@angular/common';
import { DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { BenefitSearchResultItemComponent } from './benefit-search-result-item.component';

describe('BenefitSearchResultItemComponent', () => {
  let component: BenefitSearchResultItemComponent;
  let fixture: ComponentFixture<BenefitSearchResultItemComponent>;
  let searchTypeElm: DebugElement;
  let h3Elm: DebugElement;
  let descriptionElm: DebugElement;
  let resultItem: DebugElement;
  let location: Location;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BenefitSearchResultItemComponent ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(BenefitSearchResultItemComponent);
    component = fixture.componentInstance;

    searchTypeElm = fixture.debugElement.query(By.css('.search-type'));
    h3Elm = fixture.debugElement.query(By.css('h3'));
    descriptionElm = fixture.debugElement.query(By.css('.result > div'));
    resultItem = fixture.debugElement.query(By.css('.result'));
    location = TestBed.get(Location);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BenefitSearchResultItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render the search type and h3 by given input', () => {
    const testItem = {
      benefitShortDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed.',
      benefitCategoryName: 'Root Canal',
      benefitCategoryID: 8,
      planType: 'Medical'
    };
    component.resultItem = testItem;
    fixture.detectChanges();
    expect(searchTypeElm.nativeElement.textContent).toEqual(`Benefits > ${testItem.planType}`);
    expect(h3Elm.nativeElement.textContent).toEqual(testItem.benefitCategoryName);
    expect(descriptionElm.nativeElement.innerHTTML).toContain(testItem.benefitShortDescription);    
  });

  it('should invoke viewDetails when the result item is clicked', () => {
    resultItem.nativeElement.click();
    expect(component.viewDetails).toHaveBeenCalled();
    fixture.whenStable().then(() => {
      expect(location.path()).toContain('/myplans/benefitdetails');
    });
  });

});
