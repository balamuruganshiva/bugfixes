import { Pipe, PipeTransform } from '@angular/core';
import { BenefitSearchResultGroup } from '../model/benefit-search-result-item.model';

@Pipe({
  name: 'productType'
})
export class ProductTypePipe implements PipeTransform {

  transform(list: BenefitSearchResultGroup[], type?: string): any {
    if (!type || type === 'All Benefits') {
      return list;
    }
    return list.filter((plan) => plan.productType.toLowerCase() === type.toLowerCase());
  }

}
