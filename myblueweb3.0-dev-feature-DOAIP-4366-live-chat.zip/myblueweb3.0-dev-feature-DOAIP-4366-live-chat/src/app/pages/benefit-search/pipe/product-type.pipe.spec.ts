import { ProductTypePipe } from './product-type.pipe';

const resultResponse = [{
  cpcCode: '1232',
  productType: 'Medical',
  benefits: [{
    benefitShortDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed.',
    benefitCategoryName: 'Ambulance Services',
    benefitCategoryID: 9
  },
  {
    benefitShortDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed.',
    benefitCategoryName: 'Internal Medicine',
    benefitCategoryID: 10
  },
  {
    benefitShortDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed.',
    benefitCategoryName: 'In Patient',
    benefitCategoryID: 10
  }]
},
{
  cpcCode: '12232',
  productType: 'Dental',
  benefits: [{
    benefitShortDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed.',
    benefitCategoryName: 'Root Canal',
    benefitCategoryID: 8
  },
  {
    benefitShortDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed.',
    benefitCategoryName: 'Dental Cleaning',
    benefitCategoryID: 12
  },
  {
    benefitShortDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed.',
    benefitCategoryName: 'Orthodontics',
    benefitCategoryID: 11
  }]
}];

describe('PlanTypePipe', () => {
  it('create an instance', () => {
    const pipe = new ProductTypePipe();
    expect(pipe).toBeTruthy();
  });

  it('should return all the items if type is \'All Benefits\'', () => {
    const pipe = new ProductTypePipe();
    const type = 'All Benefits';
    expect(pipe.transform(this.resultResponse, type).length).toEqual(resultResponse.length);
  });

  it('should return filtered items by the passed type', () => {
    const pipe = new ProductTypePipe();
    const type = 'Medical';
    expect(pipe.transform(this.resultResponse, type).length).toEqual(1);
  });

  it('should return empty list if input is empty', () => {
    const pipe = new ProductTypePipe();
    const type = 'All Benefits';
    expect(pipe.transform([], type)).toBe([]);
  });

});
