import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BenefitSearchLandingComponent } from './benefit-search-landing/benefit-search-landing.component';
import { SharedModule } from '../../shared/shared.module';
import { BenefitSearchRouter } from './benefit-search.routing';
import { BenefitSearchResultItemComponent } from './benefit-search-result-item/benefit-search-result-item.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { ProductTypePipe } from './pipe/product-type.pipe';
import { FpoLayoutModule } from '../../shared/layouts/FpoLayoutComponent/fpo-layout.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    BenefitSearchRouter,
    ReactiveFormsModule,
    NgxPaginationModule,
    FpoLayoutModule
  ],
  declarations: [
    BenefitSearchLandingComponent,
    BenefitSearchResultItemComponent,
    ProductTypePipe
  ],
  providers: [
    ProductTypePipe
  ]
})
export class BenefitSearchModule { }
