import { DatePipe, TitleCasePipe } from '@angular/common';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { MatCardModule, MatTooltipModule } from '@angular/material';
import { MAT_LABEL_GLOBAL_OPTIONS } from '@angular/material/core';
import { StorageServiceModule } from 'angular-webstorage-service';
import { MaterializeModule } from 'angular2-materialize';
import { MomentModule } from 'angular2-moment';
import { TextMaskModule } from 'angular2-text-mask';
import { NgxCurrencyModule } from 'ngx-currency';
import { DialogModule } from 'primeng/primeng';
import { environment, environmentService } from '../environments/environment';
import { AppComponent } from './app.component';
import { appRouter } from './app.router';
import { ConsentModalComponent } from './components/consent-modal/consent-modal.component';
import { ConsentModalModule } from './components/consent-modal/consent-modal.module';
import { ProfileSelectPreferenceModule } from './components/profile-select-preference/profile-select-preference.module';
import { CoreModule } from './core/core.module';
import { MaterialModule } from './material.module';
import { FadFacilityCompareResolver } from './pages/fad/fad-facility-compare/fad-facility-compare-resolver';
import { FadFacilityCompareService } from './pages/fad/fad-facility-compare/fad-facility-compare.service';
import { FadProfessionalCompareService } from './pages/fad/fad-professional-compare/fad-professional-compare.service';
import { FadProviderCompareResolver } from './pages/fad/fad-provider-compare/fad-provider-compare-resolver';
import { FadProviderCompareService } from './pages/fad/fad-provider-compare/fad-provider-compare.service';
import { SendProviderEmailInquiryService } from './pages/fad/send-provider-email-inquiry/send-provider-email-inquiry.service';
import { LandingService } from './pages/landing/landing.service';
import { LoginModule } from './pages/login/login.module';
import { MyMedicationDetailsService } from './pages/medications/myMedicationDetails/my-medication-details.service';
import { MyaccountResolver } from './pages/myaccount/myaccount.resolver';
import { MyAccountService } from './pages/myaccount/myaccount.service';
import { ClaimsService } from './pages/myclaims/claims.service';
import { MyDedCoResolver } from './pages/myded-co/myded-co.resolver';
import { MyDedCoService } from './pages/myded-co/myded-co.service';
import { EobsService } from './pages/myeobs/eobs.service';
import { MyplansService } from './pages/myplans/myplans.service';
import { NotfoundComponent } from './pages/notfound/notfound.component';
import { NotificationPreferencesResolver } from './pages/notification-preferences/notification-preferences.resolver';
import { NotificationPreferencesService } from './pages/notification-preferences/notification-preferences.service';
import { PreferenceModalModule } from './pages/preference-modal/preference-modal.module';
import { PreferenceModalComponent } from './pages/preference-modal/preference-modal/preference-modal.component';
import { SsoResolver } from './pages/sso/sso.resolver';
import { SsoService } from './pages/sso/sso.service';
import { VdkComponent } from './pages/vdk/vdk.component';
import { WellconnectionModule } from './pages/wellconnection/wellconnection.module';
import { YearEndSummaryService } from './pages/year-end-summary/year-end-summary.service';
import { EnvironmentService } from './services/environement/environment.service';
import { AuthenticatedLayoutComponent } from './shared/layouts/AuthenticatedLayoutComponent/AuthenticatedLayout.component';
import { FpoLayoutModule } from './shared/layouts/FpoLayoutComponent/fpo-layout.module';
import { HeaderService } from './shared/layouts/header/header.service';
import { LogoDialogComponent } from './shared/logo-dialog/logo-dialog.component';
import { MenuDialogComponent } from './shared/menu-dialog/menu-dialog.component';
import { AppModalsProfileService } from './shared/modals/appmodals-profile.service';
import { AppmodalsComponent } from './shared/modals/appmodals.component';
import { AppModalsService } from './shared/modals/appmodals.service';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { HomepageResolver } from './shared/routeresolvers/homepage-resolver';
import { MyCardsResolverService } from './shared/routeresolvers/my-cards-resolver.service';
import { MyPlansResolverService } from './shared/routeresolvers/my-plans-resolver.service';
import { MyclaimsResolverService } from './shared/routeresolvers/myclaims-resolver.service';
import { MyEobsResolverService } from './shared/routeresolvers/myeobs-resolver.service';
import { MymedsResolverService } from './shared/routeresolvers/mymeds-resolver.service';
import { MyprofileResolverService } from './shared/routeresolvers/myprofile-resolver.service';
import { MyprofileResolverServiceContact } from './shared/routeresolvers/myprofile-resolver.service.contact';
import { OrderreplacementResolverService } from './shared/routeresolvers/orderreplacement-resolver';
import { PreferenceResolverService } from './shared/routeresolvers/preference-resolver.service';
import { AuthHttp } from './shared/services/auth-http.service';
import { AuthService } from './shared/services/auth.service';
import { DependantsService } from './shared/services/dependant.service';
import { SelectionService } from './shared/services/downloadForm/selection.service';
import { DynamicScriptLoaderService } from './shared/services/dynamic-script-loader.service';
import { FilterService } from './shared/services/filter.service';
import { GlobalService } from './shared/services/global.service';
import { LayoutService } from './shared/services/layout.service';
import { LogRocketService } from './shared/services/logrocket.service';
import { MedicationsService } from './shared/services/medications/medications.service';
import { MyCardsService } from './shared/services/mycards/mycards.service';
import { ProfileService } from './shared/services/myprofile/profile.service';
import { OrderreplacementService } from './shared/services/orderreplacement/orderreplacement.service';
import { AlertService, ConstantsService, SharedModule } from './shared/shared.module';
import { SpinnertimeoutComponent } from './shared/spinnertimeout/spinnertimeout.component';
import { NoMenuResolver } from './shared/utils/nomenu.resolver';

export function initAppFactory(logRocketService: LogRocketService) {
  return () => {
    return new Promise<void>((resolve, reject) => {
      if (environment.loadLogRocket) {
        logRocketService.init();
      }
      resolve();
    });
  };
}

@NgModule({
  declarations: [AppComponent, NotfoundComponent, AppmodalsComponent, SpinnertimeoutComponent, VdkComponent, NavbarComponent],
  exports: [AuthenticatedLayoutComponent],
  imports: [
    CoreModule,
    SharedModule,
    MaterializeModule,
    LoginModule,
    appRouter,
    TextMaskModule,
    MomentModule,
    DialogModule,
    MaterialModule,
    MatCardModule,
    MatTooltipModule,
    MatTooltipModule,
    StorageServiceModule,
    NgxCurrencyModule,
    PreferenceModalModule,
    ConsentModalModule,
    FpoLayoutModule,
    ProfileSelectPreferenceModule,
    WellconnectionModule
  ],
  entryComponents: [MenuDialogComponent, LogoDialogComponent, PreferenceModalComponent, ConsentModalComponent],
  providers: [
    SelectionService,
    AlertService,
    AuthService,
    NoMenuResolver,
    ConstantsService,
    DependantsService,
    LayoutService,
    GlobalService,
    FilterService,
    AuthHttp,
    DatePipe,
    TitleCasePipe,
    OrderreplacementResolverService,
    OrderreplacementService,
    MyprofileResolverService,
    MyprofileResolverServiceContact,
    PreferenceResolverService,
    ProfileService,
    MyCardsResolverService,
    MyCardsService,
    MymedsResolverService,
    MedicationsService,
    MyDedCoResolver,
    MyDedCoService,
    MyaccountResolver,
    MyAccountService,
    YearEndSummaryService,
    ClaimsService,
    MyclaimsResolverService,
    SsoResolver,
    SsoService,
    LandingService,
    HomepageResolver,
    MyMedicationDetailsService,
    NotificationPreferencesService,
    NotificationPreferencesResolver,
    MyPlansResolverService,
    MyplansService,
    MyEobsResolverService,
    HeaderService,
    EobsService,
    FadProviderCompareService,
    FadFacilityCompareResolver,
    FadFacilityCompareService,
    FadProviderCompareResolver,
    FadProfessionalCompareService,
    SendProviderEmailInquiryService,
    LogRocketService,
    { provide: MAT_LABEL_GLOBAL_OPTIONS, useValue: { float: 'always' } },
    {
      provide: APP_INITIALIZER,
      useFactory: initAppFactory,
      deps: [LogRocketService],
      multi: true
    },
    { provide: EnvironmentService, useValue: environmentService },
    AppModalsService,
    AppModalsProfileService,
    DynamicScriptLoaderService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
