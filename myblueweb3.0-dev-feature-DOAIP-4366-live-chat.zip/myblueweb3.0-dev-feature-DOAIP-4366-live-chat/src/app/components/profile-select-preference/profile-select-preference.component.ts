import { Component, EventEmitter, HostListener, Input, OnInit, Output } from '@angular/core';
import { generateToolTip } from '../../pages/preference-modal/preference.utils';
import { PreferencesService } from '../../shared/services/myprofile/preferences.service';
import { ConstantsService } from '../../shared/shared.module';

@Component({
  selector: 'app-profile-select-preference',
  templateUrl: './profile-select-preference.component.html',
  styleUrls: ['./profile-select-preference.component.scss']
})
export class ProfileSelectPreferenceComponent implements OnInit {

  @Input() programList: any;
  @Input() initiatedFrom: string;
  @Input() isUnionBlueMember: boolean;
  @Input() isEmailUnDeliverable: boolean;
  @Input() isemailPreferenceDisabled: boolean;
  @Input() isTextUnDeliverable: boolean;
  @Input() isCDHEnabledUser: boolean;
  @Input() istextPreferenceDisabled: boolean;
  @Input() isModelPopup: boolean;
  @Output() pageOnChangeEmitter: EventEmitter<any> = new EventEmitter();
  @Output() modalOnChangeEmitter: EventEmitter<any> = new EventEmitter();

  isPhone = false;
  mobileViewPort = 992;

  toolTipVisible;
  unionBlueDrupalUrl: string;
  isTextSelected: boolean;
  isEmailSelected: boolean;

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.isPhone = event.target.innerWidth <= this.mobileViewPort;
  }

  constructor(
    private constants: ConstantsService,
    private prefService: PreferencesService
  ) {
    if (window.innerWidth <= this.mobileViewPort) {
      this.isPhone = true;
    }
    this.unionBlueDrupalUrl = this.constants.getBlueUnion;
    this.isTextSelected = false;
    this.isEmailSelected = false;
  }

  ngOnInit() {
    this.toolTipVisible = generateToolTip(this.programList);
      this.prefService.isChannelEditSaved.subscribe((response) => {
        if (response.channel === 'Email' && response.status === 'true') {
          this.isemailPreferenceDisabled = false;
          this.isEmailUnDeliverable = false;
        } else if (response.channel === 'SMS' && response.status === 'true') {
          this.istextPreferenceDisabled = false;
          this.isTextUnDeliverable = false;
        }
      });
  }

  onChange(event: any) {
    this.programList.forEach(program => {
      if (program.id === event.source.name) {
        program.filters.forEach(filter => {
          if (filter.channelID === event.source.value) {
            filter.selected = event.source.checked;
            if (program.id === 'Documents_Plan' && (this.isEmailUnDeliverable === true || this.isTextUnDeliverable === true)) {
              if (filter.channelID === 'SMS') {
                this.isTextSelected = true;
                this.isEmailSelected = false;
                this.prefService.closeChannelEdit.next({
                  channel: 'Email',
                  status: 'true'
                });
                this.prefService.isChannelEditCancelledD.next({
                  channel: 'Email',
                  status: 'false'
                });
              }
              if (filter.channelID === 'MAIL') {
                this.isTextSelected = false;
                this.isEmailSelected = false;
                if(this.isEmailUnDeliverable === true) {
                  this.prefService.isChannelEditCancelledD.next({
                    channel: 'Email',
                    status: 'false'
                  });
                  this.prefService.closeChannelEdit.next({
                    channel: 'Email',
                    status: 'false'
                  });
                }
                if(this.isTextUnDeliverable === true) {
                  this.prefService.isChannelEditCancelledD.next({
                    channel: 'Email',
                    status: 'false'
                  });
                  this.prefService.closeChannelEdit.next({
                    channel: 'Email',
                    status: 'true'
                  });
                  this.prefService.closeChannelEdit.next({
                    channel: 'SMS',
                    status: 'false'
                  });
                }
              }
              
              if (filter.channelID === 'SOLICIT') {
                this.isEmailSelected = true;
                this.prefService.closeChannelEdit.next({
                  channel: 'SMS',
                  status: 'true'
                });
                this.prefService.isChannelEditCancelledD.next({
                  channel: 'SMS',
                  status: 'false'
                });
              }
            }
          } else if (event.source.checked && program.id === 'Documents_Plan') {
            filter.selected = false;
          }
          if (event.source.name === 'Documents_Plan' && filter.channelID === event.source.value) {
            event.source.checked = true;
            filter.selected = event.source.checked;
          }
        });
      }
    });
    this.initiatedFrom === 'preferencePage' ?
                          this.pageOnChangeEmitter.emit(this.programList) : this.modalOnChangeEmitter.emit(this.programList);
  }

  showToolTip(program, event) {
    Object.keys(this.toolTipVisible).forEach(programid => {
      this.toolTipVisible[programid] = programid === program.id ? !this.toolTipVisible[program.id] : false;
    });
    event.stopPropagation()
  }

  @HostListener("document: click")
  clickedOut() {
    Object.keys(this.toolTipVisible).forEach(programid => {
      this.toolTipVisible[programid] = this.toolTipVisible[programid] ? false : false;
    });
  }

}
