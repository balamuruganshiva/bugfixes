import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileSelectPreferenceComponent } from './profile-select-preference.component';
import { MaterialModule } from '../../material.module';
import { FpoLayoutModule } from '../../shared/layouts/FpoLayoutComponent/fpo-layout.module';
import { SharedModule } from '../../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    FpoLayoutModule,
    SharedModule
  ],
  declarations: [ProfileSelectPreferenceComponent],
  exports: [ProfileSelectPreferenceComponent]
})
export class ProfileSelectPreferenceModule { }
