import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { verifyEmail } from '../verify-email-mobile/verifyEmail.module';
import { ProfileEmailComponent } from './profile-email.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    verifyEmail
  ],
  declarations: [ProfileEmailComponent],
  exports: [ProfileEmailComponent]
})
export class ProfileEmailModule { }
