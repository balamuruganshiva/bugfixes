import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { VerifyEmailMobileComponent } from './verify-email-mobile.component';
import { VerifyEmailMobileService } from './verify-email-mobile.service';

@NgModule({
  imports: [CommonModule, HttpClientModule, FormsModule, ReactiveFormsModule, TextMaskModule],
  providers: [VerifyEmailMobileService],
  declarations: [VerifyEmailMobileComponent],
  exports: [VerifyEmailMobileComponent]
})
export class verifyEmail {}
