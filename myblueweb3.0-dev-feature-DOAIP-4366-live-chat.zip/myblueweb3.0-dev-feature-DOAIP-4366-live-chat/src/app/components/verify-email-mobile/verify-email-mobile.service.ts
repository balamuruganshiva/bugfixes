import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { GetMemberProfileResponseModel } from '../../pages/my-profile/models/get-member-profile-request.model';
import { AlertType } from '../../shared/alerts/alertType.model';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { ProfileService } from '../../shared/services/myprofile/profile.service';
import { AlertService, AuthService } from '../../shared/shared.module';

@Injectable()
export class VerifyEmailMobileService {
  private shiftKeyDown = false;
  private profile: GetMemberProfileResponseModel;

  maskedVerify = '';

  private preferenceModalVerification = new BehaviorSubject<any>(null);
  public preferenceModalVerification$ = this.preferenceModalVerification;

  constructor(
    private alertService: AlertService,
    private router: Router,
    public authService: AuthService,
    public profileService: ProfileService,
    private http: AuthHttp
  ) {
    this.profile = this.profileService.getProfile();
  }

  navigateToVerifyScreen() {
    this.router.navigate(['/myprofile/verify']).then(() => {
      this.alertService.setAlert('Verification code sent!.', '', AlertType.Success);
    });
  }

  verifyPhone(alertContainer: string = '') {
    const verifiedUsers = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
    const { phoneNumber } = JSON.parse(sessionStorage.getItem('memProfile'));
    const scopeName = this.authService.authToken ? this.authService.authToken.scopename : '';
    const verifyPhoneService = verifiedUsers.includes(scopeName)
      ? this.profileService.sendcommchlaccesscode('', phoneNumber.replace(/\D/g, ''))
      : this.profileService.sendaccesscode('MOBILE', phoneNumber.replace(/\D/g, ''));
    const isSendAccessCodeService = !verifiedUsers.includes(scopeName);

    verifyPhoneService.subscribe((response: any) => {
      let userId;
      if (response.result === '0') {
        if (isSendAccessCodeService) {
          const communicationChannel = this.http.handleDecryptedResponse(response);
          sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
          const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
          userId = sentMailId && sentMailId['commChannel'];
        }
        this.alertService.clearError();
        this.maskedVerify = this.profileService.maskPhoneNumber(phoneNumber ? phoneNumber.replace(/\D/g, '') : userId);
        sessionStorage.setItem('maskedVerify', this.maskedVerify);
        sessionStorage.setItem('maskedVerifyPhone', 'Y');
        alertContainer === 'modalAlert'
          ? this.preferenceModalVerification.next({ result: response.result, date: new Date().toString() })
          : this.navigateToVerifyScreen();
      } else {
        if (response.displaymessage) {
          if (alertContainer === 'modalAlert') {
            this.preferenceModalVerification.next({
              result: response.result,
              date: new Date().toString(),
              displaymessage: response.displaymessage
            });
          } else {
            this.alertService.setAlert(response.displaymessage, '', AlertType.Failure, 'component', alertContainer);
          }
          window.scrollTo(0, 0);
        }
      }
      this.http.hideSpinnerLoading();
    });
  }

  verifyEmail(alertContainer: string = '') {
    const verifiedUsers = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
    const { emailAddress } = JSON.parse(sessionStorage.getItem('memProfile'));
    const scopeName = this.authService.authToken ? this.authService.authToken.scopename : '';
    const verifyEmailService = verifiedUsers.includes(scopeName)
      ? this.profileService.sendcommchlaccesscode(emailAddress, '')
      : this.profileService.sendaccesscode('EMAIL', emailAddress);
    const isSendAccessCodeService = !verifiedUsers.includes(scopeName);

    verifyEmailService.subscribe((response: any) => {
      if (response.result === '0') {
        let userId;
        if (isSendAccessCodeService) {
          const communicationChannel = this.http.handleDecryptedResponse(response);
          sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
          const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
          userId = sentMailId && sentMailId['commChannel'];
        }
        this.alertService.clearError();
        this.maskedVerify = this.profileService.maskEmailId(emailAddress ? emailAddress : userId);
        sessionStorage.setItem('maskedVerifyPhone', 'N');
        sessionStorage.setItem('maskedVerify', this.maskedVerify);
        alertContainer === 'modalAlert'
          ? this.preferenceModalVerification.next({ result: response.result, date: new Date().toString() })
          : this.navigateToVerifyScreen();
      } else {
        if (response.displaymessage) {
          this.alertService.setAlert(response.displaymessage, '', AlertType.Failure, 'component', alertContainer);
          window.scrollTo(0, 0);
        }
      }
      this.http.hideSpinnerLoading();
    });
  }

  mapErrorCodeWithMsg(result, alertMessageFinal) {
    let alertType = '';
    if (result.result === -90129) {
      alertType = 'success';
      alertMessageFinal = result.displaymessage;
    } else if (result.result === -90124 || result.result === -90126) {
      alertType = 'error';
      alertMessageFinal = result.displaymessage;
    } else if (result.displaymessage !== '') {
      alertMessageFinal = result.displaymessage;
    }
    return alertMessageFinal;
  }
}
