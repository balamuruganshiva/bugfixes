import { TitleCasePipe } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { PROFIE_CONSTANTS } from '../../pages/my-profile/profile-home.constants';
import { AlertType } from '../../shared/alerts/alertType.model';
import { AlertService } from '../../shared/services/alert.service';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { PreferencesService } from '../../shared/services/myprofile/preferences.service';
import { ProfileService } from '../../shared/services/myprofile/profile.service';
import { ValidationService } from '../../shared/services/validation.service';
import { AuthService } from '../../shared/shared.module';
import { VerifyEmailMobileService } from './verify-email-mobile.service';

declare let $: any;

@Component({
  selector: 'app-verify-email-mobile',
  templateUrl: './verify-email-mobile.component.html',
  styleUrls: ['./verify-email-mobile.component.scss']
})

export class VerifyEmailMobileComponent implements OnInit, OnDestroy {
  @ViewChild('accesscode1') accesscode1: ElementRef;
  @ViewChild('accesscode2') accesscode2: ElementRef;
  @ViewChild('accesscode3') accesscode3: ElementRef;
  @ViewChild('accesscode4') accesscode4: ElementRef;
  @ViewChild('accesscode5') accesscode5: ElementRef;
  @ViewChild('accesscode6') accesscode6: ElementRef;
  @Input('sendingpage') sendingPageName: string;
  @Output() processCompleteEmitter: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() prefModalVerifyCompleteEmitter = new EventEmitter();
  processComplete = false;

  verifyaccesscodeForm: FormGroup;
  errorMsg = false;
  accesscodeMask: any[];
  isFormSubmitted = false;
  location: string;
  maskedVerifiable: string;
  codeMask = { mask: this.validationService.numericMask, guide: false };
  verifyCategory = '';
  private shiftKeyDown = false;
  registeredUserOnly = false;
  alertDisplayContainer;

  destroy$ = new Subject<void>();

  constructor(
    private alertService: AlertService,
    private fb: FormBuilder,
    private router: Router,
    private validationService: ValidationService,
    private profileService: ProfileService,
    private authService: AuthService,
    private titleCase: TitleCasePipe,
    private authHttp: AuthHttp,
    private verifyEmailMobileService: VerifyEmailMobileService,
    private preferenceService: PreferencesService
  ) {

    this.alertService.clearError();
    this.location = this.router.url.split('/')[1];
    this.verifyaccesscodeForm = this.fb.group(
      {
        accesscode1: ['', [Validators.required]],
        accesscode2: ['', [Validators.required]],
        accesscode3: ['', [Validators.required]],
        accesscode4: ['', [Validators.required]],
        accesscode5: ['', [Validators.required]],
        accesscode6: ['', [Validators.required]]
      },
      {
        validator: this.validationService.accessCodeValidator()
      }
    );

    this.verifyaccesscodeForm.valueChanges.subscribe(accesscodes => {
      Object.keys(accesscodes).forEach((key, index) => {
        const itemValue = (accesscodes[key] ? accesscodes[key] : '').toString();
        if (itemValue.length > 1) {
          let currentIndex = index;
          itemValue.split('').forEach(character => {
            if (currentIndex < 6) {
              if (!accesscodes['accesscode' + (currentIndex + 1)] || index === currentIndex) {
                const accesscodekey = 'accesscode' + (currentIndex + 1);
                accesscodes[accesscodekey] = character;
                this.verifyaccesscodeForm.get(accesscodekey).setValue(character, { emitEvent: false });
                this[accesscodekey].nativeElement.focus();
              }
              currentIndex++;
            }
          });
        }
      });
    });
    this.accesscodeMask = this.validationService.accesscodeMask;
    this.verifyEmailMobileService.preferenceModalVerification$.subscribe((response) => {
      if (response && response.date === new Date().toString()) {
        this.verifyCategory = sessionStorage.getItem('maskedVerifyPhone') === 'Y' ? 'Mobile Number' : 'Email';
        this.maskedVerifiable = this.sendingPageName === 'my-pillpack' ? this.maskEmailId(this.profileService.getProfile().emailAddress) :
                                sessionStorage.getItem('maskedVerify');
      }
    });
  }

  ngOnInit() {
    const userRole = this.profileService.getUserRole();
    this.registeredUserOnly = userRole === 'REGISTERED-AND-VERIFIED' ? true : false;
    this.verifyCategory = sessionStorage.getItem('maskedVerifyPhone') === 'Y' ? 'Mobile Number' : 'Email';
    this.sendingPageName = this.sendingPageName ? this.sendingPageName.trim().toString() : null;
    this.alertDisplayContainer = this.sendingPageName && this.sendingPageName === 'preferenceModal' ? 'modalAlert' : '';
    this.maskedVerifiable = this.sendingPageName === 'my-pillpack' ? this.maskEmailId(this.profileService.getProfile().emailAddress) :
                            sessionStorage.getItem('maskedVerify');
  }

  maskEmailId(userId: string): string {
    const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
    userId = sentMailId && sentMailId['commChannel'] ? sentMailId['commChannel'] : userId;
    const maskedUserId = userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
        return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
      })
      : userId;
    return maskedUserId;
  }

  onSubmit() {
    this.isFormSubmitted = true;
    this.alertService.clearError();
    //fix for KLO-595
    const accessCode = [
      this.verifyaccesscodeForm.value.accesscode1, this.verifyaccesscodeForm.value.accesscode2,
      this.verifyaccesscodeForm.value.accesscode3, this.verifyaccesscodeForm.value.accesscode4,
      this.verifyaccesscodeForm.value.accesscode5, this.verifyaccesscodeForm.value.accesscode6
    ].join('');

    const { emailAddress } = JSON.parse(sessionStorage.getItem('memProfile'));
    const { phoneNumber } = JSON.parse(sessionStorage.getItem('memProfile'));
    const isVerifyPhone = sessionStorage.getItem('maskedVerifyPhone') === 'Y';
    const commChannel = isVerifyPhone ? 'MOBILE' : 'EMAIL';
    const commChannelValue = isVerifyPhone ? phoneNumber : emailAddress;
    const verifiedUsers = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
    const scopeName = this.authService.authToken ? this.authService.authToken.scopename : '';
    const isVerifyAccessCodeApi = !verifiedUsers.includes(scopeName);
    const verifyAccessCode = verifiedUsers.includes(scopeName) ?
      this.profileService.VerifyCommChlAccCode(accessCode, isVerifyPhone ? '' : commChannelValue, isVerifyPhone ? commChannelValue : '') :
      this.profileService.VerifyAccessCode(accessCode, commChannel, commChannelValue);

    if (this.verifyaccesscodeForm.valid) {
      verifyAccessCode.subscribe((response: any) => {
        if (response.result === '0') {
          const msg = commChannel !== 'MOBILE' ? PROFIE_CONSTANTS.verifiedEmailMsg : PROFIE_CONSTANTS.verifiedPhoneMsg;

          isVerifyAccessCodeApi ? sessionStorage.removeItem('sendCodeRes') :
                                 this.sendNotification(commChannel !== 'MOBILE', commChannel === 'MOBILE', commChannel, commChannelValue);

          if (sessionStorage.getItem('isPendingEmail') === 'true') {
            this.verifyEmailMobileService.verifyEmail(this.alertDisplayContainer === 'modalAlert' ? this.alertDisplayContainer : '');
            this.updateProfileInfo();
            sessionStorage.removeItem('isPendingEmail');
          } else {
            const url = sessionStorage.getItem('communicationPreferencePath') === 'communication-preferences' ?
                        ['myprofile'] : ['myprofile/contact-info'];
            if (this.sendingPageName === 'my-pillpack') {
              this.onPillPackVerificaion(msg);
            } else if (this.sendingPageName === 'preferenceModal') {
              this.prefModalVerifyCompleteEmitter.emit({result: response.result, channel: isVerifyPhone ? 'PHONE' : 'EMAIL'});
            } else if (url[0] === 'myprofile') {
              this.preferenceService.updatePreferenceInfo();
            } else {
              this.onContactInfoVerification(url, msg);
            }
          }
          this.authHttp.hideSpinnerLoading();
        } else {
          this.mapSendAccessErrorCode(response);
          this.authHttp.hideSpinnerLoading();
        }
      });
    }
  }

  private updateProfileInfo() {
    this.resetForm();
    let profile = JSON.parse(sessionStorage.getItem('memProfile'));
    profile = { ...profile, isVerifiedMobile: true };
    sessionStorage.setItem('memProfile', JSON.stringify(profile));
  }

  private onPillPackVerificaion (msg) {
    this.alertService.setAlert(msg, '', AlertType.Success);
    this.processComplete = true;
    this.processCompleteEmitter.emit(true);
  }

  private onContactInfoVerification(url, msg) {
    this.router.navigate(url).then(() => {
      this.alertService.setAlert(msg, '', AlertType.Success);
      sessionStorage.setItem('destination', JSON.stringify('contact-info'));
      this.profileService.initiateUpdateProfile();
      sessionStorage.removeItem('communicationPreferencePath');
    });
  }

  mapSendAccessErrorCode(response) {
    if (response['result'] === '-1') {
      this.alertService.setAlert( PROFIE_CONSTANTS.verifyCodeExpiredMsg, '', AlertType.Failure, 'component', this.alertDisplayContainer);
    } else if (response['result'] === '-2') {
      this.alertService.setAlert(PROFIE_CONSTANTS.verifyCodeCommErrorMsg, '', AlertType.Failure, 'component', this.alertDisplayContainer);
    } else if (response['result'] === '-3') {
      this.alertService.setAlert(PROFIE_CONSTANTS.verifyCodeFeatureNotAvailableMsg, '', AlertType.Failure,
                                 'component', this.alertDisplayContainer);
    } else if (response['result'] === '-4') {
      this.alertService.setAlert(PROFIE_CONSTANTS.verifyCodeDoesNotMach, '', AlertType.Failure, 'component', this.alertDisplayContainer);
    } else {
        this.alertService.setAlert(response['displaymessage'], '', AlertType.Failure, 'component', this.alertDisplayContainer);
    }
    this.resetForm();
    this.validationService.focusFirstError();
  }

  resetForm() {
    this.verifyaccesscodeForm.setValue({
      accesscode1: '', accesscode2: '', accesscode3: '',
      accesscode4: '', accesscode5: '', accesscode6: ''
    });
  }

  sendAccessCode() {
    this.resetForm();
    this.alertService.clearError();
    const { emailAddress } = JSON.parse(sessionStorage.getItem('memProfile'));
    const { phoneNumber } = JSON.parse(sessionStorage.getItem('memProfile'));
    const isVerifyPhone = sessionStorage.getItem('maskedVerifyPhone') === 'Y';
    const commChannel = isVerifyPhone ? 'MOBILE' : 'EMAIL';
    const commChannelValue = isVerifyPhone ? phoneNumber : emailAddress;
    const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
    if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
      this.sendcommchlaccesscode(isVerifyPhone ? '' : commChannelValue, isVerifyPhone ? commChannelValue : '');
    } else {
      this.sendaccesscode(commChannel, commChannelValue);
    }
  }

  private sendaccesscode(commChannelType, commChannel): void {
    this.profileService.sendaccesscode(commChannelType, commChannel).subscribe(
      res => {
        if (res['result'] === '0' || res['result'] === 0) {
          this.alertService.clearError();
          this.alertService.setAlert(PROFIE_CONSTANTS.verificationCodeResent, '', AlertType.Success,
                                     'component', this.alertDisplayContainer);
        } else {
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure, 'component', this.alertDisplayContainer);
          }
        }
        this.authHttp.hideSpinnerLoading();
      },
      err => {
        this.authHttp.hideSpinnerLoading();
      }
    );
  }

  private sendcommchlaccesscode(email, mobile): void {
    const isVerifyPhone = sessionStorage.getItem('maskedVerifyPhone') === 'Y';
    this.profileService.sendcommchlaccesscode(email, mobile.replace(/\D/g, '')).subscribe(
      res => {
        if (res['result'] === '0' || res['result'] === 0) {
          this.alertService.clearError();
          const errorMsg = isVerifyPhone ? PROFIE_CONSTANTS.verificationCodeResentPhone : PROFIE_CONSTANTS.verificationCodeResent;
          this.alertService.setAlert(errorMsg, '', AlertType.Success, 'component', this.alertDisplayContainer);
        } else {
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure, 'component', this.alertDisplayContainer);
          }
        }
      },
      err => {
        console.log('error', err);
      }
    );
  }

  private sendNotification(isEmailEdit: boolean, isMobileEdit: boolean, commChannelType: string, commChannel: string) {
    const myProfileURL = this.getMyProfileUrl();
    const notificationRequest = {
      useridin: this.authService.useridin,
      commChannel: commChannel,
      commChannelType: commChannelType,
      templateKeyword: isEmailEdit ? 'UPDATENOTIFICATION_EMAIL' : 'UPDATENOTIFICATION_MOBILE',
      notificationParms: [
        {
          keyName: 'firstName',
          keyValue:
            this.authService && this.authService.authToken && this.authService.authToken.firstName
              ? this.titleCase.transform(this.authService.authToken.firstName)
              : ''
        },
        {
          keyName: 'myProfileURL',
          keyValue: window.location.origin + myProfileURL
        },
        {
          keyName: 'updatedFields',
          keyValue: isEmailEdit ? ['Email'] : ['Phone Number']
        }
      ]
    };
    this.profileService.sendUpdateNotification(notificationRequest).subscribe(res => { });
  }

  onKeyDown($event) {
    this.profileService.onKeyDown($event);
  }

  onKeyUp($event, undefined, accesscode2) {
    this.profileService.onKeyUp($event, undefined, accesscode2);
  }
  getMyProfileUrl() {
    let path;
    const url = sessionStorage.getItem('communicationPreferencePath');
    if (this.sendingPageName === 'my-pillpack') {
      path = '/my-pillpack';
    } else if (this.sendingPageName === 'preferenceModal') {
      path = '/myprofile/communication-preferences';
    } else if (url === 'communication-preferences') {
      path = '/myprofile/communication-preferences';
    } else {
      path = '/myprofile/contact-info';
    }
    return path;
  }

  ngOnDestroy () {
    this.alertService.clearError();
    this.destroy$.next();
    this.destroy$.complete();
  }
}
