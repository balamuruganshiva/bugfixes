import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../shared/services/auth.service';
import { GlobalService } from '../../shared/services/global.service';
import { ValidationService } from '../../shared/services/validation.service';
import { AlertService } from '../../shared/shared.module';
import { DEFAULT_PHONE_NUM, NON_DIGIT_REGEX, PHONE_FORM_MESSAGES } from './profile-phone.constants';
import { UNDELIVERABLE_MESSAGE } from '../../pages/preference-modal/preference-modal/preference-modal.constants';
import { AlertType } from '../../shared/alerts/alertType.model';
import { PreferencesService } from '../../shared/services/myprofile/preferences.service';

@Component({
  selector: 'app-profile-phone',
  templateUrl: './profile-phone.component.html',
  styleUrls: ['./profile-phone.component.scss']
})
export class ProfilePhoneComponent implements OnInit, OnChanges {
  @Input() profile: any;
  @Input() editPhone: boolean;
  @Input() isPhoneNumberRequired: boolean;
  @Input() slot: string;
  @Input() isTextUnDeliverable: boolean;
  @Input() isChannelEditCancelledText: boolean;
  @Output() cancelEdit: EventEmitter<any> = new EventEmitter();
  @Output() editProfile: EventEmitter<any> = new EventEmitter();

  impersonate = true;

  isFormSubmitted = false;
  profilePhoneEditForm: FormGroup;
  mobileNumberMessages = PHONE_FORM_MESSAGES;
  mask = { mask: this.validationService.phoneMask, guide: false };
  hasActivePlan: string;

  constructor(
    private fb: FormBuilder,
    private validationService: ValidationService,
    private globalService: GlobalService,
    private authService: AuthService,
    private alertService: AlertService,
    private prefService: PreferencesService
  ) {
    this.hasActivePlan = this.authService.isUserActive();
  }

  ngOnInit() {
    this.prefService.closeChannelEdit.subscribe((response) => {
      if (response.channel === 'SMS' && response.status === 'true') {
        this.cancelPhone();
      } else if (response.channel === 'SMS' && response.status === 'false') {
        this.editPhone = true;
      }
    });
    this.showAlertMessage();
  }

  showAlertMessage() {
    setTimeout(() => {
      if (this.isTextUnDeliverable) {
        this.alertService.setAlert(UNDELIVERABLE_MESSAGE.sms, '', AlertType.Failure,
        'component', 'profilePhoneMessage');
      }
    }, 0);
  }
  initializeForm() {
    this.profilePhoneEditForm = this.fb.group({
      useridin: '',
      phoneNumber: ['', this.editPhone ? [Validators.required, this.validationService.phoneValidator()] : []],
      phoneType: [this.getDefaultOptionForPhoneNumberType(), this.editPhone ? [Validators.required] : []],
      fullName: '',
      isVerifiedPhone: false
    });
    if (this.profile) {
      if (!this.profile.phoneNumber) {
        this.profile.phoneNumber = DEFAULT_PHONE_NUM;
      }
      this.profilePhoneEditForm.patchValue(this.profile);
      this.globalService.markFormGroupTouched(this.profilePhoneEditForm);
    }
    if (!this.isPhoneNumberRequired) {
      this.profilePhoneEditForm.controls['phoneNumber'].setValidators([]);
      this.profilePhoneEditForm.controls['phoneNumber'].updateValueAndValidity();
      this.profilePhoneEditForm.controls['phoneType'].setValidators([]);
      this.profilePhoneEditForm.controls['phoneType'].updateValueAndValidity();
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.editPhone) {
      this.initializeForm();
    }
    if (this.profilePhoneEditForm) {
      this.profilePhoneEditForm.patchValue(this.profile);
    }
  }

  get isButtonDisabled() {
    return (
      this.impersonation() ||
      this.hasActivePlan === 'false' ||
      !this.profilePhoneEditForm.valid ||
      this.profile.phoneNumber.replace(NON_DIGIT_REGEX, '') ===
        this.profilePhoneEditForm.get('phoneNumber').value.replace(NON_DIGIT_REGEX, '')
    );
  }

  impersonation() {
    return this.authService.impersonation();
  }

  getDefaultOptionForPhoneNumberType() {
    if (this.profile) {
      this.profile.phoneType = 'MOBILE';
      return this.profile.phoneType;
    }
  }

  onPhoneSubmit() {
    this.prefService.isChannelEditSaved.next({
      channel: 'SMS',
      status: 'true'
    })
    this.isFormSubmitted = true;
    this.editPhone = false;
    let profile = JSON.parse(sessionStorage.getItem('memProfile'));
    profile = { ...profile, phoneNumber: this.profilePhoneEditForm.value.phoneNumber.replace(/\D/g, ''), isVerifiedMobile: false };
    if (!profile.phoneNumber) {
      profile = { ...profile, phoneNumber: '0000000000' };
    }
    sessionStorage.setItem('memProfile', JSON.stringify(profile));
    this.editProfile.emit('PHONE');
  }

  cancelPhone() {
    this.prefService.isChannelEditCancelledD.next({
      channel: 'SMS',
      status: 'true'
    });
    this.editPhone = false;
    this.cancelEdit.emit('PHONE');
    const profile = JSON.parse(sessionStorage.getItem('memProfile'));
    this.profilePhoneEditForm.patchValue(profile);
  }
}
