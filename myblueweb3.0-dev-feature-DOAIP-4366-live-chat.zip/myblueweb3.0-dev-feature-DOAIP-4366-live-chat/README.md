# MyBlueWeb3.0
>Web Development - A more personalized way to access your health care info, claims, and more
## NPM dependencies details
<code>Last Updated: 3/15/2018</code>
<table class="table-list" width="100%">
<thead>
<tr>
<td width="30%"><strong>Name</strong></td>
<td width="35%"><strong>Installation </strong></td>
<td width="35%"><strong>Usage</strong></td>
</tr>
</thead>
<tbody>
<tr>
    <td><a href="https://github.com/auth0/angular2-jwt">angular2-jwt<a><br/><br/>
    <img alt="^0.2.3" src="https://img.shields.io/badge/ver.-%5E0.2.3-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/auth0/angular2-jwt/blob/master/LICENSE.txt">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a></td>
    <td>
        <code>
            npm install @auth0/angular-jwt
        </code>
    </td>
    <td><p>Used for OAuth</p></td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/InfomediaLtd/angular2-materialize">angular2-materialize<a><br/><br/>
        <img alt="^15.1.9" src="https://img.shields.io/badge/ver.-%5E15.1.9-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/InfomediaLtd/angular2-materialize/blob/master/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install materialize-css --save </code><br/>
        <code>npm install angular2-materialize --save </code><br/>
        <code>npm install jquery@^2.2.4 --save </code><br/>
        <code>npm install hammerjs --save</code>
    </td>
    <td>Used for assisting materailize css components</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/urish/angular2-moment">angular2-moment<a><br/><br/>
        <img alt="^1.7.0" src="https://img.shields.io/badge/ver.-%5E1.7.0-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/urish/angular2-moment/blob/master/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install --save angular2-moment </code>
    </td>
    <td>
        Used as formatting pipes
    </td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/text-mask/text-mask">angular2-text-mask<a><br/><br/>
        <img alt="^8.0.4" src="https://img.shields.io/badge/ver.-%5E8.0.4-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/text-mask/text-mask/blob/master/LICENSE">
            <img alt="unlincensed" src="https://img.shields.io/badge/license-Unlicense-lightgrey.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install angular2-text-mask</code>
    </td>
    <td>
    Text Mask is an input mask library. It can create input masks for phone, date, currency, zip code, percentage, email, and literally anything!
    </td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/expressjs/body-parser">body-parser<a><br/><br/>
        <img alt="^1.18.1" src="https://img.shields.io/badge/ver.-%5E1.18.1-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/expressjs/body-parser/blob/master/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install body-parser</code>
    </td>
    <td>Parse incoming request bodies in a middleware before your handlers
    </td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/eligrey/classList.js/">classlist.js<a><br/><br/>
        <img alt="^1.1.20150312" src="https://img.shields.io/badge/ver.-%5E1.1.20150312-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/eligrey/classList.js/blob/master/LICENSE.md">
             <img alt="unlincensed" src="https://img.shields.io/badge/license-Unlicense-lightgrey.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install classlist-polyfill</code>
    </td>
    <td>cross-browser JavaScript shim that fully implements element.classList</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/zloirock/core-js">core-js<a><br/><br/>
        <img alt="^2.4.1" src="https://img.shields.io/badge/ver.-%5E2.4.1-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/zloirock/core-js/blob/master/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install core-js</code>
    </td>
    <td>Modular standard library for JavaScript. Includes polyfills</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/brix/crypto-js">crypto-js<a><br/><br/>
        <img alt="^3.1.9-1" src="https://img.shields.io/badge/ver.-%5E3.1.9-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/brix/crypto-js/blob/develop/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install crypto-js</code>
    </td>
    <td>Used to encrypt and decrypt API calls.
    </td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/expressjs/express">express<a><br/><br/>
        <img alt="^4.15.4" src="https://img.shields.io/badge/ver.-%5E4.15.4-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/expressjs/express/blob/master/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install express</code>
    </td>
    <td>is a light-weight web application framework to help organize your web application into an MVC architecture on the server side</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/auth0/node-jsonwebtoken">jsonwebtoken<a><br/><br/>
        <img alt="^8.1.1" src="https://img.shields.io/badge/ver.-%5E8.1.1-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/auth0/node-jsonwebtoken/blob/master/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install jsonwebtoken</code>
    </td>
    <td>An implementation of JSON Web Tokens 
    </td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/johnpapa/lite-server">lite-server<a><br/><br/>
        <img alt="^2.3.0" src="https://img.shields.io/badge/ver.-%5E2.3.0-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/johnpapa/lite-server/blob/master/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install lite-server</code>
    </td>
    <td>Lightweight development only node server that serves a web app, opens it in the browser, refreshes when html or javascript change, injects CSS changes using sockets, and has a fallback page when a route is not found.</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/Dogfalo/materialize">materialize-css<a><br/><br/>
        <img alt="^0.100.2" src="https://img.shields.io/badge/ver.-%5E0.100.2-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/Dogfalo/materialize/blob/v1-dev/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install materialize-css</code>
    </td>
    <td>css framework that enables responsive views</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/moment/moment">moment<a><br/><br/>
        <img alt="^2.18.1" src="https://img.shields.io/badge/ver.-%5E2.18.1-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/moment/moment/blob/develop/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install moment</code>
    </td>
    <td>Library to deal with dates</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/VadimDez/ngx-filter-pipe">ngx-filter-pipe<a><br/><br/>
        <img alt="^1.0.0" src="https://img.shields.io/badge/ver.-%5E1.0.0-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/VadimDez/ngx-filter-pipe/blob/master/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install ngx-filter-pipe</code>
    </td>
    <td>Angular 5+ pipeline for filtering arrays.</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/VadimDez/ngx-order-pipe">ngx-order-pipe<a><br/><br/>
        <img alt="^1.0.3" src="https://img.shields.io/badge/ver.-%5E1.0.3-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/VadimDez/ngx-order-pipe/blob/master/LICENSE">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install ngx-order-pipe</code>
    </td>
    <td>Order your collection by a field</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/primefaces/primeng">primeng<a><br/><br/>
        <img alt="^4.2.2" src="https://img.shields.io/badge/ver.-%5E4.2.2-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/primefaces/primeng/blob/master/README.md">
            <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install primeng</code>
    </td>
    <td>PrimeNG is a collection of rich UI components for Angular</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/getsentry/raven-js">raven-js<a><br/><br/>
        <img alt="^3.22.1" src="https://img.shields.io/badge/ver.-%5E3.22.1-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/getsentry/raven-js/blob/master/LICENSE">
            <img alt="BSD 2-Clause Simplified License" src="https://img.shields.io/badge/license-BSD_2C_Sim-228b22.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install raven-js</code>
    </td>
    <td>Sentry SDK for JavaScript integration</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/ReactiveX/RxJS">rxjs<a><br/><br/>
        <img alt="^5.5.2" src="https://img.shields.io/badge/ver.-%5E5.5.2-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/ReactiveX/rxjs/blob/master/LICENSE.txt">
            <img alt="Apache License 2.0" src="https://img.shields.io/badge/license-Apache2.0-000099.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install rxjs</code>
    </td>
    <td>set of libraries to compose asynchronous and event-based programs using observable collections.</td>
</tr>
<tr>
    <td valign="top"><a href="https://github.com/strongloop/zone">zone.js<a><br/><br/>
        <img alt="^0.8.14" src="https://img.shields.io/badge/ver.-%5E0.8.14-blue.svg?longCache=true&style=flat-square"/>&nbsp;
        <a href="https://github.com/strongloop/zone/blob/master/LICENSE">
             <img alt="MIT" src="https://img.shields.io/badge/license-MIT-7F00FF.svg?longCache=true&style=flat-square"/>
        </a>
    </td>
    <td>
        <code>npm install zone</code>
    </td>
    <td>The Zone library provides a way to represent the dynamic extent of asynchronous calls in Node. Just like the scope of a function defines where it may be used, the extent of a call represents the lifetime that is it active.</td>
</tr>
</tbody>
</table>

## License
> © 2018 Blue Cross and Blue Shield of Massachusetts, Inc.., and Blue Cross and Blue Shield of Massachusetts HMO Blue, Inc.
